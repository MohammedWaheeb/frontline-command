package main

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"frontlinecommand/pkg/content"
	"frontlinecommand/pkg/sim"
	"os"
	"path/filepath"
	"runtime/pprof"
	"time"
)

type command struct {
	Tick     sim.Tick     `json:"tick"`
	Player   sim.PlayerID `json:"player"`
	Sequence uint32       `json:"sequence"`
	Orders   []sim.Order  `json:"orders"`
}
type oracle struct {
	Initial  string    `json:"initial_hash"`
	Commands []command `json:"commands"`
	Frames   []struct {
		Tick sim.Tick `json:"tick"`
		Hash string   `json:"hash"`
	} `json:"frames"`
}

func check(e error) {
	if e != nil {
		panic(e)
	}
}
func digest(b []byte) string { x := sha256.Sum256(b); return hex.EncodeToString(x[:]) }
func main() {
	input := flag.String("input", "", "exact existing workload")
	out := flag.String("out", "", "new output directory")
	flag.Parse()
	check(os.Mkdir(*out, 0700))
	opening, err := os.ReadFile(filepath.Join(*input, "opening.json"))
	check(err)
	raw, err := os.ReadFile(filepath.Join(*input, "native.json"))
	check(err)
	if digest(opening) != "acdcea47599b98a9feb05df8b795b1166b0885139757e3e7df8d8cc37ecbd582" || digest(raw) != "65b2a87eda9148643898eb3d12c564a69b46ee5db5c043f79bdc438917d7bd9f" {
		panic("fixture drift")
	}
	var expected oracle
	check(json.Unmarshal(raw, &expected))
	c := content.MustBase()
	f, err := os.Create(filepath.Join(*out, "cpu.pprof"))
	check(err)
	check(pprof.StartCPUProfile(f))
	rows := []map[string]any{}
	hashes := map[sim.Tick]string{}
	for _, frame := range expected.Frames {
		hashes[frame.Tick] = frame.Hash
	}
	for run := 0; run < 12; run++ {
		var e *sim.Engine
		pprof.Do(context.Background(), pprof.Labels("phase", "prepare"), func(context.Context) {
			e, err = sim.Restore(c, opening)
			check(err)
			if e.Hash() != expected.Initial {
				panic("opening hash")
			}
			submitted := 0
			for _, order := range expected.Commands {
				if order.Tick == 0 {
					check(e.Submit(order.Player, order.Sequence, order.Orders))
					submitted++
				}
			}
			if submitted != 16 {
				panic("command count")
			}
			_, err = sim.NewReplay(e)
			check(err)
			for player := sim.PlayerID(1); player <= 4; player++ {
				e.PlayerView(player)
			}
		})
		for tick := 1; tick <= 8; tick++ {
			var elapsed time.Duration
			pprof.Do(context.Background(), pprof.Labels("phase", "advance", "tick", fmt.Sprint(tick)), func(context.Context) { at := time.Now(); e.Advance(); elapsed = time.Since(at) })
			rows = append(rows, map[string]any{"run": run, "tick": tick, "advance_ns": elapsed.Nanoseconds()})
			if h, ok := hashes[e.Tick()]; ok && e.Hash() != h {
				panic(fmt.Sprintf("tick%d hash mismatch", tick))
			}
		}
	}
	pprof.StopCPUProfile()
	check(f.Close())
	report := map[string]any{"scope": "Exact3d49 first8ticks repeated12times with exact ordinary initial16 Submit batches, NewReplay and initial four PlayerViews. CPU sampling on shared M4 with one Blender worker, not quiet timing qualification or full actual server loop. Prepare labels excluded when attributing Advance; canonical tick4/tick8 hashes checked every iteration.", "status": "passed", "rows": rows}
	b, err := json.MarshalIndent(report, "", "  ")
	check(err)
	check(os.WriteFile(filepath.Join(*out, "receipt.json"), append(b, '\n'), 0600))
	fmt.Println("12 exact first8-tick profiles complete")
}
