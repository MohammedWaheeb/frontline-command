import {REVISION_STORE,upgradeRevisions,reserveRevision} from './idb-revisions';
import {APIError,LocalAPI,type Profile} from './api';
import {RuntimeError,type RuntimeFailure} from './errors';
export interface LocalCredential{origin:string;token:string;profile:Profile;revision:number}
export interface CredentialStorage{read(origin:string):Promise<LocalCredential|undefined>;write(value:Omit<LocalCredential,'revision'>,expectedRevision:number):Promise<LocalCredential>;remove(origin:string,token:string,revision?:number):Promise<boolean>}
export interface AccountContext{origin:string;profileId:string;generation:number}
export interface AccountState{phase:'guest'|'restoring'|'signed-in'|'offline'|'sign-in-required';origin:string;profile?:Profile;persistent:boolean;error?:RuntimeFailure}
export interface AccountOptions{baseURL?:string;credentials?:CredentialStorage;makeAPI?:(baseURL:string,token:string)=>LocalAPI}
function originOf(value:string){let url:URL;try{url=new URL(value)}catch{throw new RuntimeError('account_host','Choose a valid local host address.')};if(!['http:','https:'].includes(url.protocol)||url.username||url.password)throw new RuntimeError('account_host','Local profiles need an HTTP or HTTPS host without embedded credentials.');return url.origin}
function validToken(value:unknown):value is string{return typeof value==='string'&&/^[a-f0-9]{64}$/.test(value)}
function profile(value:Profile):Profile{if(!value||typeof value.id!=='string'||!value.id||typeof value.name!=='string'||!Number.isSafeInteger(value.created)||value.created<0)throw new RuntimeError('invalid_response','The host returned an invalid local profile.');return structuredClone(value)}
function vaultError(error:unknown){if(error instanceof RuntimeError)return error;return new RuntimeError('credential_storage_unavailable','The browser could not update its local profile sign-in. Game files and progress are preserved.');}
function request<T>(r:IDBRequest<T>){return new Promise<T>((resolve,reject)=>{r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(vaultError(r.error))})}
function complete(tx:IDBTransaction){return new Promise<void>((resolve,reject)=>{tx.oncomplete=()=>resolve();tx.onabort=()=>reject(vaultError(tx.error));tx.onerror=()=>{}})}
/** Credentials deliberately live outside all game-save, progress, and editor backups. */
export class LocalCredentialVault implements CredentialStorage{
 private db:Promise<IDBDatabase>|undefined;
 constructor(readonly database='frontline-command-auth'){}
 private open(){if(this.db)return this.db;this.db=new Promise<IDBDatabase>((resolve,reject)=>{if(!globalThis.indexedDB){reject(vaultError(undefined));return}let blocked=false;const r=indexedDB.open(this.database,2);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains('credentials'))r.result.createObjectStore('credentials',{keyPath:'origin'});upgradeRevisions(r.result,r.transaction!,[{name:'credentials',key:'origin'}])};r.onerror=()=>reject(vaultError(r.error));r.onblocked=()=>{blocked=true;reject(new RuntimeError('credential_storage_busy','Close another game tab before changing stored sign-in details.'))};r.onsuccess=()=>{if(blocked){r.result.close();return}r.result.onversionchange=()=>{r.result.close();this.db=undefined};resolve(r.result)}}).catch(error=>{this.db=undefined;throw error});return this.db}
 async read(origin:string){const db=await this.open(),value=await request(db.transaction('credentials').objectStore('credentials').get(originOf(origin))) as LocalCredential|undefined;if(value&&(!validToken(value.token)||!Number.isSafeInteger(value.revision)||value.revision<1))throw new RuntimeError('credential_corrupt','Stored sign-in details are unreadable. Restore a local profile token or create a local profile.');if(value)profile(value.profile);return value}
 async write(value:Omit<LocalCredential,'revision'>,expectedRevision:number){
  const origin=originOf(value.origin);if(!validToken(value.token)||!Number.isSafeInteger(expectedRevision)||expectedRevision<0)throw new RuntimeError('credential_invalid','The local profile token or revision is invalid.');const checkedProfile=profile(value.profile),db=await this.open(),tx=db.transaction(['credentials',REVISION_STORE],'readwrite'),done=complete(tx);done.catch(()=>{});
  try{const store=tx.objectStore('credentials'),current=await request(store.get(origin)) as LocalCredential|undefined;if(current&&(!Number.isSafeInteger(current.revision)||current.revision<1)){tx.abort();throw new RuntimeError('credential_corrupt','Stored sign-in metadata is unreadable. Preserve it and use a session-only profile.')}if((current?.revision??0)!==expectedRevision){tx.abort();throw new RuntimeError('credential_conflict','Another game tab changed the stored local profile. Review that sign-in before replacing it.')}const record={origin,token:value.token,profile:checkedProfile,revision:await reserveRevision(tx,'credentials',origin,current?.revision??0)};store.put(record);await done;return record}catch(error){try{tx.abort()}catch{}throw vaultError(error)}
 }
 async remove(origin:string,token:string,revision?:number){const db=await this.open(),tx=db.transaction(['credentials',REVISION_STORE],'readwrite'),done=complete(tx);done.catch(()=>{});try{const store=tx.objectStore('credentials'),current=await request(store.get(originOf(origin))) as LocalCredential|undefined;const removed=current?.token===token&&(revision===undefined||current.revision===revision);if(removed){await reserveRevision(tx,'credentials',originOf(origin),current.revision,false);store.delete(originOf(origin))}await done;return removed}catch(error){try{tx.abort()}catch{}throw vaultError(error)}}
 async close(){if(this.db)(await this.db).close();this.db=undefined}
}

export class LocalProfileSession{
 readonly origin:string;private readonly vault:CredentialStorage;private readonly makeAPI:(base:string,token:string)=>LocalAPI;
 #credential:LocalCredential|undefined;private generation=0;private busy=false;private stateValue:AccountState;private listeners=new Set<(state:AccountState)=>void>();
 constructor(options:AccountOptions={}){this.origin=originOf(options.baseURL??globalThis.location?.origin??'http://127.0.0.1:8080');this.vault=options.credentials??new LocalCredentialVault();this.makeAPI=options.makeAPI??((base,token)=>new LocalAPI(base,token));this.stateValue={phase:'guest',origin:this.origin,persistent:false}}
 get state():AccountState{return structuredClone(this.stateValue)}
 get context():AccountContext|undefined{return this.#credential?{origin:this.origin,profileId:this.#credential.profile.id,generation:this.generation}:undefined}
 subscribe(listener:(state:AccountState)=>void){this.listeners.add(listener);return()=>this.listeners.delete(listener)}
 private publish(state:AccountState){this.stateValue=state;for(const listener of this.listeners)try{listener(this.state)}catch{/* No credential or callback errors are logged. */}}
 private failure(error:unknown):RuntimeFailure{const e=RuntimeError.from(error);return {code:e.code,message:e.message,recoverable:true}}
 private same(context:AccountContext){const now=this.context;return !!now&&now.origin===context.origin&&now.profileId===context.profileId&&now.generation===context.generation}
 assertContext(context:AccountContext){if(!this.same(context))throw new RuntimeError('account_changed','The local profile changed. Preview the operation again for the current profile.')}
 private begin(){if(this.busy)throw new RuntimeError('account_busy','Wait for the current sign-in operation to finish.');this.busy=true;return ++this.generation}
 private async invalid(credential:LocalCredential,epoch:number){if(epoch!==this.generation)return;this.#credential=undefined;let error:RuntimeFailure={code:'sign_in_required',message:'The host no longer accepts this local profile token. Restore a token or create a local profile; solo saves remain available.',recoverable:true};try{await this.vault.remove(this.origin,credential.token,credential.revision)}catch(cause){error=this.failure(cause)}if(epoch===this.generation)this.publish({phase:'sign-in-required',origin:this.origin,persistent:false,error})}
 async restore(signal?:AbortSignal):Promise<AccountState>{
  const epoch=this.begin();this.publish({phase:'restoring',origin:this.origin,persistent:false});let credential:LocalCredential|undefined;
  try{credential=await this.vault.read(this.origin);if(epoch!==this.generation)return this.state;if(!credential){this.#credential=undefined;this.publish({phase:'guest',origin:this.origin,persistent:false});return this.state}this.#credential=credential;const found=profile(await this.makeAPI(this.origin,credential.token).me(signal));if(epoch!==this.generation)return this.state;if(found.id!==credential.profile.id)throw new RuntimeError('credential_profile_mismatch','The stored token belongs to another local profile. Restore the intended profile explicitly.');this.#credential={...credential,profile:found};this.publish({phase:'signed-in',origin:this.origin,profile:found,persistent:true});return this.state}
  catch(error){if(epoch!==this.generation)return this.state;if(error instanceof APIError&&error.status===401&&credential){await this.invalid(credential,epoch);return this.state}this.publish({phase:credential?'offline':'guest',origin:this.origin,profile:credential?.profile,persistent:!!credential,error:this.failure(error)});return this.state}
  finally{this.busy=false}
 }
 private async adopt(token:string,found:Profile,remember:boolean,epoch:number,previous?:LocalCredential){
  if(epoch!==this.generation)throw new RuntimeError('account_changed','Sign-in was canceled before it could replace the current profile.');const value={origin:this.origin,token,profile:profile(found)};let persistent=false,error:RuntimeFailure|undefined;
  let credential:LocalCredential={...value,revision:0};if(!remember&&previous)try{if(!await this.vault.remove(this.origin,previous.token,previous.revision))error={code:'credential_conflict',message:'Another tab changed the remembered profile. This sign-in is session-only.',recoverable:true}}catch(cause){error=this.failure(cause)}if(remember)try{credential=await this.vault.write(value,previous?.revision??0);persistent=true}catch(cause){error=this.failure(cause)}
  if(epoch!==this.generation){if(persistent)await this.vault.remove(this.origin,token,credential.revision);throw new RuntimeError('account_changed','Sign-in was canceled. Existing game files remain available.')}
  this.#credential=credential;this.publish({phase:'signed-in',origin:this.origin,profile:credential.profile,persistent,...(error?{error}:{})});return this.state;
 }
 async create(name:string,options:{remember?:boolean;signal?:AbortSignal}={}):Promise<AccountState>{
  const epoch=this.begin();try{let previous:LocalCredential|undefined;try{previous=await this.vault.read(this.origin)}catch{/* A session-only profile may still work. */}const result=await this.makeAPI(this.origin,'').createProfile(name,options.signal);if(!validToken(result.token))throw new RuntimeError('invalid_response','The host returned an invalid local profile token.');return await this.adopt(result.token,result.profile,options.remember!==false,epoch,previous)}finally{this.busy=false}
 }
 /** Only call from an explicit private sign-in-key export action, never a game backup. */
 exportSignInKey():Blob{
  if(this.busy)throw new RuntimeError('account_busy','Wait for the sign-in operation to finish.');const credential=this.#credential;if(!credential)throw new RuntimeError('sign_in_required','Sign in before exporting your private local key.');
  return new Blob([JSON.stringify({format:'frontline-local-sign-in',version:1,origin:this.origin,profile_id:credential.profile.id,token:credential.token})],{type:'application/json'});
 }
 async restoreSignInKey(file:Blob,options:{remember?:boolean;signal?:AbortSignal}={}):Promise<AccountState>{
  if(!(file instanceof Blob)||file.size<1||file.size>2048)throw new RuntimeError('credential_invalid','Choose a private local sign-in key no larger than 2 KiB.');const generation=this.generation;let value:any;try{value=JSON.parse(await file.text())}catch{throw new RuntimeError('credential_invalid','This file is not a readable local sign-in key.')}
  if(generation!==this.generation)throw new RuntimeError('account_changed','The profile changed while this key was being read. Select it again if you want to switch.');
  if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==5||Object.keys(value).some(key=>!['format','version','origin','profile_id','token'].includes(key))||value.format!=='frontline-local-sign-in'||value.version!==1||typeof value.origin!=='string'||typeof value.profile_id!=='string'||!/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,99}$/.test(value.profile_id)||!validToken(value.token))throw new RuntimeError('credential_invalid','This file is not a supported local sign-in key.');
  if(originOf(value.origin)!==value.origin||value.origin!==this.origin)throw new RuntimeError('credential_host_mismatch','This private key belongs to a different host origin. Connect to the original host before importing it.');
  return this.restoreCredential(value.token,options,value.profile_id);
 }
 async restoreToken(token:string,options:{remember?:boolean;signal?:AbortSignal}={}):Promise<AccountState>{return this.restoreCredential(token,options)}
 private async restoreCredential(token:string,options:{remember?:boolean;signal?:AbortSignal},expectedProfile?:string):Promise<AccountState>{

  if(!validToken(token))throw new RuntimeError('credential_invalid','Enter the complete local profile token.');const epoch=this.begin();try{let previous:LocalCredential|undefined;try{previous=await this.vault.read(this.origin)}catch{}const found=await this.makeAPI(this.origin,token).me(options.signal);if(expectedProfile!==undefined&&found.id!==expectedProfile)throw new RuntimeError('credential_profile_mismatch','The host profile does not match this private key. Existing sign-in is unchanged.');return await this.adopt(token,found,options.remember!==false,epoch,previous)}catch(error){if(error instanceof APIError&&error.status===401)throw new RuntimeError('sign_in_required','This host does not recognize that local profile token. Your solo saves remain available.');throw error}finally{this.busy=false}
 }
 /** The callback is trusted application logic; never display or export its API token. */
 async authenticated<T>(operation:(api:LocalAPI)=>Promise<T>,options:{context?:AccountContext;allowChangedResult?:boolean}={}):Promise<T>{
  const context=options.context??this.context;if(!context||!this.#credential)throw new RuntimeError('sign_in_required','Create or restore a local profile to use this host service. Solo play remains available.');this.assertContext(context);const credential=this.#credential;
  try{const value=await operation(this.makeAPI(this.origin,credential.token));if(!options.allowChangedResult)this.assertContext(context);if(this.same(context)&&this.stateValue.phase==='offline')this.publish({phase:'signed-in',origin:this.origin,profile:credential.profile,persistent:this.stateValue.persistent});return value}
  catch(error){if(error instanceof APIError&&error.status===401){await this.invalid(credential,context.generation);throw new RuntimeError('sign_in_required','The host no longer accepts this profile. Restore or create a local profile; your local files are preserved.')}throw error}
 }
 async logout():Promise<void>{let credential=this.#credential;this.#credential=undefined;const epoch=++this.generation;this.publish({phase:'guest',origin:this.origin,persistent:false});try{credential??=await this.vault.read(this.origin);if(epoch===this.generation&&credential)await this.vault.remove(this.origin,credential.token,credential.revision)}catch(error){if(epoch===this.generation)this.publish({phase:'guest',origin:this.origin,persistent:false,error:this.failure(error)});throw error}}
}
