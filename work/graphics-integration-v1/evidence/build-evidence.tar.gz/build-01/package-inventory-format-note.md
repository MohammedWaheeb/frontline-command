# Private wrapper inventory format correction

The browser product passed static integrity and all byte descriptors rehash correctly, but this private builder wrote the package root inventory as a bare array. The ordinary package schema is `{format_version: 1, files: [...]}`. This is a wrapper-tooling defect, not a renderer/runtime defect. No browser ran against build-01. The original build/recipe/post-audit are preserved; build-02 corrects the schema and adds whole non-client input/output comparison in the builder. Use build-02 for follow-up browser work.
