"use strict";
(() => {
  // client/node_modules/@bufbuild/protobuf/dist/esm/is-message.js
  function isMessage(arg, schema) {
    const isMessage2 = arg !== null && typeof arg == "object" && "$typeName" in arg && typeof arg.$typeName == "string";
    if (!isMessage2) {
      return false;
    }
    if (schema === void 0) {
      return true;
    }
    return schema.typeName === arg.$typeName;
  }

  // client/node_modules/@bufbuild/protobuf/dist/esm/descriptors.js
  var ScalarType;
  (function(ScalarType2) {
    ScalarType2[ScalarType2["DOUBLE"] = 1] = "DOUBLE";
    ScalarType2[ScalarType2["FLOAT"] = 2] = "FLOAT";
    ScalarType2[ScalarType2["INT64"] = 3] = "INT64";
    ScalarType2[ScalarType2["UINT64"] = 4] = "UINT64";
    ScalarType2[ScalarType2["INT32"] = 5] = "INT32";
    ScalarType2[ScalarType2["FIXED64"] = 6] = "FIXED64";
    ScalarType2[ScalarType2["FIXED32"] = 7] = "FIXED32";
    ScalarType2[ScalarType2["BOOL"] = 8] = "BOOL";
    ScalarType2[ScalarType2["STRING"] = 9] = "STRING";
    ScalarType2[ScalarType2["BYTES"] = 12] = "BYTES";
    ScalarType2[ScalarType2["UINT32"] = 13] = "UINT32";
    ScalarType2[ScalarType2["SFIXED32"] = 15] = "SFIXED32";
    ScalarType2[ScalarType2["SFIXED64"] = 16] = "SFIXED64";
    ScalarType2[ScalarType2["SINT32"] = 17] = "SINT32";
    ScalarType2[ScalarType2["SINT64"] = 18] = "SINT64";
  })(ScalarType || (ScalarType = {}));

  // client/node_modules/@bufbuild/protobuf/dist/esm/wire/varint.js
  function varint64read() {
    const buf = this.buf;
    let pos = this.pos;
    let lo = 0;
    let hi = 0;
    for (let shift = 0; shift < 28; shift += 7) {
      const b = buf[pos++];
      lo |= (b & 127) << shift;
      if ((b & 128) == 0) {
        this.pos = pos;
        this.assertBounds();
        this.varint64Lo = lo;
        this.varint64Hi = hi;
        return;
      }
    }
    const middleByte = buf[pos++];
    lo |= (middleByte & 15) << 28;
    hi = (middleByte & 112) >> 4;
    if ((middleByte & 128) == 0) {
      this.pos = pos;
      this.assertBounds();
      this.varint64Lo = lo;
      this.varint64Hi = hi;
      return;
    }
    for (let shift = 3; shift <= 31; shift += 7) {
      const b = buf[pos++];
      hi |= (b & 127) << shift;
      if ((b & 128) == 0) {
        this.pos = pos;
        this.assertBounds();
        this.varint64Lo = lo;
        this.varint64Hi = hi;
        return;
      }
    }
    throw new Error("invalid varint");
  }
  var TWO_PWR_32_DBL = 4294967296;
  function int64FromString(dec) {
    const minus = dec[0] === "-";
    if (minus) {
      dec = dec.slice(1);
    }
    const base = 1e6;
    let lowBits = 0;
    let highBits = 0;
    function add1e6digit(begin, end) {
      const digit1e6 = Number(dec.slice(begin, end));
      highBits *= base;
      lowBits = lowBits * base + digit1e6;
      if (lowBits >= TWO_PWR_32_DBL) {
        highBits = highBits + (lowBits / TWO_PWR_32_DBL | 0);
        lowBits = lowBits % TWO_PWR_32_DBL;
      }
    }
    add1e6digit(-24, -18);
    add1e6digit(-18, -12);
    add1e6digit(-12, -6);
    add1e6digit(-6);
    return minus ? negate(lowBits, highBits) : newBits(lowBits, highBits);
  }
  function int64ToString(lo, hi) {
    let bits = newBits(lo, hi);
    const negative = bits.hi & 2147483648;
    if (negative) {
      bits = negate(bits.lo, bits.hi);
    }
    const result = uInt64ToString(bits.lo, bits.hi);
    return negative ? "-" + result : result;
  }
  function uInt64ToString(lo, hi) {
    ({ lo, hi } = toUnsigned(lo, hi));
    if (hi <= 2097151) {
      return String(TWO_PWR_32_DBL * hi + lo);
    }
    const low = lo & 16777215;
    const mid = (lo >>> 24 | hi << 8) & 16777215;
    const high = hi >> 16 & 65535;
    let digitA = low + mid * 6777216 + high * 6710656;
    let digitB = mid + high * 8147497;
    let digitC = high * 2;
    const base = 1e7;
    if (digitA >= base) {
      digitB += Math.floor(digitA / base);
      digitA %= base;
    }
    if (digitB >= base) {
      digitC += Math.floor(digitB / base);
      digitB %= base;
    }
    return digitC.toString() + decimalFrom1e7WithLeadingZeros(digitB) + decimalFrom1e7WithLeadingZeros(digitA);
  }
  function toUnsigned(lo, hi) {
    return { lo: lo >>> 0, hi: hi >>> 0 };
  }
  function newBits(lo, hi) {
    return { lo: lo | 0, hi: hi | 0 };
  }
  function negate(lowBits, highBits) {
    highBits = ~highBits;
    if (lowBits) {
      lowBits = ~lowBits + 1;
    } else {
      highBits += 1;
    }
    return newBits(lowBits, highBits);
  }
  var decimalFrom1e7WithLeadingZeros = (digit1e7) => {
    const partial = String(digit1e7);
    return "0000000".slice(partial.length) + partial;
  };
  function varint32write(value, bytes) {
    if (value >>> 0 < 128) {
      bytes.push(value);
      return;
    }
    if (value >= 0) {
      while (value > 127) {
        bytes.push(value & 127 | 128);
        value = value >>> 7;
      }
      bytes.push(value);
    } else {
      for (let i = 0; i < 9; i++) {
        bytes.push(value & 127 | 128);
        value = value >> 7;
      }
      bytes.push(1);
    }
  }
  function varint32read() {
    let b = this.buf[this.pos++];
    if ((b & 128) === 0) {
      this.assertBounds();
      return b;
    }
    let result = b & 127;
    b = this.buf[this.pos++];
    result |= (b & 127) << 7;
    if ((b & 128) === 0) {
      this.assertBounds();
      return result;
    }
    b = this.buf[this.pos++];
    result |= (b & 127) << 14;
    if ((b & 128) === 0) {
      this.assertBounds();
      return result;
    }
    b = this.buf[this.pos++];
    result |= (b & 127) << 21;
    if ((b & 128) === 0) {
      this.assertBounds();
      return result;
    }
    b = this.buf[this.pos++];
    result |= (b & 15) << 28;
    for (let readBytes = 5; (b & 128) !== 0 && readBytes < 10; readBytes++)
      b = this.buf[this.pos++];
    if ((b & 128) !== 0)
      throw new Error("invalid varint");
    this.assertBounds();
    return result >>> 0;
  }

  // client/node_modules/@bufbuild/protobuf/dist/esm/proto-int64.js
  var protoInt64 = /* @__PURE__ */ makeInt64Support();
  function makeInt64Support() {
    const dv = new DataView(new ArrayBuffer(8));
    const ok = typeof BigInt === "function" && typeof dv.getBigInt64 === "function" && typeof dv.getBigUint64 === "function" && typeof dv.setBigInt64 === "function" && typeof dv.setBigUint64 === "function" && (!!globalThis.Deno || !!globalThis.Bun || typeof process != "object" || typeof process.env != "object" || process.env.BUF_BIGINT_DISABLE !== "1");
    if (ok) {
      const MIN = BigInt("-9223372036854775808");
      const MAX = BigInt("9223372036854775807");
      const UMIN = BigInt("0");
      const UMAX = BigInt("18446744073709551615");
      return {
        zero: BigInt(0),
        supported: true,
        parse(value) {
          const bi = typeof value == "bigint" ? value : BigInt(value);
          if (bi > MAX || bi < MIN) {
            throw new Error(`invalid int64: ${value}`);
          }
          return bi;
        },
        uParse(value) {
          const bi = typeof value == "bigint" ? value : BigInt(value);
          if (bi > UMAX || bi < UMIN) {
            throw new Error(`invalid uint64: ${value}`);
          }
          return bi;
        },
        enc(value) {
          dv.setBigInt64(0, this.parse(value), true);
          return {
            lo: dv.getInt32(0, true),
            hi: dv.getInt32(4, true)
          };
        },
        uEnc(value) {
          dv.setBigInt64(0, this.uParse(value), true);
          return {
            lo: dv.getInt32(0, true),
            hi: dv.getInt32(4, true)
          };
        },
        dec(lo, hi) {
          dv.setInt32(0, lo, true);
          dv.setInt32(4, hi, true);
          return dv.getBigInt64(0, true);
        },
        uDec(lo, hi) {
          dv.setInt32(0, lo, true);
          dv.setInt32(4, hi, true);
          return dv.getBigUint64(0, true);
        }
      };
    }
    return {
      zero: "0",
      supported: false,
      parse(value) {
        if (typeof value != "string") {
          value = value.toString();
        }
        assertInt64String(value);
        return value;
      },
      uParse(value) {
        if (typeof value != "string") {
          value = value.toString();
        }
        assertUInt64String(value);
        return value;
      },
      enc(value) {
        if (typeof value != "string") {
          value = value.toString();
        }
        assertInt64String(value);
        return int64FromString(value);
      },
      uEnc(value) {
        if (typeof value != "string") {
          value = value.toString();
        }
        assertUInt64String(value);
        return int64FromString(value);
      },
      dec(lo, hi) {
        return int64ToString(lo, hi);
      },
      uDec(lo, hi) {
        return uInt64ToString(lo, hi);
      }
    };
  }
  function assertInt64String(value) {
    if (!/^-?[0-9]+$/.test(value)) {
      throw new Error("invalid int64: " + value);
    }
  }
  function assertUInt64String(value) {
    if (!/^[0-9]+$/.test(value)) {
      throw new Error("invalid uint64: " + value);
    }
  }

  // client/node_modules/@bufbuild/protobuf/dist/esm/reflect/scalar.js
  function scalarZeroValue(type, longAsString) {
    switch (type) {
      case ScalarType.STRING:
        return "";
      case ScalarType.BOOL:
        return false;
      case ScalarType.DOUBLE:
      case ScalarType.FLOAT:
        return 0;
      case ScalarType.INT64:
      case ScalarType.UINT64:
      case ScalarType.SFIXED64:
      case ScalarType.FIXED64:
      case ScalarType.SINT64:
        return longAsString ? "0" : protoInt64.zero;
      case ScalarType.BYTES:
        return new Uint8Array(0);
      default:
        return 0;
    }
  }
  function isScalarZeroValue(type, value) {
    switch (type) {
      case ScalarType.BOOL:
        return value === false;
      case ScalarType.STRING:
        return value === "";
      case ScalarType.BYTES:
        return value instanceof Uint8Array && !value.byteLength;
      case ScalarType.DOUBLE:
      case ScalarType.FLOAT:
        return Object.is(value, 0);
      default:
        return value == 0;
    }
  }

  // client/node_modules/@bufbuild/protobuf/dist/esm/reflect/unsafe.js
  var IMPLICIT = 2;
  var unsafeLocal = /* @__PURE__ */ Symbol.for("reflect unsafe local");
  function unsafeOneofCase(target, oneof) {
    const c = target[oneof.localName].case;
    if (c === void 0) {
      return c;
    }
    return oneof.fields.find((f) => f.localName === c);
  }
  function unsafeIsSet(target, field) {
    const name = field.localName;
    if (field.oneof) {
      return target[field.oneof.localName].case === name;
    }
    if (field.presence != IMPLICIT) {
      return target[name] !== void 0 && Object.prototype.hasOwnProperty.call(target, name);
    }
    switch (field.fieldKind) {
      case "list":
        return target[name].length > 0;
      case "map":
        return Object.keys(target[name]).length > 0;
      case "scalar":
        return !isScalarZeroValue(field.scalar, target[name]);
      case "enum":
        return target[name] !== field.enum.values[0].number;
    }
    throw new Error("message field with implicit presence");
  }
  function unsafeIsSetExplicit(target, localName) {
    return Object.prototype.hasOwnProperty.call(target, localName) && target[localName] !== void 0;
  }
  function unsafeGet(target, field) {
    if (field.oneof) {
      const oneof = target[field.oneof.localName];
      if (oneof.case === field.localName) {
        return oneof.value;
      }
      return void 0;
    }
    return target[field.localName];
  }
  function unsafeSet(target, field, value) {
    if (field.oneof) {
      target[field.oneof.localName] = {
        case: field.localName,
        value
      };
    } else {
      target[field.localName] = value;
    }
  }
  function unsafeClear(target, field) {
    const name = field.localName;
    if (field.oneof) {
      const oneofLocalName = field.oneof.localName;
      if (target[oneofLocalName].case === name) {
        target[oneofLocalName] = { case: void 0 };
      }
    } else if (field.presence != IMPLICIT) {
      delete target[name];
    } else {
      switch (field.fieldKind) {
        case "map":
          target[name] = {};
          break;
        case "list":
          target[name] = [];
          break;
        case "enum":
          target[name] = field.enum.values[0].number;
          break;
        case "scalar":
          target[name] = scalarZeroValue(field.scalar, field.longAsString);
          break;
      }
    }
  }

  // client/node_modules/@bufbuild/protobuf/dist/esm/reflect/guard.js
  function isObject(arg) {
    return arg !== null && typeof arg == "object" && !Array.isArray(arg);
  }
  function isReflectList(arg, field) {
    var _a, _b, _c, _d;
    if (isObject(arg) && unsafeLocal in arg && "add" in arg && "field" in arg && typeof arg.field == "function") {
      if (field !== void 0) {
        const a = field;
        const b = arg.field();
        return a.listKind == b.listKind && a.scalar === b.scalar && ((_a = a.message) === null || _a === void 0 ? void 0 : _a.typeName) === ((_b = b.message) === null || _b === void 0 ? void 0 : _b.typeName) && ((_c = a.enum) === null || _c === void 0 ? void 0 : _c.typeName) === ((_d = b.enum) === null || _d === void 0 ? void 0 : _d.typeName);
      }
      return true;
    }
    return false;
  }
  function isReflectMap(arg, field) {
    var _a, _b, _c, _d;
    if (isObject(arg) && unsafeLocal in arg && "has" in arg && "field" in arg && typeof arg.field == "function") {
      if (field !== void 0) {
        const a = field, b = arg.field();
        return a.mapKey === b.mapKey && a.mapKind == b.mapKind && a.scalar === b.scalar && ((_a = a.message) === null || _a === void 0 ? void 0 : _a.typeName) === ((_b = b.message) === null || _b === void 0 ? void 0 : _b.typeName) && ((_c = a.enum) === null || _c === void 0 ? void 0 : _c.typeName) === ((_d = b.enum) === null || _d === void 0 ? void 0 : _d.typeName);
      }
      return true;
    }
    return false;
  }
  function isReflectMessage(arg, messageDesc2) {
    return isObject(arg) && unsafeLocal in arg && "desc" in arg && isObject(arg.desc) && arg.desc.kind === "message" && (messageDesc2 === void 0 || arg.desc.typeName == messageDesc2.typeName);
  }

  // client/node_modules/@bufbuild/protobuf/dist/esm/wkt/wrappers.js
  function isWrapper(arg) {
    return isWrapperTypeName(arg.$typeName);
  }
  function isWrapperDesc(messageDesc2) {
    const f = messageDesc2.fields[0];
    return isWrapperTypeName(messageDesc2.typeName) && f !== void 0 && f.fieldKind == "scalar" && f.name == "value" && f.number == 1;
  }
  function hasCustomJsonRepresentation(desc) {
    switch (desc.typeName) {
      case "google.protobuf.Any":
      case "google.protobuf.Timestamp":
      case "google.protobuf.Duration":
      case "google.protobuf.FieldMask":
      case "google.protobuf.Struct":
      case "google.protobuf.Value":
      case "google.protobuf.ListValue":
        return true;
      default:
        return isWrapperDesc(desc);
    }
  }
  var wrapperTypeNames = /* @__PURE__ */ new Set([
    "google.protobuf.DoubleValue",
    "google.protobuf.FloatValue",
    "google.protobuf.Int64Value",
    "google.protobuf.UInt64Value",
    "google.protobuf.Int32Value",
    "google.protobuf.UInt32Value",
    "google.protobuf.BoolValue",
    "google.protobuf.StringValue",
    "google.protobuf.BytesValue"
  ]);
  function isWrapperTypeName(name) {
    return wrapperTypeNames.has(name);
  }

  // client/node_modules/@bufbuild/protobuf/dist/esm/create.js
  var EDITION_PROTO3 = 999;
  var EDITION_PROTO2 = 998;
  var IMPLICIT2 = 2;
  function create(schema, init) {
    if (isMessage(init, schema)) {
      return init;
    }
    return compiledCreate(schema)(init);
  }
  var compiledCreates = /* @__PURE__ */ new WeakMap();
  function compiledCreate(desc) {
    let compiled = compiledCreates.get(desc);
    if (compiled === void 0) {
      compiled = compileCreate(desc);
      compiledCreates.set(desc, compiled);
    }
    return compiled;
  }
  var INIT_SINGULAR = 0;
  var INIT_LIST = 1;
  var INIT_MAP = 2;
  var INIT_ONEOF = 3;
  function compileCreate(desc) {
    const typeName = desc.typeName;
    const { properties, prototype } = compileInitMessage(desc);
    return (init) => {
      let message2;
      if (prototype !== void 0) {
        message2 = Object.create(prototype);
        message2.$typeName = typeName;
      } else {
        message2 = { $typeName: typeName };
      }
      for (let i = 0; i < properties.length; i++) {
        const property = properties[i];
        const name = property.name;
        const initValue = init === null || init === void 0 ? void 0 : init[name];
        switch (property.kind) {
          case INIT_SINGULAR:
            if (initValue != null) {
              message2[name] = property.convert !== void 0 ? property.convert(initValue) : initValue;
            } else if (property.constant !== void 0) {
              message2[name] = property.constant;
            }
            break;
          case INIT_LIST:
            message2[name] = property.convert !== void 0 && Array.isArray(initValue) ? initValue.map(property.convert) : initValue !== null && initValue !== void 0 ? initValue : [];
            break;
          case INIT_MAP:
            if (property.convert === void 0 || !isObject(initValue)) {
              message2[name] = initValue !== null && initValue !== void 0 ? initValue : {};
            } else {
              const converted = {};
              const keys = Object.keys(initValue);
              for (let k = 0; k < keys.length; k++) {
                converted[keys[k]] = property.convert(initValue[keys[k]]);
              }
              message2[name] = converted;
            }
            break;
          case INIT_ONEOF: {
            const oneofValue = initValue;
            if ((oneofValue === null || oneofValue === void 0 ? void 0 : oneofValue.case) != null) {
              const convert = property.convert.get(oneofValue.case);
              if (convert !== void 0) {
                message2[name] = {
                  case: oneofValue.case,
                  value: convert(oneofValue.value)
                };
                break;
              }
            }
            message2[name] = { case: void 0 };
            break;
          }
        }
      }
      return message2;
    };
  }
  function compileInitMessage(desc) {
    var _a, _b;
    const properties = [];
    const prototype = {};
    const usePrototype = needsPrototypeChain(desc);
    for (const member of desc.members) {
      const name = member.localName;
      if (member.kind == "oneof") {
        properties.push({
          name,
          kind: INIT_ONEOF,
          constant: void 0,
          convert: compileConvertOneof(member)
        });
        continue;
      }
      switch (member.fieldKind) {
        case "message": {
          properties.push({
            name,
            kind: INIT_SINGULAR,
            constant: void 0,
            convert: compileConvertMessage(member)
          });
          break;
        }
        case "list": {
          properties.push({
            name,
            kind: INIT_LIST,
            constant: void 0,
            convert: member.listKind == "message" ? (_a = compileConvertMessage(member)) !== null && _a !== void 0 ? _a : ((value) => value) : member.scalar == ScalarType.BYTES ? toU8Arr : void 0
          });
          break;
        }
        case "map": {
          properties.push({
            name,
            kind: INIT_MAP,
            constant: void 0,
            convert: member.mapKind == "message" ? (_b = compileConvertMessage(member)) !== null && _b !== void 0 ? _b : ((value) => value) : member.scalar == ScalarType.BYTES ? toU8Arr : void 0
          });
          break;
        }
        default: {
          const zeroValue = createZeroValue(member);
          properties.push({
            name,
            kind: INIT_SINGULAR,
            constant: member.presence == IMPLICIT2 ? zeroValue : void 0,
            convert: member.fieldKind == "scalar" && member.scalar == ScalarType.BYTES ? toU8Arr : void 0
          });
          if (usePrototype) {
            prototype[name] = zeroValue;
          }
          break;
        }
      }
    }
    return {
      properties,
      prototype: usePrototype ? prototype : void 0
    };
  }
  function compileConvertOneof(oneof) {
    const converters = /* @__PURE__ */ new Map();
    for (const field of oneof.fields) {
      let convert;
      if (field.fieldKind == "message") {
        convert = compileConvertMessage(field);
      } else if (field.fieldKind == "scalar" && field.scalar == ScalarType.BYTES) {
        convert = toU8Arr;
      }
      converters.set(field.localName, convert !== null && convert !== void 0 ? convert : ((value) => value));
    }
    return converters;
  }
  function compileConvertMessage(field) {
    if (field.fieldKind == "message" && !field.oneof && isWrapperDesc(field.message)) {
      return field.message.fields[0].scalar == ScalarType.BYTES ? toU8Arr : void 0;
    }
    if (field.message.typeName == "google.protobuf.Struct" && field.parent.typeName !== "google.protobuf.Value") {
      return void 0;
    }
    const messageDesc2 = field.message;
    let compiled;
    return (value) => {
      if (!isObject(value) || isMessage(value, messageDesc2)) {
        return value;
      }
      compiled !== null && compiled !== void 0 ? compiled : compiled = compiledCreate(messageDesc2);
      return compiled(value);
    };
  }
  function toU8Arr(value) {
    return Array.isArray(value) ? new Uint8Array(value) : value;
  }
  function needsPrototypeChain(desc) {
    switch (desc.file.edition) {
      case EDITION_PROTO3:
        return false;
      case EDITION_PROTO2:
        return true;
      default:
        return desc.fields.some((f) => f.presence != IMPLICIT2 && f.fieldKind != "message" && !f.oneof);
    }
  }
  function createZeroValue(field) {
    const defaultValue = field.getDefaultValue();
    if (defaultValue !== void 0) {
      return field.fieldKind == "scalar" && field.longAsString ? defaultValue.toString() : defaultValue;
    }
    return field.fieldKind == "scalar" ? scalarZeroValue(field.scalar, field.longAsString) : field.enum.values[0].number;
  }

  // client/node_modules/@bufbuild/protobuf/dist/esm/reflect/error.js
  var FieldError = class extends Error {
    constructor(fieldOrOneof, message2, name = "FieldValueInvalidError") {
      super(message2);
      this.name = name;
      this.field = () => fieldOrOneof;
    }
  };

  // client/node_modules/@bufbuild/protobuf/dist/esm/wire/text-encoding.js
  var te;
  function configureTextEncoding(textEncoding) {
    var _a;
    te = Object.assign(Object.assign({}, textEncoding), { encodeUtf8Into: (_a = textEncoding.encodeUtf8Into) !== null && _a !== void 0 ? _a : emulateEncodeInto(textEncoding.encodeUtf8.bind(textEncoding)) });
  }
  function getTextEncoding() {
    if (!te) {
      const globals = globalThis;
      if (!globals.TextEncoder || !globals.TextDecoder) {
        throw new Error("encoding API missing: install TextEncoder and TextDecoder on globalThis");
      }
      const textEncoder = new globals.TextEncoder();
      const textDecoder = new globals.TextDecoder();
      let textDecoderStrict;
      const config = {
        encodeUtf8(text) {
          return textEncoder.encode(text);
        },
        decodeUtf8(bytes, strict) {
          if (strict) {
            if (!textDecoderStrict) {
              textDecoderStrict = new globals.TextDecoder("utf-8", {
                fatal: true
              });
            }
            return textDecoderStrict.decode(bytes);
          }
          return textDecoder.decode(bytes);
        },
        checkUtf8(text) {
          try {
            encodeURIComponent(text);
            return true;
          } catch (_) {
            return false;
          }
        }
      };
      if (textEncoder.encodeInto) {
        config.encodeUtf8Into = textEncoder.encodeInto.bind(textEncoder);
      }
      const nativeStringIsWellFormed = String.prototype.isWellFormed;
      if (nativeStringIsWellFormed) {
        config.checkUtf8 = (text) => {
          return nativeStringIsWellFormed.call(text);
        };
      }
      configureTextEncoding(config);
    }
    return te;
  }
  function emulateEncodeInto(encodeUtf8) {
    return (text, dest) => {
      const bytes = encodeUtf8(text);
      dest.set(bytes);
      return { written: bytes.byteLength };
    };
  }

  // client/node_modules/@bufbuild/protobuf/dist/esm/wire/binary-encoding.js
  var WireType;
  (function(WireType2) {
    WireType2[WireType2["Varint"] = 0] = "Varint";
    WireType2[WireType2["Bit64"] = 1] = "Bit64";
    WireType2[WireType2["LengthDelimited"] = 2] = "LengthDelimited";
    WireType2[WireType2["StartGroup"] = 3] = "StartGroup";
    WireType2[WireType2["EndGroup"] = 4] = "EndGroup";
    WireType2[WireType2["Bit32"] = 5] = "Bit32";
  })(WireType || (WireType = {}));
  var FLOAT32_MAX = 34028234663852886e22;
  var FLOAT32_MIN = -34028234663852886e22;
  var UINT32_MAX = 4294967295;
  var INT32_MAX = 2147483647;
  var INT32_MIN = -2147483648;
  var EMPTY_BUFFER = new Uint8Array(0);
  var EMPTY_VIEW = new DataView(EMPTY_BUFFER.buffer);
  var ASCII_MAX_LENGTH = 32;
  var BinaryReader = class {
    constructor(buf, decodeUtf8 = getTextEncoding().decodeUtf8) {
      this.decodeUtf8 = decodeUtf8;
      this.varint64Lo = 0;
      this.varint64Hi = 0;
      this.varint64 = varint64read;
      this.uint32 = varint32read;
      this.buf = buf;
      this.len = buf.length;
      this.pos = 0;
      this.view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
    }
    /**
     * Reads a tag - field number and wire type. Tags are uint32 varints; values
     * that do not fit in uint32 are rejected.
     */
    tag() {
      const start = this.pos;
      const tag = this.uint32();
      const bytesRead = this.pos - start;
      if (bytesRead > 5 || bytesRead == 5 && this.buf[this.pos - 1] > 15) {
        throw new Error("illegal tag: varint overflows uint32");
      }
      const fieldNo = tag >>> 3;
      const wireType = tag & 7;
      if (fieldNo <= 0 || wireType > 5) {
        throw new Error("illegal tag: field no " + fieldNo + " wire type " + wireType);
      }
      return [fieldNo, wireType];
    }
    /**
     * Skip one element and return the skipped data.
     *
     * When skipping StartGroup, provide the tags field number to check for
     * matching field number in the EndGroup tag. Recursion into nested groups
     * is guarded by the `recursionLimit` argument: When the limit is reached,
     * this method throws.
     */
    skip(wireType, fieldNo, recursionLimit = 100) {
      let start = this.pos;
      switch (wireType) {
        case WireType.Varint:
          while (this.buf[this.pos++] & 128) {
          }
          break;
        // @ts-ignore TS7029: Fallthrough case in switch -- ignore instead of expect-error for compiler settings without noFallthroughCasesInSwitch: true
        case WireType.Bit64:
          this.pos += 4;
        case WireType.Bit32:
          this.pos += 4;
          break;
        case WireType.LengthDelimited:
          let len = this.uint32();
          this.pos += len;
          break;
        case WireType.StartGroup:
          if (recursionLimit <= 0) {
            throw new Error("maximum recursion depth reached");
          }
          for (; ; ) {
            const [fn, wt] = this.tag();
            if (wt === WireType.EndGroup) {
              if (fieldNo !== void 0 && fn !== fieldNo) {
                throw new Error("invalid end group tag");
              }
              break;
            }
            this.skip(wt, fn, recursionLimit - 1);
          }
          break;
        default:
          throw new Error("cant skip wire type " + wireType);
      }
      this.assertBounds();
      return this.buf.subarray(start, this.pos);
    }
    /**
     * Throws error if position in byte array is out of range.
     */
    assertBounds() {
      if (this.pos > this.len)
        throw new RangeError("premature EOF");
    }
    /**
     * Read a `int32` field, a signed 32 bit varint.
     */
    int32() {
      return this.uint32() | 0;
    }
    /**
     * Read a `sint32` field, a signed, zigzag-encoded 32-bit varint.
     */
    sint32() {
      let zze = this.uint32();
      return zze >>> 1 ^ -(zze & 1);
    }
    /**
     * Read a `int64` field, a signed 64-bit varint.
     */
    int64() {
      this.varint64();
      return protoInt64.dec(this.varint64Lo, this.varint64Hi);
    }
    /**
     * Read a `uint64` field, an unsigned 64-bit varint.
     */
    uint64() {
      this.varint64();
      return protoInt64.uDec(this.varint64Lo, this.varint64Hi);
    }
    /**
     * Read a `sint64` field, a signed, zig-zag-encoded 64-bit varint.
     */
    sint64() {
      this.varint64();
      let lo = this.varint64Lo;
      let hi = this.varint64Hi;
      let s = -(lo & 1);
      lo = (lo >>> 1 | (hi & 1) << 31) ^ s;
      hi = hi >>> 1 ^ s;
      return protoInt64.dec(lo, hi);
    }
    /**
     * Read a `bool` field, a variant.
     */
    bool() {
      const b = this.buf[this.pos];
      if (b < 128) {
        this.pos++;
        return b !== 0;
      }
      this.varint64();
      return this.varint64Lo !== 0 || this.varint64Hi !== 0;
    }
    /**
     * Read a `fixed32` field, an unsigned, fixed-length 32-bit integer.
     */
    fixed32() {
      return this.view.getUint32((this.pos += 4) - 4, true);
    }
    /**
     * Read a `sfixed32` field, a signed, fixed-length 32-bit integer.
     */
    sfixed32() {
      return this.view.getInt32((this.pos += 4) - 4, true);
    }
    /**
     * Read a `fixed64` field, an unsigned, fixed-length 64 bit integer.
     */
    fixed64() {
      return protoInt64.uDec(this.sfixed32(), this.sfixed32());
    }
    /**
     * Read a `fixed64` field, a signed, fixed-length 64-bit integer.
     */
    sfixed64() {
      return protoInt64.dec(this.sfixed32(), this.sfixed32());
    }
    /**
     * Read a `float` field, 32-bit floating point number.
     */
    float() {
      return this.view.getFloat32((this.pos += 4) - 4, true);
    }
    /**
     * Read a `double` field, a 64-bit floating point number.
     */
    double() {
      return this.view.getFloat64((this.pos += 8) - 8, true);
    }
    /**
     * Read a `bytes` field, length-delimited arbitrary data.
     */
    bytes() {
      let len = this.uint32(), start = this.pos;
      this.pos += len;
      this.assertBounds();
      return this.buf.subarray(start, start + len);
    }
    /**
     * Read a `string` field, length-delimited data converted to UTF-8 text. If
     * `strict` is true, throw on invalid UTF-8 instead of substituting U+FFFD.
     */
    string(strict) {
      const bytes = this.bytes();
      const len = bytes.length;
      if (len <= ASCII_MAX_LENGTH) {
        const codes = new Array(len);
        for (let i = 0; i < len; i++) {
          const byte = bytes[i];
          if (byte > 127) {
            return this.decodeUtf8(bytes, strict);
          }
          codes[i] = byte;
        }
        return String.fromCharCode.apply(String, codes);
      }
      return this.decodeUtf8(bytes, strict);
    }
  };

  // client/node_modules/@bufbuild/protobuf/dist/esm/reflect/reflect-check.js
  function checkField(field, value) {
    const check = field.fieldKind == "list" ? isReflectList(value, field) : field.fieldKind == "map" ? isReflectMap(value, field) : checkSingular(field, value);
    if (check === true) {
      return void 0;
    }
    let reason;
    switch (field.fieldKind) {
      case "list":
        reason = `expected ${formatReflectList(field)}, got ${formatVal(value)}`;
        break;
      case "map":
        reason = `expected ${formatReflectMap(field)}, got ${formatVal(value)}`;
        break;
      default: {
        reason = reasonSingular(field, value, check);
      }
    }
    return new FieldError(field, reason);
  }
  function checkListItem(field, index, value) {
    const check = checkSingular(field, value);
    if (check !== true) {
      return new FieldError(field, `list item #${index + 1}: ${reasonSingular(field, value, check)}`);
    }
    return void 0;
  }
  function checkMapEntry(field, key, value) {
    const checkKey = checkScalarValue(field.mapKey)(key);
    if (checkKey !== true) {
      return new FieldError(field, `invalid map key: ${reasonSingular({ scalar: field.mapKey }, key, checkKey)}`);
    }
    const checkVal = checkSingular(field, value);
    if (checkVal !== true) {
      return new FieldError(field, `map entry ${formatVal(key)}: ${reasonSingular(field, value, checkVal)}`);
    }
    return void 0;
  }
  function checkSingular(field, value) {
    if (field.scalar !== void 0) {
      return checkScalarValue(field.scalar)(value);
    }
    if (field.enum !== void 0) {
      if (field.enum.open) {
        return checkScalarValue(ScalarType.INT32)(value);
      }
      return field.enum.values.some((v) => v.number === value);
    }
    return isReflectMessage(value, field.message);
  }
  function checkScalarValue(scalar) {
    switch (scalar) {
      case ScalarType.DOUBLE:
        return (value) => typeof value == "number";
      case ScalarType.FLOAT:
        return (value) => {
          if (typeof value != "number") {
            return false;
          }
          if (Number.isNaN(value) || !Number.isFinite(value)) {
            return true;
          }
          if (value > FLOAT32_MAX || value < FLOAT32_MIN) {
            return `${value.toFixed()} out of range`;
          }
          return true;
        };
      case ScalarType.INT32:
      case ScalarType.SFIXED32:
      case ScalarType.SINT32:
        return (value) => {
          if (typeof value !== "number" || !Number.isInteger(value)) {
            return false;
          }
          if (value > INT32_MAX || value < INT32_MIN) {
            return `${value.toFixed()} out of range`;
          }
          return true;
        };
      case ScalarType.FIXED32:
      case ScalarType.UINT32:
        return (value) => {
          if (typeof value !== "number" || !Number.isInteger(value)) {
            return false;
          }
          if (value > UINT32_MAX || value < 0) {
            return `${value.toFixed()} out of range`;
          }
          return true;
        };
      case ScalarType.BOOL:
        return (value) => typeof value == "boolean";
      case ScalarType.STRING:
        return (value) => {
          if (typeof value != "string") {
            return false;
          }
          return getTextEncoding().checkUtf8(value) || "invalid UTF8";
        };
      case ScalarType.BYTES:
        return (value) => value instanceof Uint8Array;
      case ScalarType.INT64:
      case ScalarType.SFIXED64:
      case ScalarType.SINT64:
        return (value) => {
          if (typeof value == "bigint" || typeof value == "number" || typeof value == "string" && value.length > 0) {
            try {
              protoInt64.parse(value);
              return true;
            } catch (_) {
              return `${value} out of range`;
            }
          }
          return false;
        };
      case ScalarType.FIXED64:
      case ScalarType.UINT64:
        return (value) => {
          if (typeof value == "bigint" || typeof value == "number" || typeof value == "string" && value.length > 0) {
            try {
              protoInt64.uParse(value);
              return true;
            } catch (_) {
              return `${value} out of range`;
            }
          }
          return false;
        };
    }
  }
  function reasonSingular(field, val, details) {
    details = typeof details == "string" ? `: ${details}` : `, got ${formatVal(val)}`;
    if (field.scalar !== void 0) {
      return `expected ${scalarTypeDescription(field.scalar)}` + details;
    }
    if (field.enum !== void 0) {
      return `expected ${field.enum.toString()}` + details;
    }
    return `expected ${formatReflectMessage(field.message)}` + details;
  }
  function formatVal(val) {
    switch (typeof val) {
      case "object":
        if (val === null) {
          return "null";
        }
        if (val instanceof Uint8Array) {
          return `Uint8Array(${val.length})`;
        }
        if (Array.isArray(val)) {
          return `Array(${val.length})`;
        }
        if (isReflectList(val)) {
          return formatReflectList(val.field());
        }
        if (isReflectMap(val)) {
          return formatReflectMap(val.field());
        }
        if (isReflectMessage(val)) {
          return formatReflectMessage(val.desc);
        }
        if (isMessage(val)) {
          return `message ${val.$typeName}`;
        }
        return "object";
      case "string":
        return val.length > 30 ? "string" : `"${val.split('"').join('\\"')}"`;
      case "boolean":
        return String(val);
      case "number":
        return String(val);
      case "bigint":
        return String(val) + "n";
      default:
        return typeof val;
    }
  }
  function formatReflectMessage(desc) {
    return `ReflectMessage (${desc.typeName})`;
  }
  function formatReflectList(field) {
    switch (field.listKind) {
      case "message":
        return `ReflectList (${field.message.toString()})`;
      case "enum":
        return `ReflectList (${field.enum.toString()})`;
      case "scalar":
        return `ReflectList (${ScalarType[field.scalar]})`;
    }
  }
  function formatReflectMap(field) {
    switch (field.mapKind) {
      case "message":
        return `ReflectMap (${ScalarType[field.mapKey]}, ${field.message.toString()})`;
      case "enum":
        return `ReflectMap (${ScalarType[field.mapKey]}, ${field.enum.toString()})`;
      case "scalar":
        return `ReflectMap (${ScalarType[field.mapKey]}, ${ScalarType[field.scalar]})`;
    }
  }
  function scalarTypeDescription(scalar) {
    switch (scalar) {
      case ScalarType.STRING:
        return "string";
      case ScalarType.BOOL:
        return "boolean";
      case ScalarType.INT64:
      case ScalarType.SINT64:
      case ScalarType.SFIXED64:
        return "bigint (int64)";
      case ScalarType.UINT64:
      case ScalarType.FIXED64:
        return "bigint (uint64)";
      case ScalarType.BYTES:
        return "Uint8Array";
      case ScalarType.DOUBLE:
        return "number (float64)";
      case ScalarType.FLOAT:
        return "number (float32)";
      case ScalarType.FIXED32:
      case ScalarType.UINT32:
        return "number (uint32)";
      case ScalarType.INT32:
      case ScalarType.SFIXED32:
      case ScalarType.SINT32:
        return "number (int32)";
    }
  }

  // client/node_modules/@bufbuild/protobuf/dist/esm/reflect/message.js
  var NULL_VALUE = 0;
  function localMessageMapper(field) {
    if (usesJsonRepresentation(field)) {
      return {
        toMessage: (local) => wktStructToReflect(local),
        toLocal: (message2) => wktStructToLocal(message2)
      };
    }
    if (field.fieldKind == "message" && !field.oneof && isWrapperDesc(field.message)) {
      const wrapperDesc = field.message;
      const valueLocalName = wrapperDesc.fields[0].localName;
      return {
        toMessage: (local) => {
          const message2 = create(wrapperDesc);
          if (local !== void 0) {
            message2[valueLocalName] = local;
          }
          return message2;
        },
        toLocal: (message2) => message2[valueLocalName]
      };
    }
    const childDesc = field.message;
    return {
      toMessage: (local) => local === void 0 ? create(childDesc) : local,
      toLocal: (message2) => message2
    };
  }
  function usesJsonRepresentation(field) {
    return field.message.typeName == "google.protobuf.Struct" && field.parent.typeName != "google.protobuf.Value";
  }
  function wktStructToReflect(json) {
    const struct = {
      $typeName: "google.protobuf.Struct",
      fields: {}
    };
    if (isObject(json)) {
      for (const k of Object.keys(json)) {
        struct.fields[k] = wktValueToReflect(json[k]);
      }
    }
    return struct;
  }
  function wktStructToLocal(val) {
    const json = {};
    for (const k of Object.keys(val.fields)) {
      json[k] = wktValueToLocal(val.fields[k]);
    }
    return json;
  }
  function wktValueToLocal(val) {
    switch (val.kind.case) {
      case "structValue":
        return wktStructToLocal(val.kind.value);
      case "listValue":
        return val.kind.value.values.map(wktValueToLocal);
      case "nullValue":
      case void 0:
        return null;
      default:
        return val.kind.value;
    }
  }
  function wktValueToReflect(json) {
    const value = {
      $typeName: "google.protobuf.Value",
      kind: { case: void 0 }
    };
    switch (typeof json) {
      case "number":
        value.kind = { case: "numberValue", value: json };
        break;
      case "string":
        value.kind = { case: "stringValue", value: json };
        break;
      case "boolean":
        value.kind = { case: "boolValue", value: json };
        break;
      case "object":
        if (json === null) {
          value.kind = { case: "nullValue", value: NULL_VALUE };
        } else if (Array.isArray(json)) {
          const listValue = {
            $typeName: "google.protobuf.ListValue",
            values: []
          };
          if (Array.isArray(json)) {
            for (const e of json) {
              listValue.values.push(wktValueToReflect(e));
            }
          }
          value.kind = {
            case: "listValue",
            value: listValue
          };
        } else {
          value.kind = {
            case: "structValue",
            value: wktStructToReflect(json)
          };
        }
        break;
    }
    return value;
  }

  // client/node_modules/@bufbuild/protobuf/dist/esm/reflect/reflect.js
  function reflect(messageDesc2, message2, check = true) {
    return new ReflectMessageImpl(messageDesc2, message2, check);
  }
  var messageSortedFields = /* @__PURE__ */ new WeakMap();
  var ReflectMessageImpl = class {
    get sortedFields() {
      const cached = messageSortedFields.get(this.desc);
      if (cached) {
        return cached;
      }
      const sortedFields = this.desc.fields.concat().sort((a, b) => a.number - b.number);
      messageSortedFields.set(this.desc, sortedFields);
      return sortedFields;
    }
    constructor(messageDesc2, message2, check = true) {
      this.lists = /* @__PURE__ */ new Map();
      this.maps = /* @__PURE__ */ new Map();
      this.check = check;
      this.desc = messageDesc2;
      this.message = this[unsafeLocal] = message2 !== null && message2 !== void 0 ? message2 : create(messageDesc2);
      this.fields = messageDesc2.fields;
      this.oneofs = messageDesc2.oneofs;
      this.members = messageDesc2.members;
    }
    findNumber(number) {
      if (!this._fieldsByNumber) {
        this._fieldsByNumber = new Map(this.desc.fields.map((f) => [f.number, f]));
      }
      return this._fieldsByNumber.get(number);
    }
    oneofCase(oneof) {
      assertOwn(this.message, oneof);
      return unsafeOneofCase(this.message, oneof);
    }
    isSet(field) {
      assertOwn(this.message, field);
      return unsafeIsSet(this.message, field);
    }
    clear(field) {
      assertOwn(this.message, field);
      unsafeClear(this.message, field);
    }
    get(field) {
      assertOwn(this.message, field);
      const value = unsafeGet(this.message, field);
      switch (field.fieldKind) {
        case "list":
          let list = this.lists.get(field);
          if (!list || list[unsafeLocal] !== value) {
            this.lists.set(
              field,
              // biome-ignore lint/suspicious/noAssignInExpressions: no
              list = new ReflectListImpl(field, value, this.check)
            );
          }
          return list;
        case "map":
          let map = this.maps.get(field);
          if (!map || map[unsafeLocal] !== value) {
            this.maps.set(
              field,
              // biome-ignore lint/suspicious/noAssignInExpressions: no
              map = new ReflectMapImpl(field, value, this.check)
            );
          }
          return map;
        case "message":
          return messageToReflect(field, value, this.check);
        case "scalar":
          return value === void 0 ? scalarZeroValue(field.scalar, false) : longToReflect(field, value);
        case "enum":
          return value !== null && value !== void 0 ? value : field.enum.values[0].number;
      }
    }
    set(field, value) {
      assertOwn(this.message, field);
      if (this.check) {
        const err = checkField(field, value);
        if (err) {
          throw err;
        }
      }
      let local;
      if (field.fieldKind == "message") {
        local = messageToLocal(field, value);
      } else if (isReflectMap(value) || isReflectList(value)) {
        local = value[unsafeLocal];
      } else {
        local = longToLocal(field, value);
      }
      unsafeSet(this.message, field, local);
    }
    getUnknown() {
      return this.message.$unknown;
    }
    setUnknown(value) {
      this.message.$unknown = value;
    }
  };
  function assertOwn(owner, member) {
    if (member.parent.typeName !== owner.$typeName) {
      throw new FieldError(member, `cannot use ${member.toString()} with message ${owner.$typeName}`, "ForeignFieldError");
    }
  }
  var ReflectListImpl = class {
    field() {
      return this._field;
    }
    get size() {
      return this._arr.length;
    }
    constructor(field, unsafeInput, check) {
      this._field = field;
      this._arr = this[unsafeLocal] = unsafeInput;
      this.check = check;
    }
    get(index) {
      const item = this._arr[index];
      return item === void 0 ? void 0 : listItemToReflect(this._field, item, this.check);
    }
    set(index, item) {
      if (index < 0 || index >= this._arr.length) {
        throw new FieldError(this._field, `list item #${index + 1}: out of range`);
      }
      if (this.check) {
        const err = checkListItem(this._field, index, item);
        if (err) {
          throw err;
        }
      }
      this._arr[index] = listItemToLocal(this._field, item);
    }
    add(item) {
      if (this.check) {
        const err = checkListItem(this._field, this._arr.length, item);
        if (err) {
          throw err;
        }
      }
      this._arr.push(listItemToLocal(this._field, item));
      return void 0;
    }
    clear() {
      this._arr.splice(0, this._arr.length);
    }
    [Symbol.iterator]() {
      return this.values();
    }
    keys() {
      return this._arr.keys();
    }
    *values() {
      for (const item of this._arr) {
        yield listItemToReflect(this._field, item, this.check);
      }
    }
    *entries() {
      for (let i = 0; i < this._arr.length; i++) {
        yield [i, listItemToReflect(this._field, this._arr[i], this.check)];
      }
    }
  };
  var ReflectMapImpl = class {
    constructor(field, unsafeInput, check = true) {
      this.obj = this[unsafeLocal] = unsafeInput !== null && unsafeInput !== void 0 ? unsafeInput : {};
      this.check = check;
      this._field = field;
    }
    field() {
      return this._field;
    }
    set(key, value) {
      if (this.check) {
        const err = checkMapEntry(this._field, key, value);
        if (err) {
          throw err;
        }
      }
      this.obj[mapKeyToLocal(key)] = mapValueToLocal(this._field, value);
      return this;
    }
    delete(key) {
      const k = mapKeyToLocal(key);
      const has = Object.prototype.hasOwnProperty.call(this.obj, k);
      if (has) {
        delete this.obj[k];
      }
      return has;
    }
    clear() {
      for (const key of Object.keys(this.obj)) {
        delete this.obj[key];
      }
    }
    get(key) {
      let val = this.obj[mapKeyToLocal(key)];
      if (val !== void 0) {
        val = mapValueToReflect(this._field, val, this.check);
      }
      return val;
    }
    has(key) {
      return Object.prototype.hasOwnProperty.call(this.obj, mapKeyToLocal(key));
    }
    *keys() {
      for (const objKey of Object.keys(this.obj)) {
        yield mapKeyToReflect(objKey, this._field.mapKey);
      }
    }
    *entries() {
      for (const objEntry of Object.entries(this.obj)) {
        yield [
          mapKeyToReflect(objEntry[0], this._field.mapKey),
          mapValueToReflect(this._field, objEntry[1], this.check)
        ];
      }
    }
    [Symbol.iterator]() {
      return this.entries();
    }
    get size() {
      return Object.keys(this.obj).length;
    }
    *values() {
      for (const val of Object.values(this.obj)) {
        yield mapValueToReflect(this._field, val, this.check);
      }
    }
    forEach(callbackfn, thisArg) {
      for (const mapEntry of this.entries()) {
        callbackfn.call(thisArg, mapEntry[1], mapEntry[0], this);
      }
    }
  };
  function messageToLocal(field, value) {
    if (!isReflectMessage(value)) {
      return value;
    }
    if (isWrapper(value.message) && !field.oneof && field.fieldKind == "message") {
      return value.message.value;
    }
    if (value.desc.typeName == "google.protobuf.Struct" && field.parent.typeName != "google.protobuf.Value") {
      return wktStructToLocal(value.message);
    }
    return value.message;
  }
  function messageToReflect(field, value, check) {
    if (value !== void 0) {
      if (isWrapperDesc(field.message) && !field.oneof && field.fieldKind == "message") {
        value = {
          $typeName: field.message.typeName,
          value: longToReflect(field.message.fields[0], value)
        };
      } else if (field.message.typeName == "google.protobuf.Struct" && field.parent.typeName != "google.protobuf.Value" && isObject(value)) {
        value = wktStructToReflect(value);
      }
    }
    return new ReflectMessageImpl(field.message, value, check);
  }
  function listItemToLocal(field, value) {
    if (field.listKind == "message") {
      return messageToLocal(field, value);
    }
    return longToLocal(field, value);
  }
  function listItemToReflect(field, value, check) {
    if (field.listKind == "message") {
      return messageToReflect(field, value, check);
    }
    return longToReflect(field, value);
  }
  function mapValueToLocal(field, value) {
    if (field.mapKind == "message") {
      return messageToLocal(field, value);
    }
    return longToLocal(field, value);
  }
  function mapValueToReflect(field, value, check) {
    if (field.mapKind == "message") {
      return messageToReflect(field, value, check);
    }
    return value;
  }
  function mapKeyToLocal(key) {
    return typeof key == "string" || typeof key == "number" ? key : String(key);
  }
  function mapKeyToReflect(key, type) {
    switch (type) {
      case ScalarType.STRING:
        return key;
      case ScalarType.INT32:
      case ScalarType.FIXED32:
      case ScalarType.UINT32:
      case ScalarType.SFIXED32:
      case ScalarType.SINT32: {
        const n = Number.parseInt(key);
        if (Number.isFinite(n)) {
          return n;
        }
        break;
      }
      case ScalarType.BOOL:
        switch (key) {
          case "true":
            return true;
          case "false":
            return false;
        }
        break;
      case ScalarType.UINT64:
      case ScalarType.FIXED64:
        try {
          return protoInt64.uParse(key);
        } catch (_a) {
        }
        break;
      default:
        try {
          return protoInt64.parse(key);
        } catch (_b) {
        }
        break;
    }
    return key;
  }
  function longToReflect(field, value) {
    switch (field.scalar) {
      case ScalarType.INT64:
      case ScalarType.SFIXED64:
      case ScalarType.SINT64:
        if ("longAsString" in field && field.longAsString && typeof value == "string") {
          value = protoInt64.parse(value);
        }
        break;
      case ScalarType.FIXED64:
      case ScalarType.UINT64:
        if ("longAsString" in field && field.longAsString && typeof value == "string") {
          value = protoInt64.uParse(value);
        }
        break;
    }
    return value;
  }
  function longToLocal(field, value) {
    switch (field.scalar) {
      case ScalarType.INT64:
      case ScalarType.SFIXED64:
      case ScalarType.SINT64:
        if ("longAsString" in field && field.longAsString) {
          value = String(value);
        } else if (typeof value == "string" || typeof value == "number") {
          value = protoInt64.parse(value);
        }
        break;
      case ScalarType.FIXED64:
      case ScalarType.UINT64:
        if ("longAsString" in field && field.longAsString) {
          value = String(value);
        } else if (typeof value == "string" || typeof value == "number") {
          value = protoInt64.uParse(value);
        }
        break;
    }
    return value;
  }

  // client/node_modules/@bufbuild/protobuf/dist/esm/wire/base64-encoding.js
  var nativeSetFromBase64 = Uint8Array.prototype.setFromBase64;
  function base64Decode(base64Str) {
    const len = base64Str.length;
    let size = len - (len + 3 >> 2);
    if ((len & 3) == 0 && base64Str[len - 1] == "=") {
      size -= base64Str[len - 2] == "=" ? 2 : 1;
    }
    const bytes = new Uint8Array(size);
    let written = -1;
    if (nativeSetFromBase64) {
      try {
        const result = nativeSetFromBase64.call(bytes, base64Str);
        if (result.read == len) {
          written = result.written;
        }
      } catch (_a) {
      }
    }
    if (written < 0) {
      written = setFromBase64(bytes, base64Str);
    }
    return written == size ? bytes : bytes.subarray(0, written);
  }
  function setFromBase64(bytes, base64Str) {
    const table = getDecodeTable();
    let bytePos = 0, groupPos = 0, b, p = 0;
    for (let i = 0; i < base64Str.length; i++) {
      b = table[base64Str.charCodeAt(i)];
      if (b === void 0) {
        switch (base64Str[i]) {
          // @ts-ignore TS7029: Fallthrough case in switch -- ignore instead of expect-error for compiler settings without noFallthroughCasesInSwitch: true
          case "=":
            groupPos = 0;
          // reset state when padding found
          case "\n":
          case "\r":
          case "	":
          case " ":
            continue;
          // skip white-space, and padding
          default:
            throw Error("invalid base64 string");
        }
      }
      switch (groupPos) {
        case 0:
          p = b;
          groupPos = 1;
          break;
        case 1:
          bytes[bytePos++] = p << 2 | (b & 48) >> 4;
          p = b;
          groupPos = 2;
          break;
        case 2:
          bytes[bytePos++] = (p & 15) << 4 | (b & 60) >> 2;
          p = b;
          groupPos = 3;
          break;
        case 3:
          bytes[bytePos++] = (p & 3) << 6 | b;
          groupPos = 0;
          break;
      }
    }
    if (groupPos == 1)
      throw Error("invalid base64 string");
    return bytePos;
  }
  var nativeToBase64 = Uint8Array.prototype.toBase64;
  var toBase64OptionsMap = {
    std: { alphabet: "base64", omitPadding: false },
    std_raw: { alphabet: "base64", omitPadding: true },
    url: { alphabet: "base64url", omitPadding: true }
  };
  function base64Encode(bytes, encoding = "std") {
    if (nativeToBase64) {
      return nativeToBase64.call(bytes, toBase64OptionsMap[encoding]);
    }
    const table = getEncodeTable(encoding);
    const pad = encoding == "std";
    let base64 = "", groupPos = 0, b, p = 0;
    for (let i = 0; i < bytes.length; i++) {
      b = bytes[i];
      switch (groupPos) {
        case 0:
          base64 += table[b >> 2];
          p = (b & 3) << 4;
          groupPos = 1;
          break;
        case 1:
          base64 += table[p | b >> 4];
          p = (b & 15) << 2;
          groupPos = 2;
          break;
        case 2:
          base64 += table[p | b >> 6];
          base64 += table[b & 63];
          groupPos = 0;
          break;
      }
    }
    if (groupPos) {
      base64 += table[p];
      if (pad) {
        base64 += "=";
        if (groupPos == 1)
          base64 += "=";
      }
    }
    return base64;
  }
  var encodeTableStd;
  var encodeTableUrl;
  var decodeTable;
  function getEncodeTable(encoding) {
    if (!encodeTableStd) {
      encodeTableStd = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split("");
      encodeTableUrl = encodeTableStd.slice(0, -2).concat("-", "_");
    }
    return encoding == "url" ? (
      // biome-ignore lint/style/noNonNullAssertion: TS fails to narrow down
      encodeTableUrl
    ) : encodeTableStd;
  }
  function getDecodeTable() {
    if (!decodeTable) {
      decodeTable = [];
      const encodeTable = getEncodeTable("std");
      for (let i = 0; i < encodeTable.length; i++)
        decodeTable[encodeTable[i].charCodeAt(0)] = i;
      decodeTable["-".charCodeAt(0)] = encodeTable.indexOf("+");
      decodeTable["_".charCodeAt(0)] = encodeTable.indexOf("/");
    }
    return decodeTable;
  }

  // client/node_modules/@bufbuild/protobuf/dist/esm/reflect/names.js
  function protoCamelCase(snakeCase) {
    let capNext = false;
    const b = [];
    for (let i = 0; i < snakeCase.length; i++) {
      let c = snakeCase.charAt(i);
      switch (c) {
        case "_":
          capNext = true;
          break;
        case "0":
        case "1":
        case "2":
        case "3":
        case "4":
        case "5":
        case "6":
        case "7":
        case "8":
        case "9":
          b.push(c);
          capNext = false;
          break;
        default:
          if (capNext) {
            capNext = false;
            c = c.toUpperCase();
          }
          b.push(c);
          break;
      }
    }
    return b.join("");
  }
  function protoSnakeCase(lowerCamelCase) {
    return lowerCamelCase.replace(/[A-Z]/g, (letter) => "_" + letter.toLowerCase());
  }
  var reservedObjectProperties = /* @__PURE__ */ new Set([
    // names reserved by JavaScript
    "constructor",
    "toString",
    "toJSON",
    "valueOf"
  ]);
  function safeObjectProperty(name) {
    return reservedObjectProperties.has(name) ? name + "$" : name;
  }

  // client/node_modules/@bufbuild/protobuf/dist/esm/codegenv2/restore-json-names.js
  function restoreJsonNames(message2) {
    for (const f of message2.field) {
      if (!unsafeIsSetExplicit(f, "jsonName")) {
        f.jsonName = protoCamelCase(f.name);
      }
    }
    message2.nestedType.forEach(restoreJsonNames);
  }

  // client/node_modules/@bufbuild/protobuf/dist/esm/wire/text-format.js
  function parseTextFormatEnumValue(descEnum, value) {
    const enumValue = descEnum.values.find((v) => v.name === value);
    if (!enumValue) {
      throw new Error(`cannot parse ${descEnum} default value: ${value}`);
    }
    return enumValue.number;
  }
  function parseTextFormatScalarValue(type, value) {
    switch (type) {
      case ScalarType.STRING:
        return value;
      case ScalarType.BYTES: {
        const u = unescapeBytesDefaultValue(value);
        if (u === false) {
          throw new Error(`cannot parse ${ScalarType[type]} default value: ${value}`);
        }
        return u;
      }
      case ScalarType.INT64:
      case ScalarType.SFIXED64:
      case ScalarType.SINT64:
        return protoInt64.parse(value);
      case ScalarType.UINT64:
      case ScalarType.FIXED64:
        return protoInt64.uParse(value);
      case ScalarType.DOUBLE:
      case ScalarType.FLOAT:
        switch (value) {
          case "inf":
            return Number.POSITIVE_INFINITY;
          case "-inf":
            return Number.NEGATIVE_INFINITY;
          case "nan":
            return Number.NaN;
          default:
            return parseFloat(value);
        }
      case ScalarType.BOOL:
        return value === "true";
      case ScalarType.INT32:
      case ScalarType.UINT32:
      case ScalarType.SINT32:
      case ScalarType.FIXED32:
      case ScalarType.SFIXED32:
        return parseInt(value, 10);
    }
  }
  function unescapeBytesDefaultValue(str) {
    const b = [];
    const input = {
      tail: str,
      c: "",
      next() {
        if (this.tail.length == 0) {
          return false;
        }
        this.c = this.tail[0];
        this.tail = this.tail.substring(1);
        return true;
      },
      take(n) {
        if (this.tail.length >= n) {
          const r = this.tail.substring(0, n);
          this.tail = this.tail.substring(n);
          return r;
        }
        return false;
      }
    };
    while (input.next()) {
      switch (input.c) {
        case "\\":
          if (input.next()) {
            switch (input.c) {
              case "\\":
                b.push(input.c.charCodeAt(0));
                break;
              case "b":
                b.push(8);
                break;
              case "f":
                b.push(12);
                break;
              case "n":
                b.push(10);
                break;
              case "r":
                b.push(13);
                break;
              case "t":
                b.push(9);
                break;
              case "v":
                b.push(11);
                break;
              case "0":
              case "1":
              case "2":
              case "3":
              case "4":
              case "5":
              case "6":
              case "7": {
                const s = input.c;
                const t = input.take(2);
                if (t === false) {
                  return false;
                }
                const n = parseInt(s + t, 8);
                if (Number.isNaN(n)) {
                  return false;
                }
                b.push(n);
                break;
              }
              case "x": {
                const s = input.c;
                const t = input.take(2);
                if (t === false) {
                  return false;
                }
                const n = parseInt(s + t, 16);
                if (Number.isNaN(n)) {
                  return false;
                }
                b.push(n);
                break;
              }
              case "u": {
                const s = input.c;
                const t = input.take(4);
                if (t === false) {
                  return false;
                }
                const n = parseInt(s + t, 16);
                if (Number.isNaN(n)) {
                  return false;
                }
                const chunk = new Uint8Array(4);
                const view2 = new DataView(chunk.buffer);
                view2.setInt32(0, n, true);
                b.push(chunk[0], chunk[1], chunk[2], chunk[3]);
                break;
              }
              case "U": {
                const s = input.c;
                const t = input.take(8);
                if (t === false) {
                  return false;
                }
                const tc = protoInt64.uEnc(s + t);
                const chunk = new Uint8Array(8);
                const view2 = new DataView(chunk.buffer);
                view2.setInt32(0, tc.lo, true);
                view2.setInt32(4, tc.hi, true);
                b.push(chunk[0], chunk[1], chunk[2], chunk[3], chunk[4], chunk[5], chunk[6], chunk[7]);
                break;
              }
            }
          }
          break;
        default:
          b.push(input.c.charCodeAt(0));
      }
    }
    return new Uint8Array(b);
  }

  // client/node_modules/@bufbuild/protobuf/dist/esm/reflect/nested-types.js
  function* nestedTypes(desc) {
    switch (desc.kind) {
      case "file":
        for (const message2 of desc.messages) {
          yield message2;
          yield* nestedTypes(message2);
        }
        yield* desc.enums;
        yield* desc.services;
        yield* desc.extensions;
        break;
      case "message":
        for (const message2 of desc.nestedMessages) {
          yield message2;
          yield* nestedTypes(message2);
        }
        yield* desc.nestedEnums;
        yield* desc.nestedExtensions;
        break;
    }
  }

  // client/node_modules/@bufbuild/protobuf/dist/esm/registry.js
  function createFileRegistry(...args) {
    const registry = createBaseRegistry();
    if (!args.length) {
      return registry;
    }
    if ("$typeName" in args[0] && args[0].$typeName == "google.protobuf.FileDescriptorSet") {
      for (const file of args[0].file) {
        addFile(file, registry);
      }
      return registry;
    }
    if ("$typeName" in args[0]) {
      let recurseDeps = function(file) {
        const deps = [];
        for (const protoFileName of file.dependency) {
          if (registry.getFile(protoFileName) != void 0) {
            continue;
          }
          if (seen.has(protoFileName)) {
            continue;
          }
          const dep = resolve(protoFileName);
          if (!dep) {
            throw new Error(`Unable to resolve ${protoFileName}, imported by ${file.name}`);
          }
          if ("kind" in dep) {
            registry.addFile(dep, false, true);
          } else {
            seen.add(dep.name);
            deps.push(dep);
          }
        }
        return deps.concat(...deps.map(recurseDeps));
      };
      const input = args[0];
      const resolve = args[1];
      const seen = /* @__PURE__ */ new Set();
      for (const file of [input, ...recurseDeps(input)].reverse()) {
        addFile(file, registry);
      }
    } else {
      for (const fileReg of args) {
        for (const file of fileReg.files) {
          registry.addFile(file);
        }
      }
    }
    return registry;
  }
  function createBaseRegistry() {
    const types = /* @__PURE__ */ new Map();
    const extendees = /* @__PURE__ */ new Map();
    const files = /* @__PURE__ */ new Map();
    return {
      kind: "registry",
      types,
      extendees,
      [Symbol.iterator]() {
        return types.values();
      },
      get files() {
        return files.values();
      },
      addFile(file, skipTypes, withDeps) {
        files.set(file.proto.name, file);
        if (!skipTypes) {
          for (const type of nestedTypes(file)) {
            this.add(type);
          }
        }
        if (withDeps) {
          for (const f of file.dependencies) {
            this.addFile(f, skipTypes, withDeps);
          }
        }
      },
      add(desc) {
        if (desc.kind == "extension") {
          let numberToExt = extendees.get(desc.extendee.typeName);
          if (!numberToExt) {
            extendees.set(
              desc.extendee.typeName,
              // biome-ignore lint/suspicious/noAssignInExpressions: no
              numberToExt = /* @__PURE__ */ new Map()
            );
          }
          numberToExt.set(desc.number, desc);
        }
        types.set(desc.typeName, desc);
      },
      get(typeName) {
        return types.get(typeName);
      },
      getFile(fileName) {
        return files.get(fileName);
      },
      getMessage(typeName) {
        const t = types.get(typeName);
        return (t === null || t === void 0 ? void 0 : t.kind) == "message" ? t : void 0;
      },
      getEnum(typeName) {
        const t = types.get(typeName);
        return (t === null || t === void 0 ? void 0 : t.kind) == "enum" ? t : void 0;
      },
      getExtension(typeName) {
        const t = types.get(typeName);
        return (t === null || t === void 0 ? void 0 : t.kind) == "extension" ? t : void 0;
      },
      getExtensionFor(extendee, no) {
        var _a;
        return (_a = extendees.get(extendee.typeName)) === null || _a === void 0 ? void 0 : _a.get(no);
      },
      getService(typeName) {
        const t = types.get(typeName);
        return (t === null || t === void 0 ? void 0 : t.kind) == "service" ? t : void 0;
      }
    };
  }
  var EDITION_PROTO22 = 998;
  var EDITION_PROTO32 = 999;
  var EDITION_UNSTABLE = 9999;
  var TYPE_STRING = 9;
  var TYPE_GROUP = 10;
  var TYPE_MESSAGE = 11;
  var TYPE_BYTES = 12;
  var TYPE_ENUM = 14;
  var LABEL_REPEATED = 3;
  var LABEL_REQUIRED = 2;
  var JS_STRING = 1;
  var IDEMPOTENCY_UNKNOWN = 0;
  var EXPLICIT = 1;
  var IMPLICIT3 = 2;
  var LEGACY_REQUIRED = 3;
  var PACKED = 1;
  var DELIMITED = 2;
  var OPEN = 1;
  var VERIFY = 2;
  var maximumEdition = 1001;
  var featureDefaults = {
    // EDITION_PROTO2
    998: {
      fieldPresence: 1,
      // EXPLICIT,
      enumType: 2,
      // CLOSED,
      repeatedFieldEncoding: 2,
      // EXPANDED,
      utf8Validation: 3,
      // NONE,
      messageEncoding: 1,
      // LENGTH_PREFIXED,
      jsonFormat: 2,
      // LEGACY_BEST_EFFORT,
      enforceNamingStyle: 2,
      // STYLE_LEGACY,
      defaultSymbolVisibility: 1
      // EXPORT_ALL,
    },
    // EDITION_PROTO3
    999: {
      fieldPresence: 2,
      // IMPLICIT,
      enumType: 1,
      // OPEN,
      repeatedFieldEncoding: 1,
      // PACKED,
      utf8Validation: 2,
      // VERIFY,
      messageEncoding: 1,
      // LENGTH_PREFIXED,
      jsonFormat: 1,
      // ALLOW,
      enforceNamingStyle: 2,
      // STYLE_LEGACY,
      defaultSymbolVisibility: 1
      // EXPORT_ALL,
    },
    // EDITION_2023
    1e3: {
      fieldPresence: 1,
      // EXPLICIT,
      enumType: 1,
      // OPEN,
      repeatedFieldEncoding: 1,
      // PACKED,
      utf8Validation: 2,
      // VERIFY,
      messageEncoding: 1,
      // LENGTH_PREFIXED,
      jsonFormat: 1,
      // ALLOW,
      enforceNamingStyle: 2,
      // STYLE_LEGACY,
      defaultSymbolVisibility: 1
      // EXPORT_ALL,
    },
    // EDITION_2024
    1001: {
      fieldPresence: 1,
      // EXPLICIT,
      enumType: 1,
      // OPEN,
      repeatedFieldEncoding: 1,
      // PACKED,
      utf8Validation: 2,
      // VERIFY,
      messageEncoding: 1,
      // LENGTH_PREFIXED,
      jsonFormat: 1,
      // ALLOW,
      enforceNamingStyle: 1,
      // STYLE2024,
      defaultSymbolVisibility: 2
      // EXPORT_TOP_LEVEL,
    }
  };
  function addFile(proto, reg) {
    var _a, _b;
    const file = {
      kind: "file",
      proto,
      deprecated: (_b = (_a = proto.options) === null || _a === void 0 ? void 0 : _a.deprecated) !== null && _b !== void 0 ? _b : false,
      edition: getFileEdition(proto),
      name: proto.name.replace(/\.proto$/, ""),
      dependencies: findFileDependencies(proto, reg),
      enums: [],
      messages: [],
      extensions: [],
      services: [],
      toString() {
        return `file ${proto.name}`;
      }
    };
    const mapEntriesStore = /* @__PURE__ */ new Map();
    const mapEntries = {
      get(typeName) {
        return mapEntriesStore.get(typeName);
      },
      add(desc) {
        var _a2;
        assert(((_a2 = desc.proto.options) === null || _a2 === void 0 ? void 0 : _a2.mapEntry) === true);
        mapEntriesStore.set(desc.typeName, desc);
      }
    };
    for (const enumProto of proto.enumType) {
      addEnum(enumProto, file, void 0, reg);
    }
    for (const messageProto of proto.messageType) {
      addMessage(messageProto, file, void 0, reg, mapEntries);
    }
    for (const serviceProto of proto.service) {
      addService(serviceProto, file, reg);
    }
    addExtensions(file, reg);
    for (const mapEntry of mapEntriesStore.values()) {
      addFields(mapEntry, reg, mapEntries);
    }
    for (const message2 of file.messages) {
      addFields(message2, reg, mapEntries);
      addExtensions(message2, reg);
    }
    reg.addFile(file, true);
  }
  function addExtensions(desc, reg) {
    switch (desc.kind) {
      case "file":
        for (const proto of desc.proto.extension) {
          const ext = newField(proto, desc, reg);
          desc.extensions.push(ext);
          reg.add(ext);
        }
        break;
      case "message":
        for (const proto of desc.proto.extension) {
          const ext = newField(proto, desc, reg);
          desc.nestedExtensions.push(ext);
          reg.add(ext);
        }
        for (const message2 of desc.nestedMessages) {
          addExtensions(message2, reg);
        }
        break;
    }
  }
  function addFields(message2, reg, mapEntries) {
    const allOneofs = message2.proto.oneofDecl.map((proto) => newOneof(proto, message2));
    const oneofsSeen = /* @__PURE__ */ new Set();
    for (const proto of message2.proto.field) {
      const oneof = findOneof(proto, allOneofs);
      const field = newField(proto, message2, reg, oneof, mapEntries);
      message2.fields.push(field);
      message2.field[field.localName] = field;
      if (oneof === void 0) {
        message2.members.push(field);
      } else {
        oneof.fields.push(field);
        if (!oneofsSeen.has(oneof)) {
          oneofsSeen.add(oneof);
          message2.members.push(oneof);
        }
      }
    }
    for (const oneof of allOneofs.filter((o) => oneofsSeen.has(o))) {
      message2.oneofs.push(oneof);
    }
    for (const child of message2.nestedMessages) {
      addFields(child, reg, mapEntries);
    }
  }
  function addEnum(proto, file, parent, reg) {
    var _a, _b, _c, _d, _e;
    const sharedPrefix = findEnumSharedPrefix(proto.name, proto.value);
    const desc = {
      kind: "enum",
      proto,
      deprecated: (_b = (_a = proto.options) === null || _a === void 0 ? void 0 : _a.deprecated) !== null && _b !== void 0 ? _b : false,
      file,
      parent,
      open: true,
      name: proto.name,
      typeName: makeTypeName(proto, parent, file),
      value: {},
      values: [],
      sharedPrefix,
      toString() {
        return `enum ${this.typeName}`;
      }
    };
    desc.open = isEnumOpen(desc);
    reg.add(desc);
    for (const p of proto.value) {
      const name = p.name;
      desc.values.push(
        // biome-ignore lint/suspicious/noAssignInExpressions: no
        desc.value[p.number] = {
          kind: "enum_value",
          proto: p,
          deprecated: (_d = (_c = p.options) === null || _c === void 0 ? void 0 : _c.deprecated) !== null && _d !== void 0 ? _d : false,
          parent: desc,
          name,
          localName: safeObjectProperty(sharedPrefix == void 0 ? name : name.substring(sharedPrefix.length)),
          number: p.number,
          toString() {
            return `enum value ${desc.typeName}.${name}`;
          }
        }
      );
    }
    ((_e = parent === null || parent === void 0 ? void 0 : parent.nestedEnums) !== null && _e !== void 0 ? _e : file.enums).push(desc);
  }
  function addMessage(proto, file, parent, reg, mapEntries) {
    var _a, _b, _c, _d;
    const desc = {
      kind: "message",
      proto,
      deprecated: (_b = (_a = proto.options) === null || _a === void 0 ? void 0 : _a.deprecated) !== null && _b !== void 0 ? _b : false,
      file,
      parent,
      name: proto.name,
      typeName: makeTypeName(proto, parent, file),
      fields: [],
      field: {},
      oneofs: [],
      members: [],
      nestedEnums: [],
      nestedMessages: [],
      nestedExtensions: [],
      toString() {
        return `message ${this.typeName}`;
      }
    };
    if (((_c = proto.options) === null || _c === void 0 ? void 0 : _c.mapEntry) === true) {
      mapEntries.add(desc);
    } else {
      ((_d = parent === null || parent === void 0 ? void 0 : parent.nestedMessages) !== null && _d !== void 0 ? _d : file.messages).push(desc);
      reg.add(desc);
    }
    for (const enumProto of proto.enumType) {
      addEnum(enumProto, file, desc, reg);
    }
    for (const messageProto of proto.nestedType) {
      addMessage(messageProto, file, desc, reg, mapEntries);
    }
  }
  function addService(proto, file, reg) {
    var _a, _b;
    const desc = {
      kind: "service",
      proto,
      deprecated: (_b = (_a = proto.options) === null || _a === void 0 ? void 0 : _a.deprecated) !== null && _b !== void 0 ? _b : false,
      file,
      name: proto.name,
      typeName: makeTypeName(proto, void 0, file),
      methods: [],
      method: {},
      toString() {
        return `service ${this.typeName}`;
      }
    };
    file.services.push(desc);
    reg.add(desc);
    for (const methodProto of proto.method) {
      const method = newMethod(methodProto, desc, reg);
      desc.methods.push(method);
      desc.method[method.localName] = method;
    }
  }
  function newMethod(proto, parent, reg) {
    var _a, _b, _c, _d;
    let methodKind;
    if (proto.clientStreaming && proto.serverStreaming) {
      methodKind = "bidi_streaming";
    } else if (proto.clientStreaming) {
      methodKind = "client_streaming";
    } else if (proto.serverStreaming) {
      methodKind = "server_streaming";
    } else {
      methodKind = "unary";
    }
    const input = reg.getMessage(trimLeadingDot(proto.inputType));
    const output = reg.getMessage(trimLeadingDot(proto.outputType));
    assert(input, `invalid MethodDescriptorProto: input_type ${proto.inputType} not found`);
    assert(output, `invalid MethodDescriptorProto: output_type ${proto.inputType} not found`);
    const name = proto.name;
    return {
      kind: "rpc",
      proto,
      deprecated: (_b = (_a = proto.options) === null || _a === void 0 ? void 0 : _a.deprecated) !== null && _b !== void 0 ? _b : false,
      parent,
      name,
      localName: safeObjectProperty(name.length ? safeObjectProperty(name[0].toLowerCase() + name.substring(1)) : name),
      methodKind,
      input,
      output,
      idempotency: (_d = (_c = proto.options) === null || _c === void 0 ? void 0 : _c.idempotencyLevel) !== null && _d !== void 0 ? _d : IDEMPOTENCY_UNKNOWN,
      toString() {
        return `rpc ${parent.typeName}.${name}`;
      }
    };
  }
  function newOneof(proto, parent) {
    return {
      kind: "oneof",
      proto,
      deprecated: false,
      parent,
      fields: [],
      name: proto.name,
      localName: safeObjectProperty(protoCamelCase(proto.name)),
      toString() {
        return `oneof ${parent.typeName}.${this.name}`;
      }
    };
  }
  function newField(proto, parentOrFile, reg, oneof, mapEntries) {
    var _a, _b, _c;
    const isExtension = mapEntries === void 0;
    const field = {
      kind: "field",
      proto,
      deprecated: (_b = (_a = proto.options) === null || _a === void 0 ? void 0 : _a.deprecated) !== null && _b !== void 0 ? _b : false,
      name: proto.name,
      number: proto.number,
      scalar: void 0,
      message: void 0,
      enum: void 0,
      presence: getFieldPresence(proto, oneof, isExtension, parentOrFile),
      utf8Validation: isUtf8Validated(proto, parentOrFile),
      listKind: void 0,
      mapKind: void 0,
      mapKey: void 0,
      delimitedEncoding: void 0,
      packed: void 0,
      longAsString: false,
      getDefaultValue: void 0
    };
    let toStr;
    if (isExtension) {
      const file = parentOrFile.kind == "file" ? parentOrFile : parentOrFile.file;
      const parent = parentOrFile.kind == "file" ? void 0 : parentOrFile;
      const typeName = makeTypeName(proto, parent, file);
      field.kind = "extension";
      field.file = file;
      field.parent = parent;
      field.oneof = void 0;
      field.typeName = typeName;
      field.jsonName = `[${typeName}]`;
      toStr = () => `extension ${typeName}`;
      const extendee = reg.getMessage(trimLeadingDot(proto.extendee));
      assert(extendee, `invalid FieldDescriptorProto: extendee ${proto.extendee} not found`);
      field.extendee = extendee;
    } else {
      const parent = parentOrFile;
      assert(parent.kind == "message");
      field.parent = parent;
      field.oneof = oneof;
      field.localName = oneof ? protoCamelCase(proto.name) : safeObjectProperty(protoCamelCase(proto.name));
      field.jsonName = proto.jsonName;
      toStr = () => `field ${parent.typeName}.${proto.name}`;
    }
    Object.defineProperty(field, "toString", {
      value: toStr,
      writable: true,
      enumerable: true,
      configurable: true
    });
    const label = proto.label;
    const type = proto.type;
    const jstype = (_c = proto.options) === null || _c === void 0 ? void 0 : _c.jstype;
    if (label === LABEL_REPEATED) {
      const mapEntry = type == TYPE_MESSAGE ? mapEntries === null || mapEntries === void 0 ? void 0 : mapEntries.get(trimLeadingDot(proto.typeName)) : void 0;
      if (mapEntry) {
        field.fieldKind = "map";
        const { key, value } = findMapEntryFields(mapEntry);
        field.mapKey = key.scalar;
        field.mapKind = value.fieldKind;
        field.message = value.message;
        field.delimitedEncoding = false;
        field.enum = value.enum;
        field.scalar = value.scalar;
        return field;
      }
      field.fieldKind = "list";
      switch (type) {
        case TYPE_MESSAGE:
        case TYPE_GROUP:
          field.listKind = "message";
          field.message = reg.getMessage(trimLeadingDot(proto.typeName));
          assert(field.message);
          field.delimitedEncoding = isDelimitedEncoding(proto, parentOrFile);
          break;
        case TYPE_ENUM:
          field.listKind = "enum";
          field.enum = reg.getEnum(trimLeadingDot(proto.typeName));
          assert(field.enum);
          break;
        default:
          field.listKind = "scalar";
          field.scalar = type;
          field.longAsString = jstype == JS_STRING;
          break;
      }
      field.packed = isPackedField(proto, parentOrFile);
      return field;
    }
    switch (type) {
      case TYPE_MESSAGE:
      case TYPE_GROUP:
        field.fieldKind = "message";
        field.message = reg.getMessage(trimLeadingDot(proto.typeName));
        assert(field.message, `invalid FieldDescriptorProto: type_name ${proto.typeName} not found`);
        field.delimitedEncoding = isDelimitedEncoding(proto, parentOrFile);
        field.getDefaultValue = () => void 0;
        break;
      case TYPE_ENUM: {
        const enumeration = reg.getEnum(trimLeadingDot(proto.typeName));
        assert(enumeration !== void 0, `invalid FieldDescriptorProto: type_name ${proto.typeName} not found`);
        field.fieldKind = "enum";
        field.enum = reg.getEnum(trimLeadingDot(proto.typeName));
        field.getDefaultValue = () => {
          return unsafeIsSetExplicit(proto, "defaultValue") ? parseTextFormatEnumValue(enumeration, proto.defaultValue) : void 0;
        };
        break;
      }
      default: {
        field.fieldKind = "scalar";
        field.scalar = type;
        field.longAsString = jstype == JS_STRING;
        field.getDefaultValue = () => {
          return unsafeIsSetExplicit(proto, "defaultValue") ? parseTextFormatScalarValue(type, proto.defaultValue) : void 0;
        };
        break;
      }
    }
    return field;
  }
  function getFileEdition(proto) {
    switch (proto.syntax) {
      case "":
      case "proto2":
        return EDITION_PROTO22;
      case "proto3":
        return EDITION_PROTO32;
      case "editions":
        if (proto.edition === EDITION_UNSTABLE) {
          return maximumEdition;
        }
        if (proto.edition in featureDefaults) {
          return proto.edition;
        }
        throw new Error(`${proto.name}: unsupported edition`);
      default:
        throw new Error(`${proto.name}: unsupported syntax "${proto.syntax}"`);
    }
  }
  function findFileDependencies(proto, reg) {
    return proto.dependency.map((wantName) => {
      const dep = reg.getFile(wantName);
      if (!dep) {
        throw new Error(`Cannot find ${wantName}, imported by ${proto.name}`);
      }
      return dep;
    });
  }
  function findEnumSharedPrefix(enumName, values) {
    const prefix = camelToSnakeCase(enumName) + "_";
    for (const value of values) {
      if (!value.name.toLowerCase().startsWith(prefix)) {
        return void 0;
      }
      const shortName = value.name.substring(prefix.length);
      if (shortName.length == 0) {
        return void 0;
      }
      if (/^\d/.test(shortName)) {
        return void 0;
      }
    }
    return prefix;
  }
  function camelToSnakeCase(camel) {
    return (camel.substring(0, 1) + camel.substring(1).replace(/[A-Z]/g, (c) => "_" + c)).toLowerCase();
  }
  function makeTypeName(proto, parent, file) {
    let typeName;
    if (parent) {
      typeName = `${parent.typeName}.${proto.name}`;
    } else if (file.proto.package.length > 0) {
      typeName = `${file.proto.package}.${proto.name}`;
    } else {
      typeName = `${proto.name}`;
    }
    return typeName;
  }
  function trimLeadingDot(typeName) {
    return typeName.startsWith(".") ? typeName.substring(1) : typeName;
  }
  function findOneof(proto, allOneofs) {
    if (!unsafeIsSetExplicit(proto, "oneofIndex")) {
      return void 0;
    }
    if (proto.proto3Optional) {
      return void 0;
    }
    const oneof = allOneofs[proto.oneofIndex];
    assert(oneof, `invalid FieldDescriptorProto: oneof #${proto.oneofIndex} for field #${proto.number} not found`);
    return oneof;
  }
  function getFieldPresence(proto, oneof, isExtension, parent) {
    if (proto.label == LABEL_REQUIRED) {
      return LEGACY_REQUIRED;
    }
    if (proto.label == LABEL_REPEATED) {
      return IMPLICIT3;
    }
    if (!!oneof || proto.proto3Optional) {
      return EXPLICIT;
    }
    if (isExtension) {
      return EXPLICIT;
    }
    const resolved = resolveFeature("fieldPresence", { proto, parent });
    if (resolved == IMPLICIT3 && (proto.type == TYPE_MESSAGE || proto.type == TYPE_GROUP)) {
      return EXPLICIT;
    }
    return resolved;
  }
  function isPackedField(proto, parent) {
    if (proto.label != LABEL_REPEATED) {
      return false;
    }
    switch (proto.type) {
      case TYPE_STRING:
      case TYPE_BYTES:
      case TYPE_GROUP:
      case TYPE_MESSAGE:
        return false;
    }
    const o = proto.options;
    if (o && unsafeIsSetExplicit(o, "packed")) {
      return o.packed;
    }
    return PACKED == resolveFeature("repeatedFieldEncoding", {
      proto,
      parent
    });
  }
  function findMapEntryFields(mapEntry) {
    const key = mapEntry.fields.find((f) => f.number === 1);
    const value = mapEntry.fields.find((f) => f.number === 2);
    assert(key && key.fieldKind == "scalar" && key.scalar != ScalarType.BYTES && key.scalar != ScalarType.FLOAT && key.scalar != ScalarType.DOUBLE && value && value.fieldKind != "list" && value.fieldKind != "map");
    return { key, value };
  }
  function isEnumOpen(desc) {
    var _a;
    return OPEN == resolveFeature("enumType", {
      proto: desc.proto,
      parent: (_a = desc.parent) !== null && _a !== void 0 ? _a : desc.file
    });
  }
  function isDelimitedEncoding(proto, parent) {
    if (proto.type == TYPE_GROUP) {
      return true;
    }
    return DELIMITED == resolveFeature("messageEncoding", {
      proto,
      parent
    });
  }
  function isUtf8Validated(proto, parent) {
    return VERIFY == resolveFeature("utf8Validation", {
      proto,
      parent
    });
  }
  function resolveFeature(name, ref) {
    var _a, _b;
    const featureSet = (_a = ref.proto.options) === null || _a === void 0 ? void 0 : _a.features;
    if (featureSet) {
      const val = featureSet[name];
      if (val != 0) {
        return val;
      }
    }
    if ("kind" in ref) {
      if (ref.kind == "message") {
        return resolveFeature(name, (_b = ref.parent) !== null && _b !== void 0 ? _b : ref.file);
      }
      const editionDefaults = featureDefaults[ref.edition];
      if (!editionDefaults) {
        throw new Error(`feature default for edition ${ref.edition} not found`);
      }
      return editionDefaults[name];
    }
    return resolveFeature(name, ref.parent);
  }
  function assert(condition, msg) {
    if (!condition) {
      throw new Error(msg);
    }
  }

  // client/node_modules/@bufbuild/protobuf/dist/esm/codegenv2/boot.js
  function boot(boot2) {
    const root = bootFileDescriptorProto(boot2);
    root.messageType.forEach(restoreJsonNames);
    const reg = createFileRegistry(root, () => void 0);
    return reg.getFile(root.name);
  }
  function bootFileDescriptorProto(init) {
    const proto = /* @__PURE__ */ Object.create({
      syntax: "",
      edition: 0
    });
    return Object.assign(proto, Object.assign(Object.assign({ $typeName: "google.protobuf.FileDescriptorProto", dependency: [], publicDependency: [], weakDependency: [], optionDependency: [], service: [], extension: [] }, init), { messageType: init.messageType.map(bootDescriptorProto), enumType: init.enumType.map(bootEnumDescriptorProto) }));
  }
  function bootDescriptorProto(init) {
    var _a, _b, _c, _d, _e, _f, _g, _h;
    const proto = /* @__PURE__ */ Object.create({
      visibility: 0
    });
    return Object.assign(proto, {
      $typeName: "google.protobuf.DescriptorProto",
      name: init.name,
      field: (_b = (_a = init.field) === null || _a === void 0 ? void 0 : _a.map(bootFieldDescriptorProto)) !== null && _b !== void 0 ? _b : [],
      extension: [],
      nestedType: (_d = (_c = init.nestedType) === null || _c === void 0 ? void 0 : _c.map(bootDescriptorProto)) !== null && _d !== void 0 ? _d : [],
      enumType: (_f = (_e = init.enumType) === null || _e === void 0 ? void 0 : _e.map(bootEnumDescriptorProto)) !== null && _f !== void 0 ? _f : [],
      extensionRange: (_h = (_g = init.extensionRange) === null || _g === void 0 ? void 0 : _g.map((e) => Object.assign({ $typeName: "google.protobuf.DescriptorProto.ExtensionRange" }, e))) !== null && _h !== void 0 ? _h : [],
      oneofDecl: [],
      reservedRange: [],
      reservedName: []
    });
  }
  function bootFieldDescriptorProto(init) {
    const proto = /* @__PURE__ */ Object.create({
      label: 1,
      typeName: "",
      extendee: "",
      defaultValue: "",
      oneofIndex: 0,
      jsonName: "",
      proto3Optional: false
    });
    return Object.assign(proto, Object.assign(Object.assign({ $typeName: "google.protobuf.FieldDescriptorProto" }, init), { options: init.options ? bootFieldOptions(init.options) : void 0 }));
  }
  function bootFieldOptions(init) {
    var _a, _b, _c;
    const proto = /* @__PURE__ */ Object.create({
      ctype: 0,
      packed: false,
      jstype: 0,
      lazy: false,
      unverifiedLazy: false,
      deprecated: false,
      weak: false,
      debugRedact: false,
      retention: 0
    });
    return Object.assign(proto, Object.assign(Object.assign({ $typeName: "google.protobuf.FieldOptions" }, init), { targets: (_a = init.targets) !== null && _a !== void 0 ? _a : [], editionDefaults: (_c = (_b = init.editionDefaults) === null || _b === void 0 ? void 0 : _b.map((e) => Object.assign({ $typeName: "google.protobuf.FieldOptions.EditionDefault" }, e))) !== null && _c !== void 0 ? _c : [], uninterpretedOption: [] }));
  }
  function bootEnumDescriptorProto(init) {
    const proto = /* @__PURE__ */ Object.create({
      visibility: 0
    });
    return Object.assign(proto, {
      $typeName: "google.protobuf.EnumDescriptorProto",
      name: init.name,
      reservedName: [],
      reservedRange: [],
      value: init.value.map((e) => Object.assign({ $typeName: "google.protobuf.EnumValueDescriptorProto" }, e))
    });
  }

  // client/node_modules/@bufbuild/protobuf/dist/esm/codegenv2/message.js
  function messageDesc(file, path, ...paths) {
    return paths.reduce((acc, cur) => acc.nestedMessages[cur], file.messages[path]);
  }

  // client/node_modules/@bufbuild/protobuf/dist/esm/wkt/gen/google/protobuf/descriptor_pb.js
  var file_google_protobuf_descriptor = /* @__PURE__ */ boot({ "name": "google/protobuf/descriptor.proto", "package": "google.protobuf", "messageType": [{ "name": "FileDescriptorSet", "field": [{ "name": "file", "number": 1, "type": 11, "label": 3, "typeName": ".google.protobuf.FileDescriptorProto" }], "extensionRange": [{ "start": 536e6, "end": 536000001 }] }, { "name": "FileDescriptorProto", "field": [{ "name": "name", "number": 1, "type": 9, "label": 1 }, { "name": "package", "number": 2, "type": 9, "label": 1 }, { "name": "dependency", "number": 3, "type": 9, "label": 3 }, { "name": "public_dependency", "number": 10, "type": 5, "label": 3 }, { "name": "weak_dependency", "number": 11, "type": 5, "label": 3 }, { "name": "option_dependency", "number": 15, "type": 9, "label": 3 }, { "name": "message_type", "number": 4, "type": 11, "label": 3, "typeName": ".google.protobuf.DescriptorProto" }, { "name": "enum_type", "number": 5, "type": 11, "label": 3, "typeName": ".google.protobuf.EnumDescriptorProto" }, { "name": "service", "number": 6, "type": 11, "label": 3, "typeName": ".google.protobuf.ServiceDescriptorProto" }, { "name": "extension", "number": 7, "type": 11, "label": 3, "typeName": ".google.protobuf.FieldDescriptorProto" }, { "name": "options", "number": 8, "type": 11, "label": 1, "typeName": ".google.protobuf.FileOptions" }, { "name": "source_code_info", "number": 9, "type": 11, "label": 1, "typeName": ".google.protobuf.SourceCodeInfo" }, { "name": "syntax", "number": 12, "type": 9, "label": 1 }, { "name": "edition", "number": 14, "type": 14, "label": 1, "typeName": ".google.protobuf.Edition" }] }, { "name": "DescriptorProto", "field": [{ "name": "name", "number": 1, "type": 9, "label": 1 }, { "name": "field", "number": 2, "type": 11, "label": 3, "typeName": ".google.protobuf.FieldDescriptorProto" }, { "name": "extension", "number": 6, "type": 11, "label": 3, "typeName": ".google.protobuf.FieldDescriptorProto" }, { "name": "nested_type", "number": 3, "type": 11, "label": 3, "typeName": ".google.protobuf.DescriptorProto" }, { "name": "enum_type", "number": 4, "type": 11, "label": 3, "typeName": ".google.protobuf.EnumDescriptorProto" }, { "name": "extension_range", "number": 5, "type": 11, "label": 3, "typeName": ".google.protobuf.DescriptorProto.ExtensionRange" }, { "name": "oneof_decl", "number": 8, "type": 11, "label": 3, "typeName": ".google.protobuf.OneofDescriptorProto" }, { "name": "options", "number": 7, "type": 11, "label": 1, "typeName": ".google.protobuf.MessageOptions" }, { "name": "reserved_range", "number": 9, "type": 11, "label": 3, "typeName": ".google.protobuf.DescriptorProto.ReservedRange" }, { "name": "reserved_name", "number": 10, "type": 9, "label": 3 }, { "name": "visibility", "number": 11, "type": 14, "label": 1, "typeName": ".google.protobuf.SymbolVisibility" }], "nestedType": [{ "name": "ExtensionRange", "field": [{ "name": "start", "number": 1, "type": 5, "label": 1 }, { "name": "end", "number": 2, "type": 5, "label": 1 }, { "name": "options", "number": 3, "type": 11, "label": 1, "typeName": ".google.protobuf.ExtensionRangeOptions" }] }, { "name": "ReservedRange", "field": [{ "name": "start", "number": 1, "type": 5, "label": 1 }, { "name": "end", "number": 2, "type": 5, "label": 1 }] }] }, { "name": "ExtensionRangeOptions", "field": [{ "name": "uninterpreted_option", "number": 999, "type": 11, "label": 3, "typeName": ".google.protobuf.UninterpretedOption" }, { "name": "declaration", "number": 2, "type": 11, "label": 3, "typeName": ".google.protobuf.ExtensionRangeOptions.Declaration", "options": { "retention": 2 } }, { "name": "features", "number": 50, "type": 11, "label": 1, "typeName": ".google.protobuf.FeatureSet" }, { "name": "verification", "number": 3, "type": 14, "label": 1, "typeName": ".google.protobuf.ExtensionRangeOptions.VerificationState", "defaultValue": "UNVERIFIED", "options": { "retention": 2 } }], "nestedType": [{ "name": "Declaration", "field": [{ "name": "number", "number": 1, "type": 5, "label": 1 }, { "name": "full_name", "number": 2, "type": 9, "label": 1 }, { "name": "type", "number": 3, "type": 9, "label": 1 }, { "name": "reserved", "number": 5, "type": 8, "label": 1 }, { "name": "repeated", "number": 6, "type": 8, "label": 1 }] }], "enumType": [{ "name": "VerificationState", "value": [{ "name": "DECLARATION", "number": 0 }, { "name": "UNVERIFIED", "number": 1 }] }], "extensionRange": [{ "start": 1e3, "end": 536870912 }] }, { "name": "FieldDescriptorProto", "field": [{ "name": "name", "number": 1, "type": 9, "label": 1 }, { "name": "number", "number": 3, "type": 5, "label": 1 }, { "name": "label", "number": 4, "type": 14, "label": 1, "typeName": ".google.protobuf.FieldDescriptorProto.Label" }, { "name": "type", "number": 5, "type": 14, "label": 1, "typeName": ".google.protobuf.FieldDescriptorProto.Type" }, { "name": "type_name", "number": 6, "type": 9, "label": 1 }, { "name": "extendee", "number": 2, "type": 9, "label": 1 }, { "name": "default_value", "number": 7, "type": 9, "label": 1 }, { "name": "oneof_index", "number": 9, "type": 5, "label": 1 }, { "name": "json_name", "number": 10, "type": 9, "label": 1 }, { "name": "options", "number": 8, "type": 11, "label": 1, "typeName": ".google.protobuf.FieldOptions" }, { "name": "proto3_optional", "number": 17, "type": 8, "label": 1 }], "enumType": [{ "name": "Type", "value": [{ "name": "TYPE_DOUBLE", "number": 1 }, { "name": "TYPE_FLOAT", "number": 2 }, { "name": "TYPE_INT64", "number": 3 }, { "name": "TYPE_UINT64", "number": 4 }, { "name": "TYPE_INT32", "number": 5 }, { "name": "TYPE_FIXED64", "number": 6 }, { "name": "TYPE_FIXED32", "number": 7 }, { "name": "TYPE_BOOL", "number": 8 }, { "name": "TYPE_STRING", "number": 9 }, { "name": "TYPE_GROUP", "number": 10 }, { "name": "TYPE_MESSAGE", "number": 11 }, { "name": "TYPE_BYTES", "number": 12 }, { "name": "TYPE_UINT32", "number": 13 }, { "name": "TYPE_ENUM", "number": 14 }, { "name": "TYPE_SFIXED32", "number": 15 }, { "name": "TYPE_SFIXED64", "number": 16 }, { "name": "TYPE_SINT32", "number": 17 }, { "name": "TYPE_SINT64", "number": 18 }] }, { "name": "Label", "value": [{ "name": "LABEL_OPTIONAL", "number": 1 }, { "name": "LABEL_REPEATED", "number": 3 }, { "name": "LABEL_REQUIRED", "number": 2 }] }] }, { "name": "OneofDescriptorProto", "field": [{ "name": "name", "number": 1, "type": 9, "label": 1 }, { "name": "options", "number": 2, "type": 11, "label": 1, "typeName": ".google.protobuf.OneofOptions" }] }, { "name": "EnumDescriptorProto", "field": [{ "name": "name", "number": 1, "type": 9, "label": 1 }, { "name": "value", "number": 2, "type": 11, "label": 3, "typeName": ".google.protobuf.EnumValueDescriptorProto" }, { "name": "options", "number": 3, "type": 11, "label": 1, "typeName": ".google.protobuf.EnumOptions" }, { "name": "reserved_range", "number": 4, "type": 11, "label": 3, "typeName": ".google.protobuf.EnumDescriptorProto.EnumReservedRange" }, { "name": "reserved_name", "number": 5, "type": 9, "label": 3 }, { "name": "visibility", "number": 6, "type": 14, "label": 1, "typeName": ".google.protobuf.SymbolVisibility" }], "nestedType": [{ "name": "EnumReservedRange", "field": [{ "name": "start", "number": 1, "type": 5, "label": 1 }, { "name": "end", "number": 2, "type": 5, "label": 1 }] }] }, { "name": "EnumValueDescriptorProto", "field": [{ "name": "name", "number": 1, "type": 9, "label": 1 }, { "name": "number", "number": 2, "type": 5, "label": 1 }, { "name": "options", "number": 3, "type": 11, "label": 1, "typeName": ".google.protobuf.EnumValueOptions" }] }, { "name": "ServiceDescriptorProto", "field": [{ "name": "name", "number": 1, "type": 9, "label": 1 }, { "name": "method", "number": 2, "type": 11, "label": 3, "typeName": ".google.protobuf.MethodDescriptorProto" }, { "name": "options", "number": 3, "type": 11, "label": 1, "typeName": ".google.protobuf.ServiceOptions" }] }, { "name": "MethodDescriptorProto", "field": [{ "name": "name", "number": 1, "type": 9, "label": 1 }, { "name": "input_type", "number": 2, "type": 9, "label": 1 }, { "name": "output_type", "number": 3, "type": 9, "label": 1 }, { "name": "options", "number": 4, "type": 11, "label": 1, "typeName": ".google.protobuf.MethodOptions" }, { "name": "client_streaming", "number": 5, "type": 8, "label": 1, "defaultValue": "false" }, { "name": "server_streaming", "number": 6, "type": 8, "label": 1, "defaultValue": "false" }] }, { "name": "FileOptions", "field": [{ "name": "java_package", "number": 1, "type": 9, "label": 1 }, { "name": "java_outer_classname", "number": 8, "type": 9, "label": 1 }, { "name": "java_multiple_files", "number": 10, "type": 8, "label": 1, "defaultValue": "false", "options": {} }, { "name": "java_generate_equals_and_hash", "number": 20, "type": 8, "label": 1, "options": { "deprecated": true } }, { "name": "java_string_check_utf8", "number": 27, "type": 8, "label": 1, "defaultValue": "false" }, { "name": "optimize_for", "number": 9, "type": 14, "label": 1, "typeName": ".google.protobuf.FileOptions.OptimizeMode", "defaultValue": "SPEED" }, { "name": "go_package", "number": 11, "type": 9, "label": 1 }, { "name": "cc_generic_services", "number": 16, "type": 8, "label": 1, "defaultValue": "false" }, { "name": "java_generic_services", "number": 17, "type": 8, "label": 1, "defaultValue": "false" }, { "name": "py_generic_services", "number": 18, "type": 8, "label": 1, "defaultValue": "false" }, { "name": "deprecated", "number": 23, "type": 8, "label": 1, "defaultValue": "false" }, { "name": "cc_enable_arenas", "number": 31, "type": 8, "label": 1, "defaultValue": "true" }, { "name": "objc_class_prefix", "number": 36, "type": 9, "label": 1 }, { "name": "csharp_namespace", "number": 37, "type": 9, "label": 1 }, { "name": "swift_prefix", "number": 39, "type": 9, "label": 1 }, { "name": "php_class_prefix", "number": 40, "type": 9, "label": 1 }, { "name": "php_namespace", "number": 41, "type": 9, "label": 1 }, { "name": "php_metadata_namespace", "number": 44, "type": 9, "label": 1 }, { "name": "ruby_package", "number": 45, "type": 9, "label": 1 }, { "name": "features", "number": 50, "type": 11, "label": 1, "typeName": ".google.protobuf.FeatureSet" }, { "name": "uninterpreted_option", "number": 999, "type": 11, "label": 3, "typeName": ".google.protobuf.UninterpretedOption" }], "enumType": [{ "name": "OptimizeMode", "value": [{ "name": "SPEED", "number": 1 }, { "name": "CODE_SIZE", "number": 2 }, { "name": "LITE_RUNTIME", "number": 3 }] }], "extensionRange": [{ "start": 1e3, "end": 536870912 }] }, { "name": "MessageOptions", "field": [{ "name": "message_set_wire_format", "number": 1, "type": 8, "label": 1, "defaultValue": "false" }, { "name": "no_standard_descriptor_accessor", "number": 2, "type": 8, "label": 1, "defaultValue": "false" }, { "name": "deprecated", "number": 3, "type": 8, "label": 1, "defaultValue": "false" }, { "name": "map_entry", "number": 7, "type": 8, "label": 1 }, { "name": "deprecated_legacy_json_field_conflicts", "number": 11, "type": 8, "label": 1, "options": { "deprecated": true } }, { "name": "features", "number": 12, "type": 11, "label": 1, "typeName": ".google.protobuf.FeatureSet" }, { "name": "uninterpreted_option", "number": 999, "type": 11, "label": 3, "typeName": ".google.protobuf.UninterpretedOption" }], "extensionRange": [{ "start": 1e3, "end": 536870912 }] }, { "name": "FieldOptions", "field": [{ "name": "ctype", "number": 1, "type": 14, "label": 1, "typeName": ".google.protobuf.FieldOptions.CType", "defaultValue": "STRING" }, { "name": "packed", "number": 2, "type": 8, "label": 1 }, { "name": "jstype", "number": 6, "type": 14, "label": 1, "typeName": ".google.protobuf.FieldOptions.JSType", "defaultValue": "JS_NORMAL" }, { "name": "lazy", "number": 5, "type": 8, "label": 1, "defaultValue": "false" }, { "name": "unverified_lazy", "number": 15, "type": 8, "label": 1, "defaultValue": "false" }, { "name": "deprecated", "number": 3, "type": 8, "label": 1, "defaultValue": "false" }, { "name": "weak", "number": 10, "type": 8, "label": 1, "defaultValue": "false", "options": { "deprecated": true } }, { "name": "debug_redact", "number": 16, "type": 8, "label": 1, "defaultValue": "false" }, { "name": "retention", "number": 17, "type": 14, "label": 1, "typeName": ".google.protobuf.FieldOptions.OptionRetention" }, { "name": "targets", "number": 19, "type": 14, "label": 3, "typeName": ".google.protobuf.FieldOptions.OptionTargetType" }, { "name": "edition_defaults", "number": 20, "type": 11, "label": 3, "typeName": ".google.protobuf.FieldOptions.EditionDefault" }, { "name": "features", "number": 21, "type": 11, "label": 1, "typeName": ".google.protobuf.FeatureSet" }, { "name": "feature_support", "number": 22, "type": 11, "label": 1, "typeName": ".google.protobuf.FieldOptions.FeatureSupport" }, { "name": "uninterpreted_option", "number": 999, "type": 11, "label": 3, "typeName": ".google.protobuf.UninterpretedOption" }], "nestedType": [{ "name": "EditionDefault", "field": [{ "name": "edition", "number": 3, "type": 14, "label": 1, "typeName": ".google.protobuf.Edition" }, { "name": "value", "number": 2, "type": 9, "label": 1 }] }, { "name": "FeatureSupport", "field": [{ "name": "edition_introduced", "number": 1, "type": 14, "label": 1, "typeName": ".google.protobuf.Edition" }, { "name": "edition_deprecated", "number": 2, "type": 14, "label": 1, "typeName": ".google.protobuf.Edition" }, { "name": "deprecation_warning", "number": 3, "type": 9, "label": 1 }, { "name": "edition_removed", "number": 4, "type": 14, "label": 1, "typeName": ".google.protobuf.Edition" }, { "name": "removal_error", "number": 5, "type": 9, "label": 1 }] }], "enumType": [{ "name": "CType", "value": [{ "name": "STRING", "number": 0 }, { "name": "CORD", "number": 1 }, { "name": "STRING_PIECE", "number": 2 }] }, { "name": "JSType", "value": [{ "name": "JS_NORMAL", "number": 0 }, { "name": "JS_STRING", "number": 1 }, { "name": "JS_NUMBER", "number": 2 }] }, { "name": "OptionRetention", "value": [{ "name": "RETENTION_UNKNOWN", "number": 0 }, { "name": "RETENTION_RUNTIME", "number": 1 }, { "name": "RETENTION_SOURCE", "number": 2 }] }, { "name": "OptionTargetType", "value": [{ "name": "TARGET_TYPE_UNKNOWN", "number": 0 }, { "name": "TARGET_TYPE_FILE", "number": 1 }, { "name": "TARGET_TYPE_EXTENSION_RANGE", "number": 2 }, { "name": "TARGET_TYPE_MESSAGE", "number": 3 }, { "name": "TARGET_TYPE_FIELD", "number": 4 }, { "name": "TARGET_TYPE_ONEOF", "number": 5 }, { "name": "TARGET_TYPE_ENUM", "number": 6 }, { "name": "TARGET_TYPE_ENUM_ENTRY", "number": 7 }, { "name": "TARGET_TYPE_SERVICE", "number": 8 }, { "name": "TARGET_TYPE_METHOD", "number": 9 }] }], "extensionRange": [{ "start": 1e3, "end": 536870912 }] }, { "name": "OneofOptions", "field": [{ "name": "features", "number": 1, "type": 11, "label": 1, "typeName": ".google.protobuf.FeatureSet" }, { "name": "uninterpreted_option", "number": 999, "type": 11, "label": 3, "typeName": ".google.protobuf.UninterpretedOption" }], "extensionRange": [{ "start": 1e3, "end": 536870912 }] }, { "name": "EnumOptions", "field": [{ "name": "allow_alias", "number": 2, "type": 8, "label": 1 }, { "name": "deprecated", "number": 3, "type": 8, "label": 1, "defaultValue": "false" }, { "name": "deprecated_legacy_json_field_conflicts", "number": 6, "type": 8, "label": 1, "options": { "deprecated": true } }, { "name": "features", "number": 7, "type": 11, "label": 1, "typeName": ".google.protobuf.FeatureSet" }, { "name": "uninterpreted_option", "number": 999, "type": 11, "label": 3, "typeName": ".google.protobuf.UninterpretedOption" }], "extensionRange": [{ "start": 1e3, "end": 536870912 }] }, { "name": "EnumValueOptions", "field": [{ "name": "deprecated", "number": 1, "type": 8, "label": 1, "defaultValue": "false" }, { "name": "features", "number": 2, "type": 11, "label": 1, "typeName": ".google.protobuf.FeatureSet" }, { "name": "debug_redact", "number": 3, "type": 8, "label": 1, "defaultValue": "false" }, { "name": "feature_support", "number": 4, "type": 11, "label": 1, "typeName": ".google.protobuf.FieldOptions.FeatureSupport" }, { "name": "uninterpreted_option", "number": 999, "type": 11, "label": 3, "typeName": ".google.protobuf.UninterpretedOption" }], "extensionRange": [{ "start": 1e3, "end": 536870912 }] }, { "name": "ServiceOptions", "field": [{ "name": "features", "number": 34, "type": 11, "label": 1, "typeName": ".google.protobuf.FeatureSet" }, { "name": "deprecated", "number": 33, "type": 8, "label": 1, "defaultValue": "false" }, { "name": "uninterpreted_option", "number": 999, "type": 11, "label": 3, "typeName": ".google.protobuf.UninterpretedOption" }], "extensionRange": [{ "start": 1e3, "end": 536870912 }] }, { "name": "MethodOptions", "field": [{ "name": "deprecated", "number": 33, "type": 8, "label": 1, "defaultValue": "false" }, { "name": "idempotency_level", "number": 34, "type": 14, "label": 1, "typeName": ".google.protobuf.MethodOptions.IdempotencyLevel", "defaultValue": "IDEMPOTENCY_UNKNOWN" }, { "name": "features", "number": 35, "type": 11, "label": 1, "typeName": ".google.protobuf.FeatureSet" }, { "name": "uninterpreted_option", "number": 999, "type": 11, "label": 3, "typeName": ".google.protobuf.UninterpretedOption" }], "enumType": [{ "name": "IdempotencyLevel", "value": [{ "name": "IDEMPOTENCY_UNKNOWN", "number": 0 }, { "name": "NO_SIDE_EFFECTS", "number": 1 }, { "name": "IDEMPOTENT", "number": 2 }] }], "extensionRange": [{ "start": 1e3, "end": 536870912 }] }, { "name": "UninterpretedOption", "field": [{ "name": "name", "number": 2, "type": 11, "label": 3, "typeName": ".google.protobuf.UninterpretedOption.NamePart" }, { "name": "identifier_value", "number": 3, "type": 9, "label": 1 }, { "name": "positive_int_value", "number": 4, "type": 4, "label": 1 }, { "name": "negative_int_value", "number": 5, "type": 3, "label": 1 }, { "name": "double_value", "number": 6, "type": 1, "label": 1 }, { "name": "string_value", "number": 7, "type": 12, "label": 1 }, { "name": "aggregate_value", "number": 8, "type": 9, "label": 1 }], "nestedType": [{ "name": "NamePart", "field": [{ "name": "name_part", "number": 1, "type": 9, "label": 2 }, { "name": "is_extension", "number": 2, "type": 8, "label": 2 }] }] }, { "name": "FeatureSet", "field": [{ "name": "field_presence", "number": 1, "type": 14, "label": 1, "typeName": ".google.protobuf.FeatureSet.FieldPresence", "options": { "retention": 1, "targets": [4, 1], "editionDefaults": [{ "value": "EXPLICIT", "edition": 900 }, { "value": "IMPLICIT", "edition": 999 }, { "value": "EXPLICIT", "edition": 1e3 }] } }, { "name": "enum_type", "number": 2, "type": 14, "label": 1, "typeName": ".google.protobuf.FeatureSet.EnumType", "options": { "retention": 1, "targets": [6, 1], "editionDefaults": [{ "value": "CLOSED", "edition": 900 }, { "value": "OPEN", "edition": 999 }] } }, { "name": "repeated_field_encoding", "number": 3, "type": 14, "label": 1, "typeName": ".google.protobuf.FeatureSet.RepeatedFieldEncoding", "options": { "retention": 1, "targets": [4, 1], "editionDefaults": [{ "value": "EXPANDED", "edition": 900 }, { "value": "PACKED", "edition": 999 }] } }, { "name": "utf8_validation", "number": 4, "type": 14, "label": 1, "typeName": ".google.protobuf.FeatureSet.Utf8Validation", "options": { "retention": 1, "targets": [4, 1], "editionDefaults": [{ "value": "NONE", "edition": 900 }, { "value": "VERIFY", "edition": 999 }] } }, { "name": "message_encoding", "number": 5, "type": 14, "label": 1, "typeName": ".google.protobuf.FeatureSet.MessageEncoding", "options": { "retention": 1, "targets": [4, 1], "editionDefaults": [{ "value": "LENGTH_PREFIXED", "edition": 900 }] } }, { "name": "json_format", "number": 6, "type": 14, "label": 1, "typeName": ".google.protobuf.FeatureSet.JsonFormat", "options": { "retention": 1, "targets": [3, 6, 1], "editionDefaults": [{ "value": "LEGACY_BEST_EFFORT", "edition": 900 }, { "value": "ALLOW", "edition": 999 }] } }, { "name": "enforce_naming_style", "number": 7, "type": 14, "label": 1, "typeName": ".google.protobuf.FeatureSet.EnforceNamingStyle", "options": { "retention": 2, "targets": [1, 2, 3, 4, 5, 6, 7, 8, 9], "editionDefaults": [{ "value": "STYLE_LEGACY", "edition": 900 }, { "value": "STYLE2024", "edition": 1001 }] } }, { "name": "default_symbol_visibility", "number": 8, "type": 14, "label": 1, "typeName": ".google.protobuf.FeatureSet.VisibilityFeature.DefaultSymbolVisibility", "options": { "retention": 2, "targets": [1], "editionDefaults": [{ "value": "EXPORT_ALL", "edition": 900 }, { "value": "EXPORT_TOP_LEVEL", "edition": 1001 }] } }], "nestedType": [{ "name": "VisibilityFeature", "enumType": [{ "name": "DefaultSymbolVisibility", "value": [{ "name": "DEFAULT_SYMBOL_VISIBILITY_UNKNOWN", "number": 0 }, { "name": "EXPORT_ALL", "number": 1 }, { "name": "EXPORT_TOP_LEVEL", "number": 2 }, { "name": "LOCAL_ALL", "number": 3 }, { "name": "STRICT", "number": 4 }] }] }], "enumType": [{ "name": "FieldPresence", "value": [{ "name": "FIELD_PRESENCE_UNKNOWN", "number": 0 }, { "name": "EXPLICIT", "number": 1 }, { "name": "IMPLICIT", "number": 2 }, { "name": "LEGACY_REQUIRED", "number": 3 }] }, { "name": "EnumType", "value": [{ "name": "ENUM_TYPE_UNKNOWN", "number": 0 }, { "name": "OPEN", "number": 1 }, { "name": "CLOSED", "number": 2 }] }, { "name": "RepeatedFieldEncoding", "value": [{ "name": "REPEATED_FIELD_ENCODING_UNKNOWN", "number": 0 }, { "name": "PACKED", "number": 1 }, { "name": "EXPANDED", "number": 2 }] }, { "name": "Utf8Validation", "value": [{ "name": "UTF8_VALIDATION_UNKNOWN", "number": 0 }, { "name": "VERIFY", "number": 2 }, { "name": "NONE", "number": 3 }] }, { "name": "MessageEncoding", "value": [{ "name": "MESSAGE_ENCODING_UNKNOWN", "number": 0 }, { "name": "LENGTH_PREFIXED", "number": 1 }, { "name": "DELIMITED", "number": 2 }] }, { "name": "JsonFormat", "value": [{ "name": "JSON_FORMAT_UNKNOWN", "number": 0 }, { "name": "ALLOW", "number": 1 }, { "name": "LEGACY_BEST_EFFORT", "number": 2 }] }, { "name": "EnforceNamingStyle", "value": [{ "name": "ENFORCE_NAMING_STYLE_UNKNOWN", "number": 0 }, { "name": "STYLE2024", "number": 1 }, { "name": "STYLE_LEGACY", "number": 2 }] }], "extensionRange": [{ "start": 1e3, "end": 9995 }, { "start": 9995, "end": 1e4 }, { "start": 1e4, "end": 10001 }] }, { "name": "FeatureSetDefaults", "field": [{ "name": "defaults", "number": 1, "type": 11, "label": 3, "typeName": ".google.protobuf.FeatureSetDefaults.FeatureSetEditionDefault" }, { "name": "minimum_edition", "number": 4, "type": 14, "label": 1, "typeName": ".google.protobuf.Edition" }, { "name": "maximum_edition", "number": 5, "type": 14, "label": 1, "typeName": ".google.protobuf.Edition" }], "nestedType": [{ "name": "FeatureSetEditionDefault", "field": [{ "name": "edition", "number": 3, "type": 14, "label": 1, "typeName": ".google.protobuf.Edition" }, { "name": "overridable_features", "number": 4, "type": 11, "label": 1, "typeName": ".google.protobuf.FeatureSet" }, { "name": "fixed_features", "number": 5, "type": 11, "label": 1, "typeName": ".google.protobuf.FeatureSet" }] }] }, { "name": "SourceCodeInfo", "field": [{ "name": "location", "number": 1, "type": 11, "label": 3, "typeName": ".google.protobuf.SourceCodeInfo.Location" }], "nestedType": [{ "name": "Location", "field": [{ "name": "path", "number": 1, "type": 5, "label": 3, "options": { "packed": true } }, { "name": "span", "number": 2, "type": 5, "label": 3, "options": { "packed": true } }, { "name": "leading_comments", "number": 3, "type": 9, "label": 1 }, { "name": "trailing_comments", "number": 4, "type": 9, "label": 1 }, { "name": "leading_detached_comments", "number": 6, "type": 9, "label": 3 }] }], "extensionRange": [{ "start": 536e6, "end": 536000001 }] }, { "name": "GeneratedCodeInfo", "field": [{ "name": "annotation", "number": 1, "type": 11, "label": 3, "typeName": ".google.protobuf.GeneratedCodeInfo.Annotation" }], "nestedType": [{ "name": "Annotation", "field": [{ "name": "path", "number": 1, "type": 5, "label": 3, "options": { "packed": true } }, { "name": "source_file", "number": 2, "type": 9, "label": 1 }, { "name": "begin", "number": 3, "type": 5, "label": 1 }, { "name": "end", "number": 4, "type": 5, "label": 1 }, { "name": "semantic", "number": 5, "type": 14, "label": 1, "typeName": ".google.protobuf.GeneratedCodeInfo.Annotation.Semantic" }], "enumType": [{ "name": "Semantic", "value": [{ "name": "NONE", "number": 0 }, { "name": "SET", "number": 1 }, { "name": "ALIAS", "number": 2 }] }] }] }], "enumType": [{ "name": "Edition", "value": [{ "name": "EDITION_UNKNOWN", "number": 0 }, { "name": "EDITION_LEGACY", "number": 900 }, { "name": "EDITION_PROTO2", "number": 998 }, { "name": "EDITION_PROTO3", "number": 999 }, { "name": "EDITION_2023", "number": 1e3 }, { "name": "EDITION_2024", "number": 1001 }, { "name": "EDITION_UNSTABLE", "number": 9999 }, { "name": "EDITION_1_TEST_ONLY", "number": 1 }, { "name": "EDITION_2_TEST_ONLY", "number": 2 }, { "name": "EDITION_99997_TEST_ONLY", "number": 99997 }, { "name": "EDITION_99998_TEST_ONLY", "number": 99998 }, { "name": "EDITION_99999_TEST_ONLY", "number": 99999 }, { "name": "EDITION_MAX", "number": 2147483647 }] }, { "name": "SymbolVisibility", "value": [{ "name": "VISIBILITY_UNSET", "number": 0 }, { "name": "VISIBILITY_LOCAL", "number": 1 }, { "name": "VISIBILITY_EXPORT", "number": 2 }] }] });
  var FileDescriptorProtoSchema = /* @__PURE__ */ messageDesc(file_google_protobuf_descriptor, 1);
  var ExtensionRangeOptions_VerificationState;
  (function(ExtensionRangeOptions_VerificationState2) {
    ExtensionRangeOptions_VerificationState2[ExtensionRangeOptions_VerificationState2["DECLARATION"] = 0] = "DECLARATION";
    ExtensionRangeOptions_VerificationState2[ExtensionRangeOptions_VerificationState2["UNVERIFIED"] = 1] = "UNVERIFIED";
  })(ExtensionRangeOptions_VerificationState || (ExtensionRangeOptions_VerificationState = {}));
  var FieldDescriptorProto_Type;
  (function(FieldDescriptorProto_Type2) {
    FieldDescriptorProto_Type2[FieldDescriptorProto_Type2["DOUBLE"] = 1] = "DOUBLE";
    FieldDescriptorProto_Type2[FieldDescriptorProto_Type2["FLOAT"] = 2] = "FLOAT";
    FieldDescriptorProto_Type2[FieldDescriptorProto_Type2["INT64"] = 3] = "INT64";
    FieldDescriptorProto_Type2[FieldDescriptorProto_Type2["UINT64"] = 4] = "UINT64";
    FieldDescriptorProto_Type2[FieldDescriptorProto_Type2["INT32"] = 5] = "INT32";
    FieldDescriptorProto_Type2[FieldDescriptorProto_Type2["FIXED64"] = 6] = "FIXED64";
    FieldDescriptorProto_Type2[FieldDescriptorProto_Type2["FIXED32"] = 7] = "FIXED32";
    FieldDescriptorProto_Type2[FieldDescriptorProto_Type2["BOOL"] = 8] = "BOOL";
    FieldDescriptorProto_Type2[FieldDescriptorProto_Type2["STRING"] = 9] = "STRING";
    FieldDescriptorProto_Type2[FieldDescriptorProto_Type2["GROUP"] = 10] = "GROUP";
    FieldDescriptorProto_Type2[FieldDescriptorProto_Type2["MESSAGE"] = 11] = "MESSAGE";
    FieldDescriptorProto_Type2[FieldDescriptorProto_Type2["BYTES"] = 12] = "BYTES";
    FieldDescriptorProto_Type2[FieldDescriptorProto_Type2["UINT32"] = 13] = "UINT32";
    FieldDescriptorProto_Type2[FieldDescriptorProto_Type2["ENUM"] = 14] = "ENUM";
    FieldDescriptorProto_Type2[FieldDescriptorProto_Type2["SFIXED32"] = 15] = "SFIXED32";
    FieldDescriptorProto_Type2[FieldDescriptorProto_Type2["SFIXED64"] = 16] = "SFIXED64";
    FieldDescriptorProto_Type2[FieldDescriptorProto_Type2["SINT32"] = 17] = "SINT32";
    FieldDescriptorProto_Type2[FieldDescriptorProto_Type2["SINT64"] = 18] = "SINT64";
  })(FieldDescriptorProto_Type || (FieldDescriptorProto_Type = {}));
  var FieldDescriptorProto_Label;
  (function(FieldDescriptorProto_Label2) {
    FieldDescriptorProto_Label2[FieldDescriptorProto_Label2["OPTIONAL"] = 1] = "OPTIONAL";
    FieldDescriptorProto_Label2[FieldDescriptorProto_Label2["REPEATED"] = 3] = "REPEATED";
    FieldDescriptorProto_Label2[FieldDescriptorProto_Label2["REQUIRED"] = 2] = "REQUIRED";
  })(FieldDescriptorProto_Label || (FieldDescriptorProto_Label = {}));
  var FileOptions_OptimizeMode;
  (function(FileOptions_OptimizeMode2) {
    FileOptions_OptimizeMode2[FileOptions_OptimizeMode2["SPEED"] = 1] = "SPEED";
    FileOptions_OptimizeMode2[FileOptions_OptimizeMode2["CODE_SIZE"] = 2] = "CODE_SIZE";
    FileOptions_OptimizeMode2[FileOptions_OptimizeMode2["LITE_RUNTIME"] = 3] = "LITE_RUNTIME";
  })(FileOptions_OptimizeMode || (FileOptions_OptimizeMode = {}));
  var FieldOptions_CType;
  (function(FieldOptions_CType2) {
    FieldOptions_CType2[FieldOptions_CType2["STRING"] = 0] = "STRING";
    FieldOptions_CType2[FieldOptions_CType2["CORD"] = 1] = "CORD";
    FieldOptions_CType2[FieldOptions_CType2["STRING_PIECE"] = 2] = "STRING_PIECE";
  })(FieldOptions_CType || (FieldOptions_CType = {}));
  var FieldOptions_JSType;
  (function(FieldOptions_JSType2) {
    FieldOptions_JSType2[FieldOptions_JSType2["JS_NORMAL"] = 0] = "JS_NORMAL";
    FieldOptions_JSType2[FieldOptions_JSType2["JS_STRING"] = 1] = "JS_STRING";
    FieldOptions_JSType2[FieldOptions_JSType2["JS_NUMBER"] = 2] = "JS_NUMBER";
  })(FieldOptions_JSType || (FieldOptions_JSType = {}));
  var FieldOptions_OptionRetention;
  (function(FieldOptions_OptionRetention2) {
    FieldOptions_OptionRetention2[FieldOptions_OptionRetention2["RETENTION_UNKNOWN"] = 0] = "RETENTION_UNKNOWN";
    FieldOptions_OptionRetention2[FieldOptions_OptionRetention2["RETENTION_RUNTIME"] = 1] = "RETENTION_RUNTIME";
    FieldOptions_OptionRetention2[FieldOptions_OptionRetention2["RETENTION_SOURCE"] = 2] = "RETENTION_SOURCE";
  })(FieldOptions_OptionRetention || (FieldOptions_OptionRetention = {}));
  var FieldOptions_OptionTargetType;
  (function(FieldOptions_OptionTargetType2) {
    FieldOptions_OptionTargetType2[FieldOptions_OptionTargetType2["TARGET_TYPE_UNKNOWN"] = 0] = "TARGET_TYPE_UNKNOWN";
    FieldOptions_OptionTargetType2[FieldOptions_OptionTargetType2["TARGET_TYPE_FILE"] = 1] = "TARGET_TYPE_FILE";
    FieldOptions_OptionTargetType2[FieldOptions_OptionTargetType2["TARGET_TYPE_EXTENSION_RANGE"] = 2] = "TARGET_TYPE_EXTENSION_RANGE";
    FieldOptions_OptionTargetType2[FieldOptions_OptionTargetType2["TARGET_TYPE_MESSAGE"] = 3] = "TARGET_TYPE_MESSAGE";
    FieldOptions_OptionTargetType2[FieldOptions_OptionTargetType2["TARGET_TYPE_FIELD"] = 4] = "TARGET_TYPE_FIELD";
    FieldOptions_OptionTargetType2[FieldOptions_OptionTargetType2["TARGET_TYPE_ONEOF"] = 5] = "TARGET_TYPE_ONEOF";
    FieldOptions_OptionTargetType2[FieldOptions_OptionTargetType2["TARGET_TYPE_ENUM"] = 6] = "TARGET_TYPE_ENUM";
    FieldOptions_OptionTargetType2[FieldOptions_OptionTargetType2["TARGET_TYPE_ENUM_ENTRY"] = 7] = "TARGET_TYPE_ENUM_ENTRY";
    FieldOptions_OptionTargetType2[FieldOptions_OptionTargetType2["TARGET_TYPE_SERVICE"] = 8] = "TARGET_TYPE_SERVICE";
    FieldOptions_OptionTargetType2[FieldOptions_OptionTargetType2["TARGET_TYPE_METHOD"] = 9] = "TARGET_TYPE_METHOD";
  })(FieldOptions_OptionTargetType || (FieldOptions_OptionTargetType = {}));
  var MethodOptions_IdempotencyLevel;
  (function(MethodOptions_IdempotencyLevel2) {
    MethodOptions_IdempotencyLevel2[MethodOptions_IdempotencyLevel2["IDEMPOTENCY_UNKNOWN"] = 0] = "IDEMPOTENCY_UNKNOWN";
    MethodOptions_IdempotencyLevel2[MethodOptions_IdempotencyLevel2["NO_SIDE_EFFECTS"] = 1] = "NO_SIDE_EFFECTS";
    MethodOptions_IdempotencyLevel2[MethodOptions_IdempotencyLevel2["IDEMPOTENT"] = 2] = "IDEMPOTENT";
  })(MethodOptions_IdempotencyLevel || (MethodOptions_IdempotencyLevel = {}));
  var FeatureSet_VisibilityFeature_DefaultSymbolVisibility;
  (function(FeatureSet_VisibilityFeature_DefaultSymbolVisibility2) {
    FeatureSet_VisibilityFeature_DefaultSymbolVisibility2[FeatureSet_VisibilityFeature_DefaultSymbolVisibility2["DEFAULT_SYMBOL_VISIBILITY_UNKNOWN"] = 0] = "DEFAULT_SYMBOL_VISIBILITY_UNKNOWN";
    FeatureSet_VisibilityFeature_DefaultSymbolVisibility2[FeatureSet_VisibilityFeature_DefaultSymbolVisibility2["EXPORT_ALL"] = 1] = "EXPORT_ALL";
    FeatureSet_VisibilityFeature_DefaultSymbolVisibility2[FeatureSet_VisibilityFeature_DefaultSymbolVisibility2["EXPORT_TOP_LEVEL"] = 2] = "EXPORT_TOP_LEVEL";
    FeatureSet_VisibilityFeature_DefaultSymbolVisibility2[FeatureSet_VisibilityFeature_DefaultSymbolVisibility2["LOCAL_ALL"] = 3] = "LOCAL_ALL";
    FeatureSet_VisibilityFeature_DefaultSymbolVisibility2[FeatureSet_VisibilityFeature_DefaultSymbolVisibility2["STRICT"] = 4] = "STRICT";
  })(FeatureSet_VisibilityFeature_DefaultSymbolVisibility || (FeatureSet_VisibilityFeature_DefaultSymbolVisibility = {}));
  var FeatureSet_FieldPresence;
  (function(FeatureSet_FieldPresence2) {
    FeatureSet_FieldPresence2[FeatureSet_FieldPresence2["FIELD_PRESENCE_UNKNOWN"] = 0] = "FIELD_PRESENCE_UNKNOWN";
    FeatureSet_FieldPresence2[FeatureSet_FieldPresence2["EXPLICIT"] = 1] = "EXPLICIT";
    FeatureSet_FieldPresence2[FeatureSet_FieldPresence2["IMPLICIT"] = 2] = "IMPLICIT";
    FeatureSet_FieldPresence2[FeatureSet_FieldPresence2["LEGACY_REQUIRED"] = 3] = "LEGACY_REQUIRED";
  })(FeatureSet_FieldPresence || (FeatureSet_FieldPresence = {}));
  var FeatureSet_EnumType;
  (function(FeatureSet_EnumType2) {
    FeatureSet_EnumType2[FeatureSet_EnumType2["ENUM_TYPE_UNKNOWN"] = 0] = "ENUM_TYPE_UNKNOWN";
    FeatureSet_EnumType2[FeatureSet_EnumType2["OPEN"] = 1] = "OPEN";
    FeatureSet_EnumType2[FeatureSet_EnumType2["CLOSED"] = 2] = "CLOSED";
  })(FeatureSet_EnumType || (FeatureSet_EnumType = {}));
  var FeatureSet_RepeatedFieldEncoding;
  (function(FeatureSet_RepeatedFieldEncoding2) {
    FeatureSet_RepeatedFieldEncoding2[FeatureSet_RepeatedFieldEncoding2["REPEATED_FIELD_ENCODING_UNKNOWN"] = 0] = "REPEATED_FIELD_ENCODING_UNKNOWN";
    FeatureSet_RepeatedFieldEncoding2[FeatureSet_RepeatedFieldEncoding2["PACKED"] = 1] = "PACKED";
    FeatureSet_RepeatedFieldEncoding2[FeatureSet_RepeatedFieldEncoding2["EXPANDED"] = 2] = "EXPANDED";
  })(FeatureSet_RepeatedFieldEncoding || (FeatureSet_RepeatedFieldEncoding = {}));
  var FeatureSet_Utf8Validation;
  (function(FeatureSet_Utf8Validation2) {
    FeatureSet_Utf8Validation2[FeatureSet_Utf8Validation2["UTF8_VALIDATION_UNKNOWN"] = 0] = "UTF8_VALIDATION_UNKNOWN";
    FeatureSet_Utf8Validation2[FeatureSet_Utf8Validation2["VERIFY"] = 2] = "VERIFY";
    FeatureSet_Utf8Validation2[FeatureSet_Utf8Validation2["NONE"] = 3] = "NONE";
  })(FeatureSet_Utf8Validation || (FeatureSet_Utf8Validation = {}));
  var FeatureSet_MessageEncoding;
  (function(FeatureSet_MessageEncoding2) {
    FeatureSet_MessageEncoding2[FeatureSet_MessageEncoding2["MESSAGE_ENCODING_UNKNOWN"] = 0] = "MESSAGE_ENCODING_UNKNOWN";
    FeatureSet_MessageEncoding2[FeatureSet_MessageEncoding2["LENGTH_PREFIXED"] = 1] = "LENGTH_PREFIXED";
    FeatureSet_MessageEncoding2[FeatureSet_MessageEncoding2["DELIMITED"] = 2] = "DELIMITED";
  })(FeatureSet_MessageEncoding || (FeatureSet_MessageEncoding = {}));
  var FeatureSet_JsonFormat;
  (function(FeatureSet_JsonFormat2) {
    FeatureSet_JsonFormat2[FeatureSet_JsonFormat2["JSON_FORMAT_UNKNOWN"] = 0] = "JSON_FORMAT_UNKNOWN";
    FeatureSet_JsonFormat2[FeatureSet_JsonFormat2["ALLOW"] = 1] = "ALLOW";
    FeatureSet_JsonFormat2[FeatureSet_JsonFormat2["LEGACY_BEST_EFFORT"] = 2] = "LEGACY_BEST_EFFORT";
  })(FeatureSet_JsonFormat || (FeatureSet_JsonFormat = {}));
  var FeatureSet_EnforceNamingStyle;
  (function(FeatureSet_EnforceNamingStyle2) {
    FeatureSet_EnforceNamingStyle2[FeatureSet_EnforceNamingStyle2["ENFORCE_NAMING_STYLE_UNKNOWN"] = 0] = "ENFORCE_NAMING_STYLE_UNKNOWN";
    FeatureSet_EnforceNamingStyle2[FeatureSet_EnforceNamingStyle2["STYLE2024"] = 1] = "STYLE2024";
    FeatureSet_EnforceNamingStyle2[FeatureSet_EnforceNamingStyle2["STYLE_LEGACY"] = 2] = "STYLE_LEGACY";
  })(FeatureSet_EnforceNamingStyle || (FeatureSet_EnforceNamingStyle = {}));
  var GeneratedCodeInfo_Annotation_Semantic;
  (function(GeneratedCodeInfo_Annotation_Semantic2) {
    GeneratedCodeInfo_Annotation_Semantic2[GeneratedCodeInfo_Annotation_Semantic2["NONE"] = 0] = "NONE";
    GeneratedCodeInfo_Annotation_Semantic2[GeneratedCodeInfo_Annotation_Semantic2["SET"] = 1] = "SET";
    GeneratedCodeInfo_Annotation_Semantic2[GeneratedCodeInfo_Annotation_Semantic2["ALIAS"] = 2] = "ALIAS";
  })(GeneratedCodeInfo_Annotation_Semantic || (GeneratedCodeInfo_Annotation_Semantic = {}));
  var Edition;
  (function(Edition2) {
    Edition2[Edition2["EDITION_UNKNOWN"] = 0] = "EDITION_UNKNOWN";
    Edition2[Edition2["EDITION_LEGACY"] = 900] = "EDITION_LEGACY";
    Edition2[Edition2["EDITION_PROTO2"] = 998] = "EDITION_PROTO2";
    Edition2[Edition2["EDITION_PROTO3"] = 999] = "EDITION_PROTO3";
    Edition2[Edition2["EDITION_2023"] = 1e3] = "EDITION_2023";
    Edition2[Edition2["EDITION_2024"] = 1001] = "EDITION_2024";
    Edition2[Edition2["EDITION_UNSTABLE"] = 9999] = "EDITION_UNSTABLE";
    Edition2[Edition2["EDITION_1_TEST_ONLY"] = 1] = "EDITION_1_TEST_ONLY";
    Edition2[Edition2["EDITION_2_TEST_ONLY"] = 2] = "EDITION_2_TEST_ONLY";
    Edition2[Edition2["EDITION_99997_TEST_ONLY"] = 99997] = "EDITION_99997_TEST_ONLY";
    Edition2[Edition2["EDITION_99998_TEST_ONLY"] = 99998] = "EDITION_99998_TEST_ONLY";
    Edition2[Edition2["EDITION_99999_TEST_ONLY"] = 99999] = "EDITION_99999_TEST_ONLY";
    Edition2[Edition2["EDITION_MAX"] = 2147483647] = "EDITION_MAX";
  })(Edition || (Edition = {}));
  var SymbolVisibility;
  (function(SymbolVisibility2) {
    SymbolVisibility2[SymbolVisibility2["VISIBILITY_UNSET"] = 0] = "VISIBILITY_UNSET";
    SymbolVisibility2[SymbolVisibility2["VISIBILITY_LOCAL"] = 1] = "VISIBILITY_LOCAL";
    SymbolVisibility2[SymbolVisibility2["VISIBILITY_EXPORT"] = 2] = "VISIBILITY_EXPORT";
  })(SymbolVisibility || (SymbolVisibility = {}));

  // client/node_modules/@bufbuild/protobuf/dist/esm/from-binary.js
  function makeReadContext(options) {
    return Object.assign(Object.assign({ readUnknownFields: true, recursionLimit: 100 }, options), { depth: 0 });
  }
  function fromBinary(schema, bytes, options) {
    const message2 = create(schema);
    compiledReader(schema).read(message2, new BinaryReader(bytes), makeReadContext(options), bytes.byteLength);
    return message2;
  }
  var compiledReaders = /* @__PURE__ */ new WeakMap();
  function compiledReader(desc) {
    let compiled = compiledReaders.get(desc);
    if (compiled === void 0) {
      compiled = compileMessage(desc);
    }
    return compiled;
  }
  function compileMessage(desc) {
    const descString = String(desc);
    const fieldReaders = /* @__PURE__ */ new Map();
    const compiled = {
      read: compileMessageReader(descString, fieldReaders),
      readGroup: compileGroupReader(descString, fieldReaders)
    };
    compiledReaders.set(desc, compiled);
    for (const field of desc.fields) {
      fieldReaders.set(field.number, compileFieldReader(field));
    }
    return compiled;
  }
  function compileMessageReader(descString, fieldReaders) {
    return (message2, reader, ctx, length) => {
      var _a;
      if (++ctx.depth > ctx.recursionLimit) {
        throw new Error(`cannot decode ${descString} from binary: maximum recursion depth of ${ctx.recursionLimit} reached`);
      }
      const end = reader.pos + length;
      const unknownFields = (_a = message2.$unknown) !== null && _a !== void 0 ? _a : [];
      while (reader.pos < end) {
        const [fieldNo, wireType] = reader.tag();
        const fieldReader = fieldReaders.get(fieldNo);
        if (fieldReader === void 0) {
          const data2 = reader.skip(wireType, fieldNo, ctx.recursionLimit - ctx.depth);
          if (ctx.readUnknownFields) {
            unknownFields.push({ no: fieldNo, wireType, data: data2 });
          }
          continue;
        }
        fieldReader(message2, reader, ctx, wireType);
      }
      if (unknownFields.length > 0) {
        message2.$unknown = unknownFields;
      }
      ctx.depth--;
    };
  }
  function compileGroupReader(descString, fieldReaders) {
    return (message2, reader, ctx, fieldNo) => {
      var _a;
      if (++ctx.depth > ctx.recursionLimit) {
        throw new Error(`cannot decode ${descString} from binary: maximum recursion depth of ${ctx.recursionLimit} reached`);
      }
      let recordFieldNo;
      let wireType;
      const unknownFields = (_a = message2.$unknown) !== null && _a !== void 0 ? _a : [];
      while (reader.pos < reader.len) {
        [recordFieldNo, wireType] = reader.tag();
        if (wireType == WireType.EndGroup) {
          break;
        }
        const fieldReader = fieldReaders.get(recordFieldNo);
        if (fieldReader === void 0) {
          const data2 = reader.skip(wireType, recordFieldNo, ctx.recursionLimit - ctx.depth);
          if (ctx.readUnknownFields) {
            unknownFields.push({ no: recordFieldNo, wireType, data: data2 });
          }
          continue;
        }
        fieldReader(message2, reader, ctx, wireType);
      }
      if (wireType != WireType.EndGroup || recordFieldNo !== fieldNo) {
        throw new Error("invalid end group tag");
      }
      if (unknownFields.length > 0) {
        message2.$unknown = unknownFields;
      }
      ctx.depth--;
    };
  }
  function readField(message2, reader, field, wireType, ctx) {
    compileFieldReader(field)(message2[unsafeLocal], reader, ctx, wireType);
  }
  function compileFieldReader(field) {
    switch (field.fieldKind) {
      case "scalar":
        return compileScalarFieldReader(field);
      case "enum":
        return compileEnumFieldReader(field);
      case "message":
        return compileMessageFieldReader(field);
      case "list":
        return compileListFieldReader(field);
      case "map":
        return compileMapFieldReader(field);
    }
  }
  function compileScalarFieldReader(field) {
    const readScalar = compileScalarReader(field.scalar, field.utf8Validation, field.longAsString);
    const localName = field.localName;
    if (field.oneof) {
      const oneofLocalName = field.oneof.localName;
      return (message2, reader) => {
        message2[oneofLocalName] = {
          case: localName,
          value: readScalar(reader)
        };
      };
    }
    return (message2, reader) => {
      message2[localName] = readScalar(reader);
    };
  }
  function compileEnumFieldReader(field) {
    var _a;
    const localName = field.localName;
    const oneofLocalName = (_a = field.oneof) === null || _a === void 0 ? void 0 : _a.localName;
    if (field.enum.open) {
      if (oneofLocalName !== void 0) {
        return (message2, reader) => {
          message2[oneofLocalName] = { case: localName, value: reader.int32() };
        };
      }
      return (message2, reader) => {
        message2[localName] = reader.int32();
      };
    }
    const values = field.enum.values;
    const fieldNo = field.number;
    return (message2, reader, ctx, wireType) => {
      var _a2;
      const val = reader.int32();
      if (values.some((v) => v.number === val)) {
        if (oneofLocalName !== void 0) {
          message2[oneofLocalName] = { case: localName, value: val };
        } else {
          message2[localName] = val;
        }
      } else if (ctx.readUnknownFields) {
        const bytes = [];
        varint32write(val, bytes);
        const unknownFields = (_a2 = message2.$unknown) !== null && _a2 !== void 0 ? _a2 : [];
        unknownFields.push({
          no: fieldNo,
          wireType,
          data: new Uint8Array(bytes)
        });
        message2.$unknown = unknownFields;
      }
    };
  }
  function compileMessageFieldReader(field) {
    const localName = field.localName;
    const { toMessage, toLocal } = localMessageMapper(field);
    const readChild = compileChildReader(field);
    if (field.oneof) {
      const oneofLocalName = field.oneof.localName;
      return (message2, reader, ctx) => {
        const oneof = message2[oneofLocalName];
        const child = toMessage(oneof.case === localName ? oneof.value : void 0);
        readChild(child, reader, ctx);
        message2[oneofLocalName] = { case: localName, value: toLocal(child) };
      };
    }
    return (message2, reader, ctx) => {
      const child = toMessage(message2[localName]);
      readChild(child, reader, ctx);
      message2[localName] = toLocal(child);
    };
  }
  function compileChildReader(field) {
    const compiledChild = compiledReader(field.message);
    if (field.delimitedEncoding) {
      const fieldNo = field.number;
      return (child, reader, ctx) => compiledChild.readGroup(child, reader, ctx, fieldNo);
    }
    return (child, reader, ctx) => compiledChild.read(child, reader, ctx, reader.uint32());
  }
  function compileListFieldReader(field) {
    const localName = field.localName;
    if (field.listKind == "message") {
      const { toMessage, toLocal } = localMessageMapper(field);
      const readChild = compileChildReader(field);
      return (message2, reader, ctx) => {
        const child = toMessage(void 0);
        readChild(child, reader, ctx);
        message2[localName].push(toLocal(child));
      };
    }
    const scalarType = field.listKind == "enum" ? ScalarType.INT32 : field.scalar;
    const longAsString = field.listKind == "scalar" ? field.longAsString : false;
    const readScalar = compileScalarReader(scalarType, field.utf8Validation, longAsString);
    const packedPossible = scalarType != ScalarType.STRING && scalarType != ScalarType.BYTES;
    return (message2, reader, ctx, wireType) => {
      const items = message2[localName];
      if (wireType == WireType.LengthDelimited && packedPossible) {
        const end = reader.uint32() + reader.pos;
        while (reader.pos < end) {
          items.push(readScalar(reader));
        }
      } else {
        items.push(readScalar(reader));
      }
    };
  }
  function compileMapFieldReader(field) {
    const localName = field.localName;
    const readKey = compileScalarReader(field.mapKey, field.utf8Validation, false);
    const keyZero = scalarZeroValue(field.mapKey, false);
    let readValue;
    let valueDefault;
    switch (field.mapKind) {
      case "scalar": {
        const scalar = field.scalar;
        const readScalar = compileScalarReader(scalar, field.utf8Validation, false);
        readValue = (reader) => readScalar(reader);
        if (scalar == ScalarType.BYTES) {
          valueDefault = () => new Uint8Array(0);
        } else {
          const zero = scalarZeroValue(scalar, false);
          valueDefault = () => zero;
        }
        break;
      }
      case "enum": {
        const zero = field.enum.values[0].number;
        readValue = (reader) => reader.int32();
        valueDefault = () => zero;
        break;
      }
      case "message": {
        const { toMessage, toLocal } = localMessageMapper(field);
        const readChild = compiledReader(field.message).read;
        readValue = (reader, ctx) => {
          const child = toMessage(void 0);
          readChild(child, reader, ctx, reader.uint32());
          return toLocal(child);
        };
        valueDefault = () => toLocal(toMessage(void 0));
        break;
      }
    }
    return (message2, reader, ctx) => {
      const record = message2[localName];
      let key;
      let val;
      const len = reader.uint32();
      const end = reader.pos + len;
      while (reader.pos < end) {
        const [fieldNo] = reader.tag();
        switch (fieldNo) {
          case 1:
            key = readKey(reader);
            break;
          case 2:
            val = readValue(reader, ctx);
            break;
        }
      }
      if (key === void 0) {
        key = keyZero;
      }
      if (val === void 0) {
        val = valueDefault();
      }
      record[key] = val;
    };
  }
  function compileScalarReader(type, utf8Validation, longAsString) {
    switch (type) {
      case ScalarType.STRING:
        return (reader) => reader.string(utf8Validation);
      case ScalarType.BOOL:
        return (reader) => reader.bool();
      case ScalarType.DOUBLE:
        return (reader) => reader.double();
      case ScalarType.FLOAT:
        return (reader) => reader.float();
      case ScalarType.INT32:
        return (reader) => reader.int32();
      case ScalarType.INT64:
        if (longAsString) {
          return (reader) => String(reader.int64());
        }
        return (reader) => reader.int64();
      case ScalarType.UINT64:
        if (longAsString) {
          return (reader) => String(reader.uint64());
        }
        return (reader) => reader.uint64();
      case ScalarType.FIXED64:
        if (longAsString) {
          return (reader) => String(reader.fixed64());
        }
        return (reader) => reader.fixed64();
      case ScalarType.BYTES:
        return (reader) => reader.bytes();
      case ScalarType.FIXED32:
        return (reader) => reader.fixed32();
      case ScalarType.SFIXED32:
        return (reader) => reader.sfixed32();
      case ScalarType.SFIXED64:
        if (longAsString) {
          return (reader) => String(reader.sfixed64());
        }
        return (reader) => reader.sfixed64();
      case ScalarType.SINT64:
        if (longAsString) {
          return (reader) => String(reader.sint64());
        }
        return (reader) => reader.sint64();
      case ScalarType.UINT32:
        return (reader) => reader.uint32();
      case ScalarType.SINT32:
        return (reader) => reader.sint32();
    }
  }

  // client/node_modules/@bufbuild/protobuf/dist/esm/codegenv2/file.js
  function fileDesc(b64, imports) {
    var _a;
    const root = fromBinary(FileDescriptorProtoSchema, base64Decode(b64));
    root.messageType.forEach(restoreJsonNames);
    root.dependency = (_a = imports === null || imports === void 0 ? void 0 : imports.map((f) => f.proto.name)) !== null && _a !== void 0 ? _a : [];
    const reg = createFileRegistry(root, (protoFileName) => imports === null || imports === void 0 ? void 0 : imports.find((f) => f.proto.name === protoFileName));
    return reg.getFile(root.name);
  }

  // client/node_modules/@bufbuild/protobuf/dist/esm/wkt/any.js
  function anyIs(any, descOrTypeName) {
    if (any.typeUrl === "") {
      return false;
    }
    const want = typeof descOrTypeName == "string" ? descOrTypeName : descOrTypeName.typeName;
    const got = typeUrlToName(any.typeUrl);
    return want === got;
  }
  function anyUnpack(any, registryOrMessageDesc) {
    if (any.typeUrl === "") {
      return void 0;
    }
    const desc = registryOrMessageDesc.kind == "message" ? registryOrMessageDesc : registryOrMessageDesc.getMessage(typeUrlToName(any.typeUrl));
    if (!desc || !anyIs(any, desc)) {
      return void 0;
    }
    return fromBinary(desc, any.value);
  }
  function typeUrlToName(url) {
    const slash = url.lastIndexOf("/");
    const name = slash >= 0 ? url.substring(slash + 1) : url;
    if (!name.length) {
      throw new Error(`invalid type url: ${url}`);
    }
    return name;
  }

  // client/node_modules/@bufbuild/protobuf/dist/esm/extensions.js
  function getExtension(message2, extension, options) {
    assertExtendee(extension, message2);
    const ufs = filterUnknownFields(message2.$unknown, extension);
    const [container, field, get] = createExtensionContainer(extension);
    const ctx = makeReadContext(options);
    for (const uf of ufs) {
      readField(container, new BinaryReader(uf.data), field, uf.wireType, ctx);
    }
    return get();
  }
  function filterUnknownFields(unknownFields, extension) {
    if (unknownFields === void 0)
      return [];
    if (extension.fieldKind === "enum" || extension.fieldKind === "scalar") {
      for (let i = unknownFields.length - 1; i >= 0; --i) {
        if (unknownFields[i].no == extension.number) {
          return [unknownFields[i]];
        }
      }
      return [];
    }
    return unknownFields.filter((uf) => uf.no === extension.number);
  }
  function createExtensionContainer(extension, value) {
    const localName = extension.typeName;
    const field = Object.assign(Object.assign({}, extension), { kind: "field", parent: extension.extendee, localName });
    const desc = Object.assign(Object.assign({}, extension.extendee), { fields: [field], members: [field], oneofs: [] });
    const container = create(desc, value !== void 0 ? { [localName]: value } : void 0);
    return [
      reflect(desc, container),
      field,
      () => {
        const value2 = container[localName];
        if (value2 === void 0) {
          const desc2 = extension.message;
          if (isWrapperDesc(desc2)) {
            return scalarZeroValue(desc2.fields[0].scalar, desc2.fields[0].longAsString);
          }
          return create(desc2);
        }
        return value2;
      }
    ];
  }
  function assertExtendee(extension, message2) {
    if (extension.extendee.typeName != message2.$typeName) {
      throw new Error(`extension ${extension.typeName} can only be applied to message ${extension.extendee.typeName}`);
    }
  }

  // client/node_modules/@bufbuild/protobuf/dist/esm/wkt/json.js
  var timestampMsMin = /* @__PURE__ */ Date.parse("0001-01-01T00:00:00Z");
  var timestampMsMax = /* @__PURE__ */ Date.parse("9999-12-31T23:59:59Z");
  var durationSecondsMin = -315576e6;
  var durationSecondsMax = 315576e6;

  // client/node_modules/@bufbuild/protobuf/dist/esm/to-json.js
  var LEGACY_REQUIRED2 = 3;
  var IMPLICIT4 = 2;
  var jsonWriteDefaults = {
    alwaysEmitImplicit: false,
    enumAsInteger: false,
    useProtoFieldName: false
  };
  function makeWriteOptions(options) {
    return options ? Object.assign(Object.assign({}, jsonWriteDefaults), options) : jsonWriteDefaults;
  }
  function toJson(schema, message2, options) {
    return compiledWriter(schema)(makeWriteOptions(options), message2);
  }
  var compiledWriters = /* @__PURE__ */ new WeakMap();
  function compiledWriter(desc) {
    let compiled = compiledWriters.get(desc);
    if (compiled === void 0) {
      compiled = compileMessage2(desc);
    }
    return compiled;
  }
  function compileMessage2(desc) {
    const typeName = desc.typeName;
    const writeWkt = compileWkt(desc);
    if (writeWkt !== void 0) {
      const foreignField2 = desc.fields[0];
      const compiledWriter3 = (opts, message2) => {
        if (message2.$typeName !== typeName && foreignField2 !== void 0) {
          throw new FieldError(foreignField2, `cannot use ${foreignField2} with message ${message2.$typeName}`, "ForeignFieldError");
        }
        return writeWkt(opts, message2);
      };
      compiledWriters.set(desc, compiledWriter3);
      return compiledWriter3;
    }
    const sortedFields = desc.fields.concat().sort((a, b) => a.number - b.number);
    const foreignField = sortedFields[0];
    const fieldWriters = [];
    const compiledWriter2 = (opts, message2) => {
      if (message2.$typeName !== typeName && foreignField !== void 0) {
        throw new FieldError(foreignField, `cannot use ${foreignField} with message ${message2.$typeName}`, "ForeignFieldError");
      }
      const json = {};
      for (let i = 0; i < fieldWriters.length; i++) {
        fieldWriters[i](opts, message2, json);
      }
      if (opts.registry) {
        writeExtensions(json, opts, opts.registry, message2, desc);
      }
      return json;
    };
    compiledWriters.set(desc, compiledWriter2);
    for (const field of sortedFields) {
      fieldWriters.push(compileField(field));
    }
    return compiledWriter2;
  }
  function compileWkt(desc) {
    if (!desc.typeName.startsWith("google.protobuf.")) {
      return void 0;
    }
    switch (desc.typeName) {
      case "google.protobuf.Any":
        return (opts, message2) => anyToJson(message2, opts);
      case "google.protobuf.Timestamp":
        return (opts, message2) => timestampToJson(message2);
      case "google.protobuf.Duration":
        return (opts, message2) => durationToJson(message2);
      case "google.protobuf.FieldMask":
        return (opts, message2) => fieldMaskToJson(message2);
      case "google.protobuf.Struct":
        return (opts, message2) => structToJson(message2);
      case "google.protobuf.Value":
        return (opts, message2) => valueToJson(message2);
      case "google.protobuf.ListValue":
        return (opts, message2) => listValueToJson(message2);
      default:
        if (isWrapperDesc(desc)) {
          const valueField = desc.fields[0];
          const localName = valueField.localName;
          const zero = scalarZeroValue(valueField.scalar, false);
          const writeScalar = compileScalarValue(valueField);
          return (opts, message2) => {
            const value = message2[localName];
            return writeScalar(opts, value === void 0 ? zero : value);
          };
        }
        return void 0;
    }
  }
  function compileField(field) {
    switch (field.fieldKind) {
      case "scalar":
      case "enum":
      case "message":
        return compileSingularField(field);
      case "list":
      case "map": {
        const writeValue = field.fieldKind == "list" ? compileListValue(field) : compileMapValue(field);
        const protoName = field.name;
        const jsonKey = field.jsonName;
        const localName = field.localName;
        return (opts, message2, json) => {
          const value = writeValue(opts, message2[localName]);
          if (value !== void 0) {
            json[opts.useProtoFieldName ? protoName : jsonKey] = value;
          }
        };
      }
    }
  }
  function compileSingularField(field) {
    const writeValue = compileSingularValue(field);
    const protoName = field.name;
    const jsonKey = field.jsonName;
    const localName = field.localName;
    if (field.oneof) {
      const oneofLocalName = field.oneof.localName;
      return (opts, message2, json) => {
        const oneof = message2[oneofLocalName];
        if (oneof.case === localName) {
          json[opts.useProtoFieldName ? protoName : jsonKey] = writeValue(opts, oneof.value);
        }
      };
    }
    if (field.presence != IMPLICIT4) {
      const requiredError = field.presence == LEGACY_REQUIRED2 ? `cannot encode ${field} to JSON: required field not set` : void 0;
      return (opts, message2, json) => {
        const value = message2[localName];
        if (value !== void 0 && Object.prototype.hasOwnProperty.call(message2, localName)) {
          json[opts.useProtoFieldName ? protoName : jsonKey] = writeValue(opts, value);
        } else if (requiredError !== void 0) {
          throw new Error(requiredError);
        }
      };
    }
    if (field.fieldKind == "enum") {
      const zero = field.enum.values[0].number;
      return (opts, message2, json) => {
        const value = message2[localName];
        if (value !== zero || opts.alwaysEmitImplicit) {
          json[opts.useProtoFieldName ? protoName : jsonKey] = writeValue(opts, value);
        }
      };
    }
    switch (field.scalar) {
      case ScalarType.BOOL:
        return (opts, message2, json) => {
          const value = message2[localName];
          if (value !== false || opts.alwaysEmitImplicit) {
            json[opts.useProtoFieldName ? protoName : jsonKey] = writeValue(opts, value);
          }
        };
      case ScalarType.STRING:
        return (opts, message2, json) => {
          const value = message2[localName];
          if (value !== "" || opts.alwaysEmitImplicit) {
            json[opts.useProtoFieldName ? protoName : jsonKey] = writeValue(opts, value);
          }
        };
      case ScalarType.BYTES:
        return (opts, message2, json) => {
          const value = message2[localName];
          if (!(value instanceof Uint8Array) || value.byteLength > 0 || opts.alwaysEmitImplicit) {
            json[opts.useProtoFieldName ? protoName : jsonKey] = writeValue(opts, value);
          }
        };
      case ScalarType.DOUBLE:
      case ScalarType.FLOAT:
        return (opts, message2, json) => {
          const value = message2[localName];
          if (!Object.is(value, 0) || opts.alwaysEmitImplicit) {
            json[opts.useProtoFieldName ? protoName : jsonKey] = writeValue(opts, value);
          }
        };
      default:
        return (opts, message2, json) => {
          const value = message2[localName];
          if (value != 0 || opts.alwaysEmitImplicit) {
            json[opts.useProtoFieldName ? protoName : jsonKey] = writeValue(opts, value);
          }
        };
    }
  }
  function compileFieldValue(field) {
    switch (field.fieldKind) {
      case "scalar":
      case "enum":
      case "message":
        return compileSingularValue(field);
      case "list":
        return compileListValue(field);
      case "map":
        return compileMapValue(field);
    }
  }
  function compileSingularValue(field) {
    switch (field.fieldKind) {
      case "scalar":
        return compileScalarValue(field);
      case "enum":
        return compileEnumValue(field);
      case "message":
        return compileMessageValue(field);
    }
  }
  function compileMessageValue(field) {
    const { toMessage } = localMessageMapper(field);
    const writeMessage = compiledWriter(field.message);
    return (opts, value) => writeMessage(opts, toMessage(value));
  }
  function compileListValue(field) {
    const writeItem = compileListItemValue(field);
    return (opts, value) => {
      const items = value;
      if (items.length == 0 && !opts.alwaysEmitImplicit) {
        return void 0;
      }
      const jsonArray = [];
      for (let i = 0; i < items.length; i++) {
        jsonArray.push(writeItem(opts, items[i]));
      }
      return jsonArray;
    };
  }
  function compileListItemValue(field) {
    switch (field.listKind) {
      case "scalar":
        return compileScalarValue(field);
      case "enum":
        return compileEnumValue(field);
      case "message":
        return compileMessageValue(field);
    }
  }
  function compileMapValue(field) {
    const writeMapValue = compileMapEntryValue(field);
    return (opts, value) => {
      const record = value;
      const keys = Object.keys(record);
      if (keys.length == 0 && !opts.alwaysEmitImplicit) {
        return void 0;
      }
      const jsonObject = {};
      for (let i = 0; i < keys.length; i++) {
        const key = keys[i];
        jsonObject[key] = writeMapValue(opts, record[key]);
      }
      return jsonObject;
    };
  }
  function compileMapEntryValue(field) {
    switch (field.mapKind) {
      case "scalar":
        return compileScalarValue(field);
      case "enum":
        return compileEnumValue(field);
      case "message":
        return compileMessageValue(field);
    }
  }
  function compileEnumValue(field) {
    const desc = field.enum;
    if (desc.typeName == "google.protobuf.NullValue") {
      return (opts, value) => {
        if (typeof value != "number") {
          throw errorEnumValue(desc, value);
        }
        return null;
      };
    }
    return (opts, value) => {
      var _a, _b;
      if (typeof value != "number") {
        throw errorEnumValue(desc, value);
      }
      if (opts.enumAsInteger) {
        return value;
      }
      return (_b = (_a = desc.value[value]) === null || _a === void 0 ? void 0 : _a.name) !== null && _b !== void 0 ? _b : value;
    };
  }
  function errorEnumValue(desc, value) {
    return new Error(`cannot encode ${desc} to JSON: expected number, got ${formatVal(value)}`);
  }
  function compileScalarValue(field) {
    switch (field.scalar) {
      // int32, fixed32, uint32: JSON value will be a decimal number. Either numbers or strings are accepted.
      case ScalarType.INT32:
      case ScalarType.SFIXED32:
      case ScalarType.SINT32:
      case ScalarType.FIXED32:
      case ScalarType.UINT32:
        return (opts, value) => {
          if (typeof value != "number") {
            throw errorScalarValue(field, value);
          }
          return value;
        };
      // float, double: JSON value will be a number or one of the special string values "NaN", "Infinity", and "-Infinity".
      // Either numbers or strings are accepted. Exponent notation is also accepted.
      case ScalarType.FLOAT:
      case ScalarType.DOUBLE:
        return (opts, value) => {
          if (typeof value != "number") {
            throw errorScalarValue(field, value);
          }
          if (Number.isNaN(value))
            return "NaN";
          if (value === Number.POSITIVE_INFINITY)
            return "Infinity";
          if (value === Number.NEGATIVE_INFINITY)
            return "-Infinity";
          return value;
        };
      // string:
      case ScalarType.STRING:
        return (opts, value) => {
          if (typeof value != "string") {
            throw errorScalarValue(field, value);
          }
          return value;
        };
      // bool:
      case ScalarType.BOOL:
        return (opts, value) => {
          if (typeof value != "boolean") {
            throw errorScalarValue(field, value);
          }
          return value;
        };
      // JSON value will be a decimal string. Either numbers or strings are accepted.
      case ScalarType.UINT64:
      case ScalarType.FIXED64:
      case ScalarType.INT64:
      case ScalarType.SFIXED64:
      case ScalarType.SINT64:
        return (opts, value) => {
          if (typeof value == "bigint" || typeof value == "string" || typeof value == "number" && Number.isInteger(value)) {
            return value.toString();
          }
          throw errorScalarValue(field, value);
        };
      // bytes: JSON value will be the data encoded as a string using standard base64 encoding with paddings.
      // Either standard or URL-safe base64 encoding with/without paddings are accepted.
      case ScalarType.BYTES:
        return (opts, value) => {
          if (value instanceof Uint8Array) {
            return base64Encode(value);
          }
          throw errorScalarValue(field, value);
        };
    }
  }
  function errorScalarValue(field, value) {
    var _a;
    return new Error(`cannot encode ${field} to JSON: ${(_a = checkField(field, value)) === null || _a === void 0 ? void 0 : _a.message}`);
  }
  function writeExtensions(json, opts, registry, message2, desc) {
    const unknown = message2.$unknown;
    if (unknown === void 0) {
      return;
    }
    const tagSeen = /* @__PURE__ */ new Set();
    for (let i = 0; i < unknown.length; i++) {
      const { no } = unknown[i];
      if (!tagSeen.has(no)) {
        tagSeen.add(no);
        const extension = registry.getExtensionFor(desc, no);
        if (!extension) {
          continue;
        }
        const value = getExtension(message2, extension);
        const [container, field] = createExtensionContainer(extension, value);
        const local = container[unsafeLocal];
        const jsonValue = compileFieldValue(field)(opts, local[field.localName]);
        if (jsonValue !== void 0) {
          json[extension.jsonName] = jsonValue;
        }
      }
    }
  }
  function anyToJson(val, opts) {
    if (val.typeUrl === "") {
      return {};
    }
    const { registry } = opts;
    let message2;
    let desc;
    if (registry) {
      message2 = anyUnpack(val, registry);
      if (message2) {
        desc = registry.getMessage(message2.$typeName);
      }
    }
    if (!desc || !message2) {
      throw new Error(`cannot encode message ${val.$typeName} to JSON: "${val.typeUrl}" is not in the type registry`);
    }
    const json = hasCustomJsonRepresentation(desc) ? {
      value: compiledWriter(desc)(opts, message2)
    } : compiledWriter(desc)(opts, message2);
    json["@type"] = val.typeUrl;
    return json;
  }
  function durationToJson(val) {
    const seconds = Number(val.seconds);
    const nanos = val.nanos;
    if (seconds > durationSecondsMax || seconds < durationSecondsMin) {
      throw new Error(`cannot encode message ${val.$typeName} to JSON: value out of range`);
    }
    if (seconds > 0 && nanos < 0 || seconds < 0 && nanos > 0) {
      throw new Error(`cannot encode message ${val.$typeName} to JSON: nanos sign must match seconds sign`);
    }
    let text = val.seconds.toString();
    if (nanos !== 0) {
      let nanosStr = Math.abs(nanos).toString();
      nanosStr = "0".repeat(9 - nanosStr.length) + nanosStr;
      if (nanosStr.substring(3) === "000000") {
        nanosStr = nanosStr.substring(0, 3);
      } else if (nanosStr.substring(6) === "000") {
        nanosStr = nanosStr.substring(0, 6);
      }
      text += "." + nanosStr;
      if (nanos < 0 && seconds == 0) {
        text = "-" + text;
      }
    }
    return text + "s";
  }
  function fieldMaskToJson(val) {
    return val.paths.map((p) => {
      if (protoSnakeCase(protoCamelCase(p)) !== p) {
        throw new Error(`cannot encode message ${val.$typeName} to JSON: lowerCamelCase of path name "${p}" is irreversible`);
      }
      return protoCamelCase(p);
    }).join(",");
  }
  function structToJson(val) {
    const json = {};
    const keys = Object.keys(val.fields);
    for (let i = 0; i < keys.length; i++) {
      const key = keys[i];
      json[key] = valueToJson(val.fields[key]);
    }
    return json;
  }
  function valueToJson(val) {
    switch (val.kind.case) {
      case "nullValue":
        return null;
      case "numberValue":
        if (!Number.isFinite(val.kind.value)) {
          throw new Error(`${val.$typeName} cannot be NaN or Infinity`);
        }
        return val.kind.value;
      case "boolValue":
        return val.kind.value;
      case "stringValue":
        return val.kind.value;
      case "structValue":
        return structToJson(val.kind.value);
      case "listValue":
        return listValueToJson(val.kind.value);
      default:
        throw new Error(`${val.$typeName} must have a value`);
    }
  }
  function listValueToJson(val) {
    return val.values.map(valueToJson);
  }
  function timestampToJson(val) {
    const ms = Number(val.seconds) * 1e3;
    if (ms < timestampMsMin || ms > timestampMsMax) {
      throw new Error(`cannot encode message ${val.$typeName} to JSON: must be from 0001-01-01T00:00:00Z to 9999-12-31T23:59:59Z inclusive`);
    }
    if (val.nanos < 0) {
      throw new Error(`cannot encode message ${val.$typeName} to JSON: nanos must not be negative`);
    }
    if (val.nanos > 999999999) {
      throw new Error(`cannot encode message ${val.$typeName} to JSON: nanos must not be greater than 99999999`);
    }
    let z = "Z";
    if (val.nanos > 0) {
      const nanosStr = (val.nanos + 1e9).toString().substring(1);
      if (nanosStr.substring(3) === "000000") {
        z = "." + nanosStr.substring(0, 3) + "Z";
      } else if (nanosStr.substring(6) === "000") {
        z = "." + nanosStr.substring(0, 6) + "Z";
      } else {
        z = "." + nanosStr + "Z";
      }
    }
    return new Date(ms).toISOString().replace(".000Z", z);
  }

  // work/art-generation-consumer-v1/app-v3-build-03/source/client/src/protocol/frontline_pb.ts
  var file_frontline = /* @__PURE__ */ fileDesc("Cg9mcm9udGxpbmUucHJvdG8SDGZyb250bGluZS52MSKFBAoIRW52ZWxvcGUSKgoFaGVsbG8YASABKAsyGS5mcm9udGxpbmUudjEuQ2xpZW50SGVsbG9IABIqCgZvcmRlcnMYAiABKAsyGC5mcm9udGxpbmUudjEuT3JkZXJCYXRjaEgAEjEKDG9yZGVyX3Jlc3VsdBgDIAEoCzIZLmZyb250bGluZS52MS5PcmRlclJlc3VsdEgAEjAKCHNuYXBzaG90GAQgASgLMhwuZnJvbnRsaW5lLnYxLlBsYXllclNuYXBzaG90SAASKQoFZGVsdGEYBSABKAsyGC5mcm9udGxpbmUudjEuU3RhdGVEZWx0YUgAEisKBnJlc3VtZRgGIAEoCzIZLmZyb250bGluZS52MS5SZXN1bWVNYXRjaEgAEisKBnJlc3VsdBgHIAEoCzIZLmZyb250bGluZS52MS5NYXRjaFJlc3VsdEgAEiwKBWVycm9yGAggASgLMhsuZnJvbnRsaW5lLnYxLlByb3RvY29sRXJyb3JIABIiCgRwaW5nGAkgASgLMhIuZnJvbnRsaW5lLnYxLlBpbmdIABItCgdjb250cm9sGAogASgLMhouZnJvbnRsaW5lLnYxLk1hdGNoQ29udHJvbEgAEisKBnN0YXR1cxgLIAEoCzIZLmZyb250bGluZS52MS5NYXRjaFN0YXR1c0gAQgkKB21lc3NhZ2UiagoLQ2xpZW50SGVsbG8SEAoIcHJvdG9jb2wYASABKA0SEgoKc2ltdWxhdGlvbhgCIAEoCRIUCgxjb250ZW50X2hhc2gYAyABKAkSDQoFdG9rZW4YBCABKAkSEAoIbWF0Y2hfaWQYBSABKAkiSgoLUmVzdW1lTWF0Y2gSKAoFaGVsbG8YASABKAsyGS5mcm9udGxpbmUudjEuQ2xpZW50SGVsbG8SEQoJbGFzdF90aWNrGAIgASgNIh4KDE1hdGNoQ29udHJvbBIOCgZhY3Rpb24YASABKAkiVAoPQ29ubmVjdGlvblN0YXRlEg4KBnBsYXllchgBIAEoDRIRCgljb25uZWN0ZWQYAiABKAgSHgoWcmVjb25uZWN0X3JlbWFpbmluZ19tcxgDIAEoDSKYAQoLTWF0Y2hTdGF0dXMSFQoNcGF1c2VfZW5hYmxlZBgBIAEoCBIOCgZwYXVzZWQYAiABKAgSEwoLcGF1c2Vfdm90ZXMYAyADKA0SMAoJdGVhbW1hdGVzGAQgAygLMh0uZnJvbnRsaW5lLnYxLkNvbm5lY3Rpb25TdGF0ZRIbChN3YWl0aW5nX2Zvcl9wbGF5ZXJzGAUgASgIIhUKBFBpbmcSDQoFbm9uY2UYASABKA0iQwoNUHJvdG9jb2xFcnJvchIMCgRjb2RlGAEgASgJEg8KB21lc3NhZ2UYAiABKAkSEwoLcmVjb3ZlcmFibGUYAyABKAgiGwoDVmVjEgkKAXgYASABKBESCQoBeRgCIAEoESKsAQoFT3JkZXISDAoEa2luZBgBIAEoCRIQCghlbnRpdGllcxgCIAMoDRIOCgZ0YXJnZXQYAyABKA0SIwoIcG9zaXRpb24YBCABKAsyES5mcm9udGxpbmUudjEuVmVjEgwKBHR5cGUYBSABKAkSDgoGcXVldWVkGAYgASgIEg0KBWluZGV4GAcgASgFEiEKBnBvaW50cxgIIAMoCzIRLmZyb250bGluZS52MS5WZWMiQwoKT3JkZXJCYXRjaBIQCghzZXF1ZW5jZRgBIAEoDRIjCgZvcmRlcnMYAiADKAsyEy5mcm9udGxpbmUudjEuT3JkZXIibAoLT3JkZXJSZXN1bHQSDgoGcGxheWVyGAEgASgNEhAKCHNlcXVlbmNlGAIgASgNEg0KBWluZGV4GAMgASgFEhAKCGFjY2VwdGVkGAQgASgIEgwKBGNvZGUYBSABKAkSDAoEdGljaxgGIAEoDSJ6CghNZXRhZGF0YRISCgpzaW11bGF0aW9uGAEgASgJEhAKCHByb3RvY29sGAIgASgNEhQKDGNvbnRlbnRfaGFzaBgDIAEoCRITCgttYXBfdmVyc2lvbhgEIAEoCRIPCgdydWxlc2V0GAUgASgJEgwKBHNlZWQYBiABKAQiJQoIQ29vbGRvd24SCgoCaWQYASABKAkSDQoFdW50aWwYAiABKA0imAEKA0pvYhIMCgR0eXBlGAEgASgJEhAKCHJlc2VhcmNoGAIgASgIEgwKBHBhaWQYAyABKAMSDAoEd29yaxgEIAEoDRIQCghyZXF1aXJlZBgFIAEoDRIOCgZzdXBwbHkYBiABKAUSDwoHc2VydmljZRgHIAEoDRIPCgdzdGFydGVkGAggASgIEhEKCWVtZXJnZW5jeRgJIAEoCCKLAgoHRWNvbm9teRIPCgdjcmVkaXRzGAEgASgDEg4KBmVuZXJneRgCIAEoAxIOCgZzdXBwbHkYAyABKAUSFwoPcmVzZXJ2ZWRfc3VwcGx5GAQgASgFEhYKDnBvd2VyX2NhcGFjaXR5GAUgASgFEhQKDHBvd2VyX2RlbWFuZBgGIAEoBRIMCgR0aWVyGAcgASgFEg4KBmluY29tZRgIIAEoAxIWCg5yZXBhaXJfcmVzZXJ2ZRgJIAEoAxIQCgh1cGdyYWRlcxgKIAMoCRIpCgljb29sZG93bnMYCyADKAsyFi5mcm9udGxpbmUudjEuQ29vbGRvd24SFQoNbGFzdF9zZXF1ZW5jZRgMIAEoDSKmBAoNRW50aXR5UHJpdmF0ZRIKCgJocBgBIAEoAxIOCgZtYXhfaHAYAiABKAMSHwoEam9icxgDIAMoCzIRLmZyb250bGluZS52MS5Kb2ISIwoGb3JkZXJzGAQgAygLMhMuZnJvbnRsaW5lLnYxLk9yZGVyEiAKBXJhbGx5GAUgASgLMhEuZnJvbnRsaW5lLnYxLlZlYxINCgVjYXJnbxgGIAEoAxIMCgRob21lGAcgASgNEgwKBGFtbW8YCCABKAUSEQoJZW5kdXJhbmNlGAkgASgNEg8KB2NoYXJnZXMYCiABKAUSEwoLY2hhcmdlX3dvcmsYCyABKA0SFAoMc2VydmljZV93b3JrGAwgASgNEhIKCmV4cGVyaWVuY2UYDSABKAMSKQoJY29vbGRvd25zGA4gAygLMhYuZnJvbnRsaW5lLnYxLkNvb2xkb3duEhIKCnBhc3NlbmdlcnMYDyADKA0SEQoJY29udGFpbmVyGBAgASgNEhUKDXJlcGVhdF9zb3J0aWUYESABKAgSFAoMYW1idXNoX3JlYWR5GBIgASgIEhYKDm1pc3Npb25fb3JpZ2luGBMgASgJEiQKF2VtZXJnZW5jeV90YWtlb2ZmX3VudGlsGBQgASgNSACIAQESKgoGcmFuZ2VzGBUgASgLMhouZnJvbnRsaW5lLnYxLkVudGl0eVJhbmdlc0IaChhfZW1lcmdlbmN5X3Rha2VvZmZfdW50aWwiKwoMU3RhdHVzRWZmZWN0EgwKBGtpbmQYASABKAkSDQoFdW50aWwYAiABKA0i5QMKBkVudGl0eRIKCgJpZBgBIAEoDRIMCgR0eXBlGAIgASgJEg0KBW93bmVyGAMgASgNEiMKCHBvc2l0aW9uGAQgASgLMhEuZnJvbnRsaW5lLnYxLlZlYxIOCgZmYWNpbmcYBSABKAUSDgoGaGVhbHRoGAYgASgFEg0KBXN0YXRlGAcgASgJEhAKCGNvbXBsZXRlGAggASgIEg8KB2VuYWJsZWQYCSABKAgSDgoGbGFuZGVkGAogASgIEhAKCGRlcGxveWVkGAsgASgIEhEKCWNvbmNlYWxlZBgMIAEoCBIQCghwcm9ncmVzcxgNIAEoBRIMCgRyYW5rGA4gASgNEiwKB3ByaXZhdGUYDyABKAsyGy5mcm9udGxpbmUudjEuRW50aXR5UHJpdmF0ZRIVCg10dXJyZXRfZmFjaW5nGBAgASgFEhUKDWNoYW5uZWxfdW50aWwYESABKA0SEgoKbWFwX29iamVjdBgSIAEoDRIXCg9mb290cHJpbnRfd2lkdGgYEyABKAUSGAoQZm9vdHByaW50X2hlaWdodBgUIAEoBRIWCg5mb290cHJpbnRfdHlwZRgVIAEoCRIrCgdlZmZlY3RzGBYgAygLMhouZnJvbnRsaW5lLnYxLlN0YXR1c0VmZmVjdCKwAQoNUGxheWVyU3VtbWFyeRIKCgJpZBgBIAEoDRIMCgRuYW1lGAIgASgJEg8KB2ZhY3Rpb24YAyABKAkSDAoEdGVhbRgEIAEoDRIQCghkZWZlYXRlZBgFIAEoCBIRCglkZWZlYXRfYXQYBiABKA0SGgoSc3RyYXRlZ2ljX3Byb2dyZXNzGAcgASgFEhYKDnN1cnJlbmRlcl92b3RlGAggASgIEg0KBWNvbG9yGAkgASgNIo4CCgpQcm9qZWN0aWxlEgoKAmlkGAEgASgNEg0KBW93bmVyGAIgASgNEg4KBndlYXBvbhgDIAEoCRIjCghwb3NpdGlvbhgEIAEoCzIRLmZyb250bGluZS52MS5WZWMSIQoGaW1wYWN0GAUgASgLMhEuZnJvbnRsaW5lLnYxLlZlYxIRCglpbXBhY3RfYXQYBiABKA0SFQoNaW50ZXJjZXB0YWJsZRgHIAEoCBIPCgd3YXJuaW5nGAggASgIEhMKBnNwbGFzaBgJIAEoBUgAiAEBEh0KEHBvc2l0aW9uX3Zpc2libGUYCiABKAhIAYgBAUIJCgdfc3BsYXNoQhMKEV9wb3NpdGlvbl92aXNpYmxlIksKBUZpZWxkEgoKAmlkGAEgASgNEiMKCHBvc2l0aW9uGAIgASgLMhEuZnJvbnRsaW5lLnYxLlZlYxIRCglyZW1haW5pbmcYAyABKAMiSQoHU3RhdGlvbhIKCgJpZBgBIAEoDRIjCghwb3NpdGlvbhgCIAEoCzIRLmZyb250bGluZS52MS5WZWMSDQoFb3duZXIYAyABKA0irwEKBk1lbW9yeRIKCgJpZBgBIAEoDRIMCgR0eXBlGAIgASgJEg0KBW93bmVyGAMgASgNEiMKCHBvc2l0aW9uGAQgASgLMhEuZnJvbnRsaW5lLnYxLlZlYxIMCgRzZWVuGAUgASgNEhcKD2Zvb3RwcmludF93aWR0aBgGIAEoBRIYChBmb290cHJpbnRfaGVpZ2h0GAcgASgFEhYKDmZvb3RwcmludF90eXBlGAggASgJIs0BCgVFdmVudBIKCgJpZBgBIAEoDRIMCgR0aWNrGAIgASgNEgwKBGtpbmQYAyABKAkSDQoFb3duZXIYBCABKA0SDgoGZW50aXR5GAUgASgNEiMKCHBvc2l0aW9uGAYgASgLMhEuZnJvbnRsaW5lLnYxLlZlYxINCgV2YWx1ZRgHIAEoAxINCgVzY29wZRgIIAEoCRIMCgR0ZXh0GAkgASgJEiwKBmNvbWJhdBgKIAEoCzIcLmZyb250bGluZS52MS5Db21iYXRGZWVkYmFjayJdCgdPdXRjb21lEhAKCGZpbmlzaGVkGAEgASgIEgwKBGRyYXcYAiABKAgSFAoMd2lubmluZ190ZWFtGAMgASgNEg4KBnJlYXNvbhgEIAEoCRIMCgR0aWNrGAUgASgNIuAGCg5QbGF5ZXJTbmFwc2hvdBIoCghtZXRhZGF0YRgBIAEoCzIWLmZyb250bGluZS52MS5NZXRhZGF0YRIMCgR0aWNrGAIgASgNEhEKCWNvdW50ZG93bhgDIAEoDRIOCgZwbGF5ZXIYBCABKA0SJgoHZWNvbm9teRgFIAEoCzIVLmZyb250bGluZS52MS5FY29ub215EiwKB3BsYXllcnMYBiADKAsyGy5mcm9udGxpbmUudjEuUGxheWVyU3VtbWFyeRImCghlbnRpdGllcxgHIAMoCzIULmZyb250bGluZS52MS5FbnRpdHkSLQoLcHJvamVjdGlsZXMYCCADKAsyGC5mcm9udGxpbmUudjEuUHJvamVjdGlsZRIjCgZmaWVsZHMYCSADKAsyEy5mcm9udGxpbmUudjEuRmllbGQSJwoIc3RhdGlvbnMYCiADKAsyFS5mcm9udGxpbmUudjEuU3RhdGlvbhIUCghleHBsb3JlZBgLIAMoCEICEAESEwoHdmlzaWJsZRgMIAMoCEICEAESJAoGbWVtb3J5GA0gAygLMhQuZnJvbnRsaW5lLnYxLk1lbW9yeRIjCgZldmVudHMYDiADKAsyEy5mcm9udGxpbmUudjEuRXZlbnQSKgoHcmVzdWx0cxgPIAMoCzIZLmZyb250bGluZS52MS5PcmRlclJlc3VsdBITCgtzaGlwbWVudF9hdBgQIAEoDRImCgdvdXRjb21lGBEgASgLMhUuZnJvbnRsaW5lLnYxLk91dGNvbWUSJgoHc2FsdmFnZRgSIAMoCzIVLmZyb250bGluZS52MS5TYWx2YWdlEiEKBXpvbmVzGBMgAygLMhIuZnJvbnRsaW5lLnYxLlpvbmUSNAoKaW5kaWNhdG9ycxgUIAMoCzIgLmZyb250bGluZS52MS5TdHJ1Y3R1cmVJbmRpY2F0b3ISLgoHbWlzc2lvbhgVIAEoCzIdLmZyb250bGluZS52MS5NaXNzaW9uUHJvZ3Jlc3MSDgoGcnViYmxlGBYgAygNEjAKCHdhcm5pbmdzGBcgAygLMh4uZnJvbnRsaW5lLnYxLk9wZXJhdGlvbldhcm5pbmcSJgoHZGVicmllZhgYIAEoCzIVLmZyb250bGluZS52MS5EZWJyaWVmImoKClN0YXRlRGVsdGESFQoNYmFzZWxpbmVfdGljaxgBIAEoDRIrCgVzdGF0ZRgCIAEoCzIcLmZyb250bGluZS52MS5QbGF5ZXJTbmFwc2hvdBIYChByZW1vdmVkX2VudGl0aWVzGAMgAygNImgKC01hdGNoUmVzdWx0EhAKCG1hdGNoX2lkGAEgASgJEiYKB291dGNvbWUYAiABKAsyFS5mcm9udGxpbmUudjEuT3V0Y29tZRIRCgljb21taXR0ZWQYAyABKAgSDAoEdm9pZBgEIAEoCCJnCgdTYWx2YWdlEgoKAmlkGAEgASgNEg0KBW93bmVyGAIgASgNEiMKCHBvc2l0aW9uGAMgASgLMhEuZnJvbnRsaW5lLnYxLlZlYxINCgV2YWx1ZRgEIAEoAxINCgV1bnRpbBgFIAEoDSJ2CgRab25lEgwKBGtpbmQYASABKAkSDQoFb3duZXIYAiABKA0SIwoIcG9zaXRpb24YAyABKAsyES5mcm9udGxpbmUudjEuVmVjEg4KBnJhZGl1cxgEIAEoBRINCgVzdGFydBgFIAEoDRINCgV1bnRpbBgGIAEoDSJIChJTdHJ1Y3R1cmVJbmRpY2F0b3ISDQoFb3duZXIYASABKA0SIwoIcG9zaXRpb24YAiABKAsyES5mcm9udGxpbmUudjEuVmVjIoYBChFPYmplY3RpdmVQcm9ncmVzcxIKCgJpZBgBIAEoCRIMCgR0ZXh0GAIgASgJEhAKCG9wdGlvbmFsGAMgASgIEg8KB2ZhaWx1cmUYBCABKAgSEAoIY29tcGxldGUYBSABKAgSEAoIcHJvZ3Jlc3MYBiABKA0SEAoIcmVxdWlyZWQYByABKA0i4gEKD01pc3Npb25Qcm9ncmVzcxIKCgJpZBgBIAEoCRINCgV0aXRsZRgCIAEoCRISCgpkaWZmaWN1bHR5GAMgASgJEhIKCmNoZWNrcG9pbnQYBCABKAkSFwoPY2hlY2twb2ludF90aWNrGAUgASgNEjMKCm9iamVjdGl2ZXMYBiADKAsyHy5mcm9udGxpbmUudjEuT2JqZWN0aXZlUHJvZ3Jlc3MSLQoHY29udm95cxgHIAMoCzIcLmZyb250bGluZS52MS5Db252b3lQcm9ncmVzcxIPCgd2ZXJzaW9uGAggASgJIrIBChBPcGVyYXRpb25XYXJuaW5nEgwKBGtpbmQYASABKAkSDQoFb3duZXIYAiABKA0SIwoIcG9zaXRpb24YAyABKAsyES5mcm9udGxpbmUudjEuVmVjEgoKAmF0GAQgASgNEg4KBnNvdXJjZRgFIAEoDRIgCgVleGl0cxgGIAMoCzIRLmZyb250bGluZS52MS5WZWMSEwoGc3BsYXNoGAcgASgFSACIAQFCCQoHX3NwbGFzaCKpAQoOQ29udm95UHJvZ3Jlc3MSCgoCaWQYASABKAkSDgoGYWN0aXZlGAIgASgIEhEKCWNvbXBsZXRlZBgDIAEoCBIMCgRoZWxkGAQgASgIEg4KBm1vdmluZxgFIAEoCBINCgVyb3V0ZRgGIAEoDRIQCgh3YXlwb2ludBgHIAEoDRIXCg9jb3VudGRvd25fdW50aWwYCCABKA0SEAoIYXBwcm92ZWQYCSADKA0ibwoNRWNvbm9teVNhbXBsZRIMCgR0aWNrGAEgASgNEg8KB2NyZWRpdHMYAiABKAMSDgoGaW5jb21lGAMgASgDEg0KBXNwZW50GAQgASgDEg4KBnN1cHBseRgFIAEoBRIQCghzdGF0aW9ucxgGIAEoDSIuCg9Qcm9kdWN0aW9uQ291bnQSDAoEdHlwZRgBIAEoCRINCgVjb3VudBgCIAEoDSLZAgoPUGxheWVyVGVsZW1ldHJ5Eg4KBnBsYXllchgBIAEoDRI1Cg51bml0c19wcm9kdWNlZBgCIAMoCzIdLmZyb250bGluZS52MS5Qcm9kdWN0aW9uQ291bnQSPAoVYnVpbGRpbmdzX2NvbnN0cnVjdGVkGAMgAygLMh0uZnJvbnRsaW5lLnYxLlByb2R1Y3Rpb25Db3VudBISCgp1bml0c19sb3N0GAQgASgNEhYKDmJ1aWxkaW5nc19sb3N0GAUgASgNEhQKDHJlcGFpcl9zcGVudBgGIAEoAxIVCg1taXNzaWxlX3NwZW50GAcgASgDEhoKEmludGVyY2VwdG9yc19maXJlZBgIIAEoDRIdChVzdGF0aW9uX2NvbnRyb2xfdGlja3MYCSABKA0SLQoIdGltZWxpbmUYCiADKAsyGy5mcm9udGxpbmUudjEuRWNvbm9teVNhbXBsZSKwAgoNRGVicmllZlBsYXllchIOCgZwbGF5ZXIYASABKA0SDAoEbmFtZRgCIAEoCRIPCgdmYWN0aW9uGAMgASgJEgwKBHRlYW0YBCABKA0SDQoFY29sb3IYBSABKA0SEAoIZGVmZWF0ZWQYBiABKAgSDwoHY3JlZGl0cxgHIAEoAxIOCgZpbmNvbWUYCCABKAMSDQoFc3BlbnQYCSABKAMSEgoKbG9zdF92YWx1ZRgKIAEoAxIXCg91bml0c19zdXJ2aXZpbmcYCyABKA0SHAoUc3RydWN0dXJlc19zdXJ2aXZpbmcYDCABKA0SFgoOZXhwbG9yZWRfdGlsZXMYDSABKA0SLgoHbWV0cmljcxgOIAEoCzIdLmZyb250bGluZS52MS5QbGF5ZXJUZWxlbWV0cnkiVgoMRGVicmllZkV2ZW50EgwKBHRpY2sYASABKA0SDAoEa2luZBgCIAEoCRIOCgZwbGF5ZXIYAyABKA0SDAoEdHlwZRgEIAEoCRIMCgR0ZXh0GAUgASgJInsKB0RlYnJpZWYSLAoHcGxheWVycxgBIAMoCzIbLmZyb250bGluZS52MS5EZWJyaWVmUGxheWVyEioKBmV2ZW50cxgCIAMoCzIaLmZyb250bGluZS52MS5EZWJyaWVmRXZlbnQSFgoOb21pdHRlZF9ldmVudHMYAyABKA0iYAoOQ29tYmF0RmVlZGJhY2sSDgoGd2VhcG9uGAEgASgJEg8KB291dGNvbWUYAiABKAkSFAoMdGFyZ2V0X2FybW9yGAMgASgJEhcKD2NvdmVyX21pdGlnYXRlZBgEIAEoCCKiAQoMRW50aXR5UmFuZ2VzEhQKDHNpZ2h0X3JhZGl1cxgBIAEoBRIYChBkZXRlY3Rpb25fcmFkaXVzGAIgASgFEhYKDmFpcmJvcm5lX3NpZ2h0GAMgASgIEhQKDGJ1aWxkX3JhZGl1cxgEIAEoBRI0CgxpbnRlcmNlcHRpb24YBSABKAsyHi5mcm9udGxpbmUudjEuSW50ZXJjZXB0aW9uVmlldyKNAgoQSW50ZXJjZXB0aW9uVmlldxIOCgZyYWRpdXMYASABKAUSEAoIY2FwYWNpdHkYAiABKAUSDgoGYWN0aXZlGAMgASgIEg0KBXJlYWR5GAQgASgIEhkKEXJlY2hhcmdlX3JlcXVpcmVkGAUgASgNEhUKDXJlY2hhcmdlX3JhdGUYBiABKA0SHgoRbmV4dF9jaGFyZ2VfdGlja3MYByABKA1IAIgBARIVCg1maXJlX3JlYWR5X2F0GAggASgNEjkKC2Fzc2lnbm1lbnRzGAkgAygLMiQuZnJvbnRsaW5lLnYxLkludGVyY2VwdGlvbkFzc2lnbm1lbnRCFAoSX25leHRfY2hhcmdlX3RpY2tzImUKFkludGVyY2VwdGlvbkFzc2lnbm1lbnQSEgoKcHJvamVjdGlsZRgBIAEoDRIhCgZpbXBhY3QYAiABKAsyES5mcm9udGxpbmUudjEuVmVjEhQKDGludGVyY2VwdF9hdBgDIAEoDUIkWiJmcm9udGxpbmVjb21tYW5kL3Byb3RvY29sO3Byb3RvY29sYgZwcm90bzM");
  var OrderBatchSchema = /* @__PURE__ */ messageDesc(file_frontline, 10);
  var PlayerSnapshotSchema = /* @__PURE__ */ messageDesc(file_frontline, 26);

  // client/tests/stock-browser/observe.mjs
  var data = { workers: [], methods: {}, requests: [], replies: [], errors: [], consoleErrors: [], httpErrors: [], exports: [], results: [], saves: [], latest: null, clock: null, overflow: false };
  var append = (key, value, limit = 512) => {
    if (data[key].length >= limit) {
      data.overflow = true;
      return;
    }
    data[key].push(value);
  };
  var stamp = () => performance.now();
  var view = (bytes) => {
    const raw = fromBinary(PlayerSnapshotSchema, bytes), j = toJson(PlayerSnapshotSchema, raw);
    return { metadata: j.metadata, tick: raw.tick, countdown: raw.countdown, player: raw.player, economy: j.economy, players: j.players ?? [], entities: j.entities ?? [], results: j.results ?? [], outcome: j.outcome };
  };
  var message = (e) => String(e?.stack ?? e?.message ?? e);
  addEventListener("error", (e) => append("errors", { kind: "window/resource", message: e.message ?? e.target?.src ?? e.target?.href ?? "unknown resource" }), true);
  addEventListener("unhandledrejection", (e) => append("errors", { kind: "rejection", message: message(e.reason) }));
  var oldError = console.error;
  console.error = function(...args) {
    append("consoleErrors", args.map(message));
    return oldError.apply(this, args);
  };
  var oldFetch = window.fetch;
  window.fetch = async function(...args) {
    try {
      const r = await oldFetch.apply(this, args);
      if (!r.ok) append("httpErrors", { url: r.url, status: r.status });
      return r;
    } catch (e) {
      append("httpErrors", { url: String(args[0]), error: message(e) });
      throw e;
    }
  };
  var Base = window.Worker;
  var next = 0;
  var seenResults = /* @__PURE__ */ new Set();
  window.Worker = class extends Base {
    constructor(...args) {
      super(...args);
      if (args[1]?.name !== "Frontline Go simulation") return;
      const worker = { id: ++next, url: String(args[0]), live: true, createdAt: stamp() }, pending = /* @__PURE__ */ new Map();
      data.workers.push(worker);
      this.addEventListener("error", (e) => append("errors", { kind: "worker", worker: worker.id, message: e.message }));
      this.addEventListener("message", (e) => {
        const m = e.data;
        try {
          if (m.event === "frame") {
            const snapshot = view(m.bytes);
            data.latest = { worker: worker.id, ...snapshot };
            for (const result of snapshot.results) {
              const key = JSON.stringify(result);
              if (!seenResults.has(key)) {
                seenResults.add(key);
                append("results", result);
              }
            }
            for (const request2 of pending.values()) if (["create", "load", "loadReplay", "seekReplay"].includes(request2.method) && !request2.firstFrame) request2.firstFrame = snapshot;
            return;
          }
          if (m.event === "clock") {
            data.clock = { worker: worker.id, ...m };
            return;
          }
          if (m.event === "error") {
            append("errors", { kind: "runtime", worker: worker.id, error: m.error });
            return;
          }
          const request = pending.get(m.id);
          if (!request) return;
          pending.delete(m.id);
          if (!m.ok) append("errors", { kind: "rpc", method: request.method, error: m.error });
          if (request.method === "save" && m.ok) {
            append("saves", { worker: worker.id, id: m.id, time: stamp(), tick: m.result.tick, hash: m.result.hash, metadata: m.result.metadata, engine: new TextDecoder().decode(m.result.data) }, 16);
          }
          if (request.method === "content" && m.ok) data.catalogRig = m.result.units?.find((u) => u.id === "US.rig");
          if (["create", "load", "loadReplay", "seekReplay", "pause", "resume", "submit", "save", "exportReplay", "inspect", "inspectReplay"].includes(request.method)) append("replies", { worker: worker.id, id: m.id, method: request.method, ok: m.ok, result: ["create", "load", "loadReplay", "seekReplay", "inspect", "inspectReplay"].includes(request.method) ? m.result : void 0, firstFrame: request.firstFrame, time: stamp() });
        } catch (error) {
          append("errors", { kind: "observer-decode", message: message(error) });
        }
      });
      const original = this.postMessage;
      this.postMessage = function(m, ...rest) {
        if (m?.method) {
          data.methods[m.method] = (data.methods[m.method] ?? 0) + 1;
          const request = { worker: worker.id, id: m.id, method: m.method, time: stamp() };
          if (m.method === "submit") request.batch = toJson(OrderBatchSchema, fromBinary(OrderBatchSchema, m.args[0]));
          if (m.method === "create") {
            const c = m.args[0];
            request.config = { seed: c.seed, ruleset: c.ruleset, players: c.players, map: { id: c.map.id, width: c.map.width, height: c.map.height } };
            data.create = request.config;
          }
          if (m.method === "load") request.engine = new TextDecoder().decode(m.args[0]);
          if (m.method === "seekReplay") request.tick = m.args[0];
          pending.set(m.id, request);
          if (["create", "load", "loadReplay", "seekReplay", "pause", "resume", "submit", "exportReplay"].includes(m.method)) append("requests", request);
        }
        return original.call(this, m, ...rest);
      };
      const terminate = this.terminate;
      this.terminate = function() {
        worker.live = false;
        worker.terminatedAt = stamp();
        return terminate.call(this);
      };
    }
  };
  var blobs = /* @__PURE__ */ new Map();
  var objectURL = URL.createObjectURL;
  var revokeURL = URL.revokeObjectURL;
  URL.createObjectURL = function(blob) {
    const url = objectURL.call(this, blob);
    if (blob instanceof Blob) blobs.set(url, blob);
    return url;
  };
  URL.revokeObjectURL = function(url) {
    blobs.delete(url);
    return revokeURL.call(this, url);
  };
  var anchorClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function() {
    const blob = blobs.get(this.href);
    if (this.download && blob) {
      const entry = { name: this.download, mime: blob.type, size: blob.size, ready: false };
      append("exports", entry, 8);
      void blob.arrayBuffer().then((buffer) => {
        const b = new Uint8Array(buffer);
        let binary = "";
        for (let i = 0; i < b.length; i += 16384) binary += String.fromCharCode(...b.subarray(i, i + 16384));
        entry.base64 = btoa(binary);
        entry.ready = true;
      }).catch((e) => append("errors", { kind: "export-capture", message: message(e) }));
      return;
    }
    return anchorClick.call(this);
  };
  window.__stockQA = { read: (large = false) => large ? data : {
    ...data,
    requests: data.requests.map(({ engine, ...entry }) => ({ ...entry, engineBytes: engine?.length })),
    saves: data.saves.map(({ engine, ...entry }) => ({ ...entry, engineBytes: engine.length })),
    exports: data.exports.map(({ base64, ...entry }) => entry)
  } };
})();
