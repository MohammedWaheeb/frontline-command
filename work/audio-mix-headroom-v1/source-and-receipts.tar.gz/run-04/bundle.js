var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// client/node_modules/react/cjs/react.development.js
var require_react_development = __commonJS({
  "client/node_modules/react/cjs/react.development.js"(exports, module) {
    "use strict";
    (function() {
      function defineDeprecationWarning(methodName, info) {
        Object.defineProperty(Component.prototype, methodName, {
          get: function() {
            console.warn(
              "%s(...) is deprecated in plain JavaScript React classes. %s",
              info[0],
              info[1]
            );
          }
        });
      }
      function getIteratorFn(maybeIterable) {
        if (null === maybeIterable || "object" !== typeof maybeIterable)
          return null;
        maybeIterable = MAYBE_ITERATOR_SYMBOL && maybeIterable[MAYBE_ITERATOR_SYMBOL] || maybeIterable["@@iterator"];
        return "function" === typeof maybeIterable ? maybeIterable : null;
      }
      function warnNoop(publicInstance, callerName) {
        publicInstance = (publicInstance = publicInstance.constructor) && (publicInstance.displayName || publicInstance.name) || "ReactClass";
        var warningKey = publicInstance + "." + callerName;
        didWarnStateUpdateForUnmountedComponent[warningKey] || (console.error(
          "Can't call %s on a component that is not yet mounted. This is a no-op, but it might indicate a bug in your application. Instead, assign to `this.state` directly or define a `state = {};` class property with the desired state in the %s component.",
          callerName,
          publicInstance
        ), didWarnStateUpdateForUnmountedComponent[warningKey] = true);
      }
      function Component(props, context, updater) {
        this.props = props;
        this.context = context;
        this.refs = emptyObject;
        this.updater = updater || ReactNoopUpdateQueue;
      }
      function ComponentDummy() {
      }
      function PureComponent(props, context, updater) {
        this.props = props;
        this.context = context;
        this.refs = emptyObject;
        this.updater = updater || ReactNoopUpdateQueue;
      }
      function noop() {
      }
      function testStringCoercion(value) {
        return "" + value;
      }
      function checkKeyStringCoercion(value) {
        try {
          testStringCoercion(value);
          var JSCompiler_inline_result = false;
        } catch (e) {
          JSCompiler_inline_result = true;
        }
        if (JSCompiler_inline_result) {
          JSCompiler_inline_result = console;
          var JSCompiler_temp_const = JSCompiler_inline_result.error;
          var JSCompiler_inline_result$jscomp$0 = "function" === typeof Symbol && Symbol.toStringTag && value[Symbol.toStringTag] || value.constructor.name || "Object";
          JSCompiler_temp_const.call(
            JSCompiler_inline_result,
            "The provided key is an unsupported type %s. This value must be coerced to a string before using it here.",
            JSCompiler_inline_result$jscomp$0
          );
          return testStringCoercion(value);
        }
      }
      function getComponentNameFromType(type) {
        if (null == type) return null;
        if ("function" === typeof type)
          return type.$$typeof === REACT_CLIENT_REFERENCE ? null : type.displayName || type.name || null;
        if ("string" === typeof type) return type;
        switch (type) {
          case REACT_FRAGMENT_TYPE:
            return "Fragment";
          case REACT_PROFILER_TYPE:
            return "Profiler";
          case REACT_STRICT_MODE_TYPE:
            return "StrictMode";
          case REACT_SUSPENSE_TYPE:
            return "Suspense";
          case REACT_SUSPENSE_LIST_TYPE:
            return "SuspenseList";
          case REACT_ACTIVITY_TYPE:
            return "Activity";
          case REACT_VIEW_TRANSITION_TYPE:
            return "ViewTransition";
        }
        if ("object" === typeof type)
          switch ("number" === typeof type.tag && console.error(
            "Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."
          ), type.$$typeof) {
            case REACT_PORTAL_TYPE:
              return "Portal";
            case REACT_CONTEXT_TYPE:
              return type.displayName || "Context";
            case REACT_CONSUMER_TYPE:
              return (type._context.displayName || "Context") + ".Consumer";
            case REACT_FORWARD_REF_TYPE:
              var innerType = type.render;
              type = type.displayName;
              type || (type = innerType.displayName || innerType.name || "", type = "" !== type ? "ForwardRef(" + type + ")" : "ForwardRef");
              return type;
            case REACT_MEMO_TYPE:
              return innerType = type.displayName || null, null !== innerType ? innerType : getComponentNameFromType(type.type) || "Memo";
            case REACT_LAZY_TYPE:
              innerType = type._payload;
              type = type._init;
              try {
                return getComponentNameFromType(type(innerType));
              } catch (x) {
              }
          }
        return null;
      }
      function getTaskName(type) {
        if (type === REACT_FRAGMENT_TYPE) return "<>";
        if ("object" === typeof type && null !== type && type.$$typeof === REACT_LAZY_TYPE)
          return "<...>";
        try {
          var name = getComponentNameFromType(type);
          return name ? "<" + name + ">" : "<...>";
        } catch (x) {
          return "<...>";
        }
      }
      function getOwner() {
        var dispatcher = ReactSharedInternals.A;
        return null === dispatcher ? null : dispatcher.getOwner();
      }
      function UnknownOwner() {
        return Error("react-stack-top-frame");
      }
      function hasValidKey(config) {
        if (hasOwnProperty.call(config, "key")) {
          var getter = Object.getOwnPropertyDescriptor(config, "key").get;
          if (getter && getter.isReactWarning) return false;
        }
        return void 0 !== config.key;
      }
      function defineKeyPropWarningGetter(props, displayName) {
        function warnAboutAccessingKey() {
          specialPropKeyWarningShown || (specialPropKeyWarningShown = true, console.error(
            "%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)",
            displayName
          ));
        }
        warnAboutAccessingKey.isReactWarning = true;
        Object.defineProperty(props, "key", {
          get: warnAboutAccessingKey,
          configurable: true
        });
      }
      function elementRefGetterWithDeprecationWarning() {
        var componentName = getComponentNameFromType(this.type);
        didWarnAboutElementRef[componentName] || (didWarnAboutElementRef[componentName] = true, console.error(
          "Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release."
        ));
        componentName = this.props.ref;
        return void 0 !== componentName ? componentName : null;
      }
      function ReactElement(type, key, props, owner, debugStack, debugTask) {
        var refProp = props.ref;
        type = {
          $$typeof: REACT_ELEMENT_TYPE,
          type,
          key,
          props,
          _owner: owner
        };
        null !== (void 0 !== refProp ? refProp : null) ? Object.defineProperty(type, "ref", {
          enumerable: false,
          get: elementRefGetterWithDeprecationWarning
        }) : Object.defineProperty(type, "ref", { enumerable: false, value: null });
        type._store = {};
        Object.defineProperty(type._store, "validated", {
          configurable: false,
          enumerable: false,
          writable: true,
          value: 0
        });
        Object.defineProperty(type, "_debugInfo", {
          configurable: false,
          enumerable: false,
          writable: true,
          value: null
        });
        Object.defineProperty(type, "_debugStack", {
          configurable: false,
          enumerable: false,
          writable: true,
          value: debugStack
        });
        Object.defineProperty(type, "_debugTask", {
          configurable: false,
          enumerable: false,
          writable: true,
          value: debugTask
        });
        Object.freeze && (Object.freeze(type.props), Object.freeze(type));
        return type;
      }
      function cloneAndReplaceKey(oldElement, newKey) {
        newKey = ReactElement(
          oldElement.type,
          newKey,
          oldElement.props,
          oldElement._owner,
          oldElement._debugStack,
          oldElement._debugTask
        );
        oldElement._store && (newKey._store.validated = oldElement._store.validated);
        return newKey;
      }
      function validateChildKeys(node) {
        isValidElement(node) ? node._store && (node._store.validated = 1) : "object" === typeof node && null !== node && node.$$typeof === REACT_LAZY_TYPE && ("fulfilled" === node._payload.status ? isValidElement(node._payload.value) && node._payload.value._store && (node._payload.value._store.validated = 1) : node._store && (node._store.validated = 1));
      }
      function isValidElement(object) {
        return "object" === typeof object && null !== object && object.$$typeof === REACT_ELEMENT_TYPE;
      }
      function escape(key) {
        var escaperLookup = { "=": "=0", ":": "=2" };
        return "$" + key.replace(/[=:]/g, function(match) {
          return escaperLookup[match];
        });
      }
      function getElementKey(element, index) {
        return "object" === typeof element && null !== element && null != element.key ? (checkKeyStringCoercion(element.key), escape("" + element.key)) : index.toString(36);
      }
      function resolveThenable(thenable) {
        switch (thenable.status) {
          case "fulfilled":
            return thenable.value;
          case "rejected":
            throw thenable.reason;
          default:
            switch ("string" === typeof thenable.status ? thenable.then(noop, noop) : (thenable.status = "pending", thenable.then(
              function(fulfilledValue) {
                "pending" === thenable.status && (thenable.status = "fulfilled", thenable.value = fulfilledValue);
              },
              function(error) {
                "pending" === thenable.status && (thenable.status = "rejected", thenable.reason = error);
              }
            )), thenable.status) {
              case "fulfilled":
                return thenable.value;
              case "rejected":
                throw thenable.reason;
            }
        }
        throw thenable;
      }
      function mapIntoArray(children, array, escapedPrefix, nameSoFar, callback) {
        var type = typeof children;
        if ("undefined" === type || "boolean" === type) children = null;
        var invokeCallback = false;
        if (null === children) invokeCallback = true;
        else
          switch (type) {
            case "bigint":
            case "string":
            case "number":
              invokeCallback = true;
              break;
            case "object":
              switch (children.$$typeof) {
                case REACT_ELEMENT_TYPE:
                case REACT_PORTAL_TYPE:
                  invokeCallback = true;
                  break;
                case REACT_LAZY_TYPE:
                  return invokeCallback = children._init, mapIntoArray(
                    invokeCallback(children._payload),
                    array,
                    escapedPrefix,
                    nameSoFar,
                    callback
                  );
              }
          }
        if (invokeCallback) {
          invokeCallback = children;
          callback = callback(invokeCallback);
          var childKey = "" === nameSoFar ? "." + getElementKey(invokeCallback, 0) : nameSoFar;
          isArrayImpl(callback) ? (escapedPrefix = "", null != childKey && (escapedPrefix = childKey.replace(userProvidedKeyEscapeRegex, "$&/") + "/"), mapIntoArray(callback, array, escapedPrefix, "", function(c) {
            return c;
          })) : null != callback && (isValidElement(callback) && (null != callback.key && (invokeCallback && invokeCallback.key === callback.key || checkKeyStringCoercion(callback.key)), escapedPrefix = cloneAndReplaceKey(
            callback,
            escapedPrefix + (null == callback.key || invokeCallback && invokeCallback.key === callback.key ? "" : ("" + callback.key).replace(
              userProvidedKeyEscapeRegex,
              "$&/"
            ) + "/") + childKey
          ), "" !== nameSoFar && null != invokeCallback && isValidElement(invokeCallback) && null == invokeCallback.key && invokeCallback._store && !invokeCallback._store.validated && (escapedPrefix._store.validated = 2), callback = escapedPrefix), array.push(callback));
          return 1;
        }
        invokeCallback = 0;
        childKey = "" === nameSoFar ? "." : nameSoFar + ":";
        if (isArrayImpl(children))
          for (var i = 0; i < children.length; i++)
            nameSoFar = children[i], type = childKey + getElementKey(nameSoFar, i), invokeCallback += mapIntoArray(
              nameSoFar,
              array,
              escapedPrefix,
              type,
              callback
            );
        else if (i = getIteratorFn(children), "function" === typeof i)
          for (i === children.entries && (didWarnAboutMaps || console.warn(
            "Using Maps as children is not supported. Use an array of keyed ReactElements instead."
          ), didWarnAboutMaps = true), children = i.call(children), i = 0; !(nameSoFar = children.next()).done; )
            nameSoFar = nameSoFar.value, type = childKey + getElementKey(nameSoFar, i++), invokeCallback += mapIntoArray(
              nameSoFar,
              array,
              escapedPrefix,
              type,
              callback
            );
        else if ("object" === type) {
          if ("function" === typeof children.then)
            return mapIntoArray(
              resolveThenable(children),
              array,
              escapedPrefix,
              nameSoFar,
              callback
            );
          array = String(children);
          throw Error(
            "Objects are not valid as a React child (found: " + ("[object Object]" === array ? "object with keys {" + Object.keys(children).join(", ") + "}" : array) + "). If you meant to render a collection of children, use an array instead."
          );
        }
        return invokeCallback;
      }
      function mapChildren(children, func, context) {
        if (null == children) return children;
        var result = [], count = 0;
        mapIntoArray(children, result, "", "", function(child) {
          return func.call(context, child, count++);
        });
        return result;
      }
      function lazyInitializer(payload) {
        if (-1 === payload._status) {
          var resolveDebugValue = null, rejectDebugValue = null, ioInfo = payload._ioInfo;
          null != ioInfo && (ioInfo.start = ioInfo.end = performance.now(), ioInfo.value = new Promise(function(resolve, reject) {
            resolveDebugValue = resolve;
            rejectDebugValue = reject;
          }));
          ioInfo = payload._result;
          var thenable = ioInfo();
          thenable.then(
            function(moduleObject) {
              if (0 === payload._status || -1 === payload._status) {
                payload._status = 1;
                payload._result = moduleObject;
                var _ioInfo = payload._ioInfo;
                if (null != _ioInfo) {
                  _ioInfo.end = performance.now();
                  var debugValue = null == moduleObject ? void 0 : moduleObject.default;
                  resolveDebugValue(debugValue);
                  _ioInfo.value.status = "fulfilled";
                  _ioInfo.value.value = debugValue;
                }
                void 0 === thenable.status && (thenable.status = "fulfilled", thenable.value = moduleObject);
              }
            },
            function(error) {
              if (0 === payload._status || -1 === payload._status) {
                payload._status = 2;
                payload._result = error;
                var _ioInfo2 = payload._ioInfo;
                null != _ioInfo2 && (_ioInfo2.end = performance.now(), _ioInfo2.value.then(noop, noop), rejectDebugValue(error), _ioInfo2.value.status = "rejected", _ioInfo2.value.reason = error);
                void 0 === thenable.status && (thenable.status = "rejected", thenable.reason = error);
              }
            }
          );
          ioInfo = payload._ioInfo;
          if (null != ioInfo) {
            var displayName = thenable.displayName;
            "string" === typeof displayName && (ioInfo.name = displayName);
          }
          -1 === payload._status && (payload._status = 0, payload._result = thenable);
        }
        if (1 === payload._status)
          return ioInfo = payload._result, void 0 === ioInfo && console.error(
            "lazy: Expected the result of a dynamic import() call. Instead received: %s\n\nYour code should look like: \n  const MyComponent = lazy(() => import('./MyComponent'))\n\nDid you accidentally put curly braces around the import?",
            ioInfo
          ), "default" in ioInfo || console.error(
            "lazy: Expected the result of a dynamic import() call. Instead received: %s\n\nYour code should look like: \n  const MyComponent = lazy(() => import('./MyComponent'))",
            ioInfo
          ), ioInfo.default;
        throw payload._result;
      }
      function resolveDispatcher() {
        var dispatcher = ReactSharedInternals.H;
        null === dispatcher && console.error(
          "Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:\n1. You might have mismatching versions of React and the renderer (such as React DOM)\n2. You might be breaking the Rules of Hooks\n3. You might have more than one copy of React in the same app\nSee https://react.dev/link/invalid-hook-call for tips about how to debug and fix this problem."
        );
        return dispatcher;
      }
      function releaseAsyncTransition() {
        ReactSharedInternals.asyncTransitions--;
      }
      function startTransition(scope) {
        var prevTransition = ReactSharedInternals.T, currentTransition = {};
        currentTransition.types = null !== prevTransition ? prevTransition.types : null;
        currentTransition._updatedFibers = /* @__PURE__ */ new Set();
        ReactSharedInternals.T = currentTransition;
        try {
          var returnValue = scope(), onStartTransitionFinish = ReactSharedInternals.S;
          null !== onStartTransitionFinish && onStartTransitionFinish(currentTransition, returnValue);
          "object" === typeof returnValue && null !== returnValue && "function" === typeof returnValue.then && (ReactSharedInternals.asyncTransitions++, returnValue.then(releaseAsyncTransition, releaseAsyncTransition), returnValue.then(noop, reportGlobalError));
        } catch (error) {
          reportGlobalError(error);
        } finally {
          null === prevTransition && currentTransition._updatedFibers && (scope = currentTransition._updatedFibers.size, currentTransition._updatedFibers.clear(), 10 < scope && console.warn(
            "Detected a large number of updates inside startTransition. If this is due to a subscription please re-write it to use React provided hooks. Otherwise concurrent mode guarantees are off the table."
          )), null !== prevTransition && null !== currentTransition.types && (null !== prevTransition.types && prevTransition.types !== currentTransition.types && console.error(
            "We expected inner Transitions to have transferred the outer types set and that you cannot add to the outer Transition while inside the inner.This is a bug in React."
          ), prevTransition.types = currentTransition.types), ReactSharedInternals.T = prevTransition;
        }
      }
      function addTransitionType(type) {
        var transition = ReactSharedInternals.T;
        if (null !== transition) {
          var transitionTypes = transition.types;
          null === transitionTypes ? transition.types = [type] : -1 === transitionTypes.indexOf(type) && transitionTypes.push(type);
        } else
          0 === ReactSharedInternals.asyncTransitions && console.error(
            "addTransitionType can only be called inside a `startTransition()` callback. It must be associated with a specific Transition."
          ), startTransition(addTransitionType.bind(null, type));
      }
      function enqueueTask(task) {
        if (null === enqueueTaskImpl)
          try {
            var requireString = ("require" + Math.random()).slice(0, 7);
            enqueueTaskImpl = (module && module[requireString]).call(
              module,
              "timers"
            ).setImmediate;
          } catch (_err) {
            enqueueTaskImpl = function(callback) {
              false === didWarnAboutMessageChannel && (didWarnAboutMessageChannel = true, "undefined" === typeof MessageChannel && console.error(
                "This browser does not have a MessageChannel implementation, so enqueuing tasks via await act(async () => ...) will fail. Please file an issue at https://github.com/facebook/react/issues if you encounter this warning."
              ));
              var channel = new MessageChannel();
              channel.port1.onmessage = callback;
              channel.port2.postMessage(void 0);
            };
          }
        return enqueueTaskImpl(task);
      }
      function aggregateErrors(errors) {
        return 1 < errors.length && "function" === typeof AggregateError ? new AggregateError(errors) : errors[0];
      }
      function popActScope(prevActQueue, prevActScopeDepth) {
        prevActScopeDepth !== actScopeDepth - 1 && console.error(
          "You seem to have overlapping act() calls, this is not supported. Be sure to await previous act() calls before making a new one. "
        );
        actScopeDepth = prevActScopeDepth;
      }
      function recursivelyFlushAsyncActWork(returnValue, resolve, reject) {
        var queue = ReactSharedInternals.actQueue;
        if (null !== queue)
          if (0 !== queue.length)
            try {
              flushActQueue(queue);
              enqueueTask(function() {
                return recursivelyFlushAsyncActWork(returnValue, resolve, reject);
              });
              return;
            } catch (error) {
              ReactSharedInternals.thrownErrors.push(error);
            }
          else ReactSharedInternals.actQueue = null;
        0 < ReactSharedInternals.thrownErrors.length ? (queue = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, reject(queue)) : resolve(returnValue);
      }
      function flushActQueue(queue) {
        if (!isFlushing) {
          isFlushing = true;
          var i = 0;
          try {
            for (; i < queue.length; i++) {
              var callback = queue[i];
              do {
                ReactSharedInternals.didUsePromise = false;
                var continuation = callback(false);
                if (null !== continuation) {
                  if (ReactSharedInternals.didUsePromise) {
                    queue[i] = callback;
                    queue.splice(0, i);
                    return;
                  }
                  callback = continuation;
                } else break;
              } while (1);
            }
            queue.length = 0;
          } catch (error) {
            queue.splice(0, i + 1), ReactSharedInternals.thrownErrors.push(error);
          } finally {
            isFlushing = false;
          }
        }
      }
      "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
      var REACT_ELEMENT_TYPE = /* @__PURE__ */ Symbol.for("react.transitional.element"), REACT_PORTAL_TYPE = /* @__PURE__ */ Symbol.for("react.portal"), REACT_FRAGMENT_TYPE = /* @__PURE__ */ Symbol.for("react.fragment"), REACT_STRICT_MODE_TYPE = /* @__PURE__ */ Symbol.for("react.strict_mode"), REACT_PROFILER_TYPE = /* @__PURE__ */ Symbol.for("react.profiler"), REACT_CONSUMER_TYPE = /* @__PURE__ */ Symbol.for("react.consumer"), REACT_CONTEXT_TYPE = /* @__PURE__ */ Symbol.for("react.context"), REACT_FORWARD_REF_TYPE = /* @__PURE__ */ Symbol.for("react.forward_ref"), REACT_SUSPENSE_TYPE = /* @__PURE__ */ Symbol.for("react.suspense"), REACT_SUSPENSE_LIST_TYPE = /* @__PURE__ */ Symbol.for("react.suspense_list"), REACT_MEMO_TYPE = /* @__PURE__ */ Symbol.for("react.memo"), REACT_LAZY_TYPE = /* @__PURE__ */ Symbol.for("react.lazy"), REACT_ACTIVITY_TYPE = /* @__PURE__ */ Symbol.for("react.activity"), REACT_VIEW_TRANSITION_TYPE = /* @__PURE__ */ Symbol.for("react.view_transition"), MAYBE_ITERATOR_SYMBOL = Symbol.iterator, didWarnStateUpdateForUnmountedComponent = {}, ReactNoopUpdateQueue = {
        isMounted: function() {
          return false;
        },
        enqueueForceUpdate: function(publicInstance) {
          warnNoop(publicInstance, "forceUpdate");
        },
        enqueueReplaceState: function(publicInstance) {
          warnNoop(publicInstance, "replaceState");
        },
        enqueueSetState: function(publicInstance) {
          warnNoop(publicInstance, "setState");
        }
      }, assign = Object.assign, emptyObject = {};
      Object.freeze(emptyObject);
      Component.prototype.isReactComponent = {};
      Component.prototype.setState = function(partialState, callback) {
        if ("object" !== typeof partialState && "function" !== typeof partialState && null != partialState)
          throw Error(
            "takes an object of state variables to update or a function which returns an object of state variables."
          );
        this.updater.enqueueSetState(this, partialState, callback, "setState");
      };
      Component.prototype.forceUpdate = function(callback) {
        this.updater.enqueueForceUpdate(this, callback, "forceUpdate");
      };
      var deprecatedAPIs = {
        isMounted: [
          "isMounted",
          "Instead, make sure to clean up subscriptions and pending requests in componentWillUnmount to prevent memory leaks."
        ],
        replaceState: [
          "replaceState",
          "Refactor your code to use setState instead (see https://github.com/facebook/react/issues/3236)."
        ]
      };
      for (fnName in deprecatedAPIs)
        deprecatedAPIs.hasOwnProperty(fnName) && defineDeprecationWarning(fnName, deprecatedAPIs[fnName]);
      ComponentDummy.prototype = Component.prototype;
      deprecatedAPIs = PureComponent.prototype = new ComponentDummy();
      deprecatedAPIs.constructor = PureComponent;
      assign(deprecatedAPIs, Component.prototype);
      deprecatedAPIs.isPureReactComponent = true;
      var isArrayImpl = Array.isArray, REACT_CLIENT_REFERENCE = /* @__PURE__ */ Symbol.for("react.client.reference"), ReactSharedInternals = {
        H: null,
        A: null,
        T: null,
        S: null,
        actQueue: null,
        asyncTransitions: 0,
        isBatchingLegacy: false,
        didScheduleLegacyUpdate: false,
        didUsePromise: false,
        thrownErrors: [],
        getCurrentStack: null,
        recentlyCreatedOwnerStacks: 0
      }, hasOwnProperty = Object.prototype.hasOwnProperty, createTask = console.createTask ? console.createTask : function() {
        return null;
      };
      deprecatedAPIs = {
        react_stack_bottom_frame: function(callStackForError) {
          return callStackForError();
        }
      };
      var specialPropKeyWarningShown, didWarnAboutOldJSXRuntime;
      var didWarnAboutElementRef = {};
      var unknownOwnerDebugStack = deprecatedAPIs.react_stack_bottom_frame.bind(
        deprecatedAPIs,
        UnknownOwner
      )();
      var unknownOwnerDebugTask = createTask(getTaskName(UnknownOwner));
      var didWarnAboutMaps = false, userProvidedKeyEscapeRegex = /\/+/g, reportGlobalError = "function" === typeof reportError ? reportError : function(error) {
        if ("object" === typeof window && "function" === typeof window.ErrorEvent) {
          var event = new window.ErrorEvent("error", {
            bubbles: true,
            cancelable: true,
            message: "object" === typeof error && null !== error && "string" === typeof error.message ? String(error.message) : String(error),
            error
          });
          if (!window.dispatchEvent(event)) return;
        } else if ("object" === typeof process && "function" === typeof process.emit) {
          process.emit("uncaughtException", error);
          return;
        }
        console.error(error);
      }, didWarnAboutMessageChannel = false, enqueueTaskImpl = null, actScopeDepth = 0, didWarnNoAwaitAct = false, isFlushing = false, queueSeveralMicrotasks = "function" === typeof queueMicrotask ? function(callback) {
        queueMicrotask(function() {
          return queueMicrotask(callback);
        });
      } : enqueueTask;
      deprecatedAPIs = Object.freeze({
        __proto__: null,
        c: function(size) {
          return resolveDispatcher().useMemoCache(size);
        }
      });
      var fnName = {
        map: mapChildren,
        forEach: function(children, forEachFunc, forEachContext) {
          mapChildren(
            children,
            function() {
              forEachFunc.apply(this, arguments);
            },
            forEachContext
          );
        },
        count: function(children) {
          var n = 0;
          mapChildren(children, function() {
            n++;
          });
          return n;
        },
        toArray: function(children) {
          return mapChildren(children, function(child) {
            return child;
          }) || [];
        },
        only: function(children) {
          if (!isValidElement(children))
            throw Error(
              "React.Children.only expected to receive a single React element child."
            );
          return children;
        }
      };
      exports.Activity = REACT_ACTIVITY_TYPE;
      exports.Children = fnName;
      exports.Component = Component;
      exports.Fragment = REACT_FRAGMENT_TYPE;
      exports.Profiler = REACT_PROFILER_TYPE;
      exports.PureComponent = PureComponent;
      exports.StrictMode = REACT_STRICT_MODE_TYPE;
      exports.Suspense = REACT_SUSPENSE_TYPE;
      exports.ViewTransition = REACT_VIEW_TRANSITION_TYPE;
      exports.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = ReactSharedInternals;
      exports.__COMPILER_RUNTIME = deprecatedAPIs;
      exports.act = function(callback) {
        var prevActQueue = ReactSharedInternals.actQueue, prevActScopeDepth = actScopeDepth;
        actScopeDepth++;
        var queue = ReactSharedInternals.actQueue = null !== prevActQueue ? prevActQueue : [], didAwaitActCall = false;
        try {
          var result = callback();
        } catch (error) {
          ReactSharedInternals.thrownErrors.push(error);
        }
        if (0 < ReactSharedInternals.thrownErrors.length)
          throw popActScope(prevActQueue, prevActScopeDepth), callback = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, callback;
        if (null !== result && "object" === typeof result && "function" === typeof result.then) {
          var thenable = result;
          queueSeveralMicrotasks(function() {
            didAwaitActCall || didWarnNoAwaitAct || (didWarnNoAwaitAct = true, console.error(
              "You called act(async () => ...) without await. This could lead to unexpected testing behaviour, interleaving multiple act calls and mixing their scopes. You should - await act(async () => ...);"
            ));
          });
          return {
            then: function(resolve, reject) {
              didAwaitActCall = true;
              thenable.then(
                function(returnValue) {
                  popActScope(prevActQueue, prevActScopeDepth);
                  if (0 === prevActScopeDepth) {
                    try {
                      flushActQueue(queue), enqueueTask(function() {
                        return recursivelyFlushAsyncActWork(
                          returnValue,
                          resolve,
                          reject
                        );
                      });
                    } catch (error$0) {
                      ReactSharedInternals.thrownErrors.push(error$0);
                    }
                    if (0 < ReactSharedInternals.thrownErrors.length) {
                      var _thrownError = aggregateErrors(
                        ReactSharedInternals.thrownErrors
                      );
                      ReactSharedInternals.thrownErrors.length = 0;
                      reject(_thrownError);
                    }
                  } else resolve(returnValue);
                },
                function(error) {
                  popActScope(prevActQueue, prevActScopeDepth);
                  0 < ReactSharedInternals.thrownErrors.length ? (error = aggregateErrors(
                    ReactSharedInternals.thrownErrors
                  ), ReactSharedInternals.thrownErrors.length = 0, reject(error)) : reject(error);
                }
              );
            }
          };
        }
        var returnValue$jscomp$0 = result;
        popActScope(prevActQueue, prevActScopeDepth);
        0 === prevActScopeDepth && (flushActQueue(queue), 0 !== queue.length && queueSeveralMicrotasks(function() {
          didAwaitActCall || didWarnNoAwaitAct || (didWarnNoAwaitAct = true, console.error(
            "A component suspended inside an `act` scope, but the `act` call was not awaited. When testing React components that depend on asynchronous data, you must await the result:\n\nawait act(() => ...)"
          ));
        }), ReactSharedInternals.actQueue = null);
        if (0 < ReactSharedInternals.thrownErrors.length)
          throw callback = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, callback;
        return {
          then: function(resolve, reject) {
            didAwaitActCall = true;
            0 === prevActScopeDepth ? (ReactSharedInternals.actQueue = queue, enqueueTask(function() {
              return recursivelyFlushAsyncActWork(
                returnValue$jscomp$0,
                resolve,
                reject
              );
            })) : resolve(returnValue$jscomp$0);
          }
        };
      };
      exports.addTransitionType = addTransitionType;
      exports.cache = function(fn) {
        return function() {
          return fn.apply(null, arguments);
        };
      };
      exports.cacheSignal = function() {
        return null;
      };
      exports.captureOwnerStack = function() {
        var getCurrentStack = ReactSharedInternals.getCurrentStack;
        return null === getCurrentStack ? null : getCurrentStack();
      };
      exports.cloneElement = function(element, config, children) {
        if (null === element || void 0 === element)
          throw Error(
            "The argument must be a React element, but you passed " + element + "."
          );
        var props = assign({}, element.props), key = element.key, owner = element._owner;
        if (null != config) {
          var JSCompiler_inline_result;
          a: {
            if (hasOwnProperty.call(config, "ref") && (JSCompiler_inline_result = Object.getOwnPropertyDescriptor(
              config,
              "ref"
            ).get) && JSCompiler_inline_result.isReactWarning) {
              JSCompiler_inline_result = false;
              break a;
            }
            JSCompiler_inline_result = void 0 !== config.ref;
          }
          JSCompiler_inline_result && (owner = getOwner());
          hasValidKey(config) && (checkKeyStringCoercion(config.key), key = "" + config.key);
          for (propName in config)
            !hasOwnProperty.call(config, propName) || "key" === propName || "__self" === propName || "__source" === propName || "ref" === propName && void 0 === config.ref || (props[propName] = config[propName]);
        }
        var propName = arguments.length - 2;
        if (1 === propName) props.children = children;
        else if (1 < propName) {
          JSCompiler_inline_result = Array(propName);
          for (var i = 0; i < propName; i++)
            JSCompiler_inline_result[i] = arguments[i + 2];
          props.children = JSCompiler_inline_result;
        }
        props = ReactElement(
          element.type,
          key,
          props,
          owner,
          element._debugStack,
          element._debugTask
        );
        for (key = 2; key < arguments.length; key++)
          validateChildKeys(arguments[key]);
        return props;
      };
      exports.createContext = function(defaultValue) {
        defaultValue = {
          $$typeof: REACT_CONTEXT_TYPE,
          _currentValue: defaultValue,
          _currentValue2: defaultValue,
          _threadCount: 0,
          Provider: null,
          Consumer: null
        };
        defaultValue.Provider = defaultValue;
        defaultValue.Consumer = {
          $$typeof: REACT_CONSUMER_TYPE,
          _context: defaultValue
        };
        defaultValue._currentRenderer = null;
        defaultValue._currentRenderer2 = null;
        return defaultValue;
      };
      exports.createElement = function(type, config, children) {
        for (var i = 2; i < arguments.length; i++)
          validateChildKeys(arguments[i]);
        var propName;
        i = {};
        var key = null;
        if (null != config)
          for (propName in didWarnAboutOldJSXRuntime || !("__self" in config) || "key" in config || (didWarnAboutOldJSXRuntime = true, console.warn(
            "Your app (or one of its dependencies) is using an outdated JSX transform. Update to the modern JSX transform for faster performance: https://react.dev/link/new-jsx-transform"
          )), hasValidKey(config) && (checkKeyStringCoercion(config.key), key = "" + config.key), config)
            hasOwnProperty.call(config, propName) && "key" !== propName && "__self" !== propName && "__source" !== propName && (i[propName] = config[propName]);
        var childrenLength = arguments.length - 2;
        if (1 === childrenLength) i.children = children;
        else if (1 < childrenLength) {
          for (var childArray = Array(childrenLength), _i = 0; _i < childrenLength; _i++)
            childArray[_i] = arguments[_i + 2];
          Object.freeze && Object.freeze(childArray);
          i.children = childArray;
        }
        if (type && type.defaultProps)
          for (propName in childrenLength = type.defaultProps, childrenLength)
            void 0 === i[propName] && (i[propName] = childrenLength[propName]);
        key && defineKeyPropWarningGetter(
          i,
          "function" === typeof type ? type.displayName || type.name || "Unknown" : type
        );
        (propName = 1e4 > ReactSharedInternals.recentlyCreatedOwnerStacks++) ? (childArray = Error.stackTraceLimit, Error.stackTraceLimit = 10, childrenLength = Error("react-stack-top-frame"), Error.stackTraceLimit = childArray) : childrenLength = unknownOwnerDebugStack;
        return ReactElement(
          type,
          key,
          i,
          getOwner(),
          childrenLength,
          propName ? createTask(getTaskName(type)) : unknownOwnerDebugTask
        );
      };
      exports.createRef = function() {
        var refObject = { current: null };
        Object.seal(refObject);
        return refObject;
      };
      exports.forwardRef = function(render) {
        null != render && render.$$typeof === REACT_MEMO_TYPE ? console.error(
          "forwardRef requires a render function but received a `memo` component. Instead of forwardRef(memo(...)), use memo(forwardRef(...))."
        ) : "function" !== typeof render ? console.error(
          "forwardRef requires a render function but was given %s.",
          null === render ? "null" : typeof render
        ) : 0 !== render.length && 2 !== render.length && console.error(
          "forwardRef render functions accept exactly two parameters: props and ref. %s",
          1 === render.length ? "Did you forget to use the ref parameter?" : "Any additional parameter will be undefined."
        );
        null != render && null != render.defaultProps && console.error(
          "forwardRef render functions do not support defaultProps. Did you accidentally pass a React component?"
        );
        var elementType = { $$typeof: REACT_FORWARD_REF_TYPE, render }, ownName;
        Object.defineProperty(elementType, "displayName", {
          enumerable: false,
          configurable: true,
          get: function() {
            return ownName;
          },
          set: function(name) {
            ownName = name;
            render.name || render.displayName || (Object.defineProperty(render, "name", { value: name }), render.displayName = name);
          }
        });
        return elementType;
      };
      exports.isValidElement = isValidElement;
      exports.lazy = function(ctor) {
        ctor = { _status: -1, _result: ctor };
        var lazyType = {
          $$typeof: REACT_LAZY_TYPE,
          _payload: ctor,
          _init: lazyInitializer
        }, ioInfo = {
          name: "lazy",
          start: -1,
          end: -1,
          value: null,
          owner: null,
          debugStack: Error("react-stack-top-frame"),
          debugTask: console.createTask ? console.createTask("lazy()") : null
        };
        ctor._ioInfo = ioInfo;
        lazyType._debugInfo = [{ awaited: ioInfo }];
        return lazyType;
      };
      exports.memo = function(type, compare) {
        null == type && console.error(
          "memo: The first argument must be a component. Instead received: %s",
          null === type ? "null" : typeof type
        );
        compare = {
          $$typeof: REACT_MEMO_TYPE,
          type,
          compare: void 0 === compare ? null : compare
        };
        var ownName;
        Object.defineProperty(compare, "displayName", {
          enumerable: false,
          configurable: true,
          get: function() {
            return ownName;
          },
          set: function(name) {
            ownName = name;
            type.name || type.displayName || (Object.defineProperty(type, "name", { value: name }), type.displayName = name);
          }
        });
        return compare;
      };
      exports.startTransition = startTransition;
      exports.unstable_useCacheRefresh = function() {
        return resolveDispatcher().useCacheRefresh();
      };
      exports.use = function(usable) {
        return resolveDispatcher().use(usable);
      };
      exports.useActionState = function(action, initialState, permalink) {
        return resolveDispatcher().useActionState(
          action,
          initialState,
          permalink
        );
      };
      exports.useCallback = function(callback, deps) {
        return resolveDispatcher().useCallback(callback, deps);
      };
      exports.useContext = function(Context) {
        var dispatcher = resolveDispatcher();
        Context.$$typeof === REACT_CONSUMER_TYPE && console.error(
          "Calling useContext(Context.Consumer) is not supported and will cause bugs. Did you mean to call useContext(Context) instead?"
        );
        return dispatcher.useContext(Context);
      };
      exports.useDebugValue = function(value, formatterFn) {
        return resolveDispatcher().useDebugValue(value, formatterFn);
      };
      exports.useDeferredValue = function(value, initialValue) {
        return resolveDispatcher().useDeferredValue(value, initialValue);
      };
      exports.useEffect = function(create, deps) {
        null == create && console.warn(
          "React Hook useEffect requires an effect callback. Did you forget to pass a callback to the hook?"
        );
        return resolveDispatcher().useEffect(create, deps);
      };
      exports.useEffectEvent = function(callback) {
        return resolveDispatcher().useEffectEvent(callback);
      };
      exports.useId = function() {
        return resolveDispatcher().useId();
      };
      exports.useImperativeHandle = function(ref, create, deps) {
        return resolveDispatcher().useImperativeHandle(ref, create, deps);
      };
      exports.useInsertionEffect = function(create, deps) {
        null == create && console.warn(
          "React Hook useInsertionEffect requires an effect callback. Did you forget to pass a callback to the hook?"
        );
        return resolveDispatcher().useInsertionEffect(create, deps);
      };
      exports.useLayoutEffect = function(create, deps) {
        null == create && console.warn(
          "React Hook useLayoutEffect requires an effect callback. Did you forget to pass a callback to the hook?"
        );
        return resolveDispatcher().useLayoutEffect(create, deps);
      };
      exports.useMemo = function(create, deps) {
        return resolveDispatcher().useMemo(create, deps);
      };
      exports.useOptimistic = function(passthrough, reducer) {
        return resolveDispatcher().useOptimistic(passthrough, reducer);
      };
      exports.useReducer = function(reducer, initialArg, init) {
        return resolveDispatcher().useReducer(reducer, initialArg, init);
      };
      exports.useRef = function(initialValue) {
        return resolveDispatcher().useRef(initialValue);
      };
      exports.useState = function(initialState) {
        return resolveDispatcher().useState(initialState);
      };
      exports.useSyncExternalStore = function(subscribe, getSnapshot, getServerSnapshot) {
        return resolveDispatcher().useSyncExternalStore(
          subscribe,
          getSnapshot,
          getServerSnapshot
        );
      };
      exports.useTransition = function() {
        return resolveDispatcher().useTransition();
      };
      exports.version = "19.3.0";
      "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
    })();
  }
});

// client/node_modules/react/index.js
var require_react = __commonJS({
  "client/node_modules/react/index.js"(exports, module) {
    "use strict";
    if (false) {
      module.exports = null;
    } else {
      module.exports = require_react_development();
    }
  }
});

// work/audio-mix-headroom-v1/candidate/src/runtime/errors.ts
var RuntimeError = class _RuntimeError extends Error {
  constructor(code, message2, recoverable = true, details) {
    super(message2);
    this.code = code;
    this.recoverable = recoverable;
    this.details = details;
    this.name = "RuntimeError";
  }
  code;
  recoverable;
  details;
  static from(value) {
    if (value instanceof _RuntimeError) return value;
    if (value && typeof value === "object" && "code" in value && "message" in value) {
      const v = value;
      return new _RuntimeError(String(v.code), String(v.message), v.recoverable !== false, value);
    }
    return new _RuntimeError("runtime_failed", value instanceof Error ? value.message : String(value), false);
  }
};

// work/audio-mix-headroom-v1/candidate/src/runtime/crypto.ts
var constants = new Uint32Array([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]);
function rotate(value, bits) {
  return value >>> bits | value << 32 - bits;
}
function hex(bytes) {
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
}
function copy(data) {
  if (!(data instanceof Uint8Array)) throw new RuntimeError("hash_input", "Hash input must be bytes.");
  return data.slice();
}
async function fallback(data) {
  const state = new Uint32Array([1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225]), words = new Uint32Array(64);
  const process2 = (block, offset) => {
    for (let i = 0; i < 16; i++) {
      const at = offset + i * 4;
      words[i] = block[at] << 24 | block[at + 1] << 16 | block[at + 2] << 8 | block[at + 3];
    }
    for (let i = 16; i < 64; i++) {
      const x = words[i - 15], y = words[i - 2], s0 = rotate(x, 7) ^ rotate(x, 18) ^ x >>> 3, s1 = rotate(y, 17) ^ rotate(y, 19) ^ y >>> 10;
      words[i] = words[i - 16] + s0 + words[i - 7] + s1 >>> 0;
    }
    let [a, b, c, d, e, f, g, h] = state;
    for (let i = 0; i < 64; i++) {
      const sigma1 = rotate(e, 6) ^ rotate(e, 11) ^ rotate(e, 25), choice = e & f ^ ~e & g, t1 = h + sigma1 + choice + constants[i] + words[i] >>> 0;
      const sigma0 = rotate(a, 2) ^ rotate(a, 13) ^ rotate(a, 22), majority = a & b ^ a & c ^ b & c, t2 = sigma0 + majority >>> 0;
      h = g;
      g = f;
      f = e;
      e = d + t1 >>> 0;
      d = c;
      c = b;
      b = a;
      a = t1 + t2 >>> 0;
    }
    state[0] = state[0] + a >>> 0;
    state[1] = state[1] + b >>> 0;
    state[2] = state[2] + c >>> 0;
    state[3] = state[3] + d >>> 0;
    state[4] = state[4] + e >>> 0;
    state[5] = state[5] + f >>> 0;
    state[6] = state[6] + g >>> 0;
    state[7] = state[7] + h >>> 0;
  };
  const fullLength = data.length - data.length % 64;
  for (let offset = 0; offset < fullLength; offset += 64) {
    process2(data, offset);
    if (offset > 0 && offset % (256 * 1024) === 0) await new Promise((resolve) => setTimeout(resolve, 0));
  }
  const remaining = data.length - fullLength, tail = new Uint8Array(remaining < 56 ? 64 : 128);
  tail.set(data.subarray(fullLength));
  tail[remaining] = 128;
  const length = new DataView(tail.buffer);
  length.setUint32(tail.length - 8, Math.floor(data.length / 536870912), false);
  length.setUint32(tail.length - 4, data.length * 8 >>> 0, false);
  for (let offset = 0; offset < tail.length; offset += 64) process2(tail, offset);
  return Array.from(state, (word) => word.toString(16).padStart(8, "0")).join("");
}
async function sha256Hex(data) {
  const bytes = copy(data), subtle = globalThis.crypto?.subtle;
  if (subtle) {
    try {
      return hex(new Uint8Array(await subtle.digest("SHA-256", bytes.buffer)));
    } catch {
    }
  }
  return fallback(bytes);
}

// work/audio-mix-headroom-v1/candidate/src/app/store.ts
var import_react = __toESM(require_react());
var Observable = class {
  constructor(value) {
    this.value = value;
  }
  value;
  listeners = /* @__PURE__ */ new Set();
  get() {
    return this.value;
  }
  set(next) {
    if (Object.is(next, this.value)) return;
    this.value = next;
    for (const l of [...this.listeners]) l();
  }
  update(fn) {
    this.set(fn(this.value));
  }
  subscribe = (listener) => {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  };
};

// work/audio-mix-headroom-v1/candidate/src/audio/index.ts
function audioVariantKey(variant) {
  return JSON.stringify([variant.url, variant.bytes, variant.sha256, variant.duration, variant.mp3_url ?? null, variant.mp3_bytes ?? null, variant.mp3_sha256 ?? null]);
}
var record = (value) => !!value && typeof value === "object" && !Array.isArray(value);
var finite = (v, min, max) => typeof v === "number" && Number.isFinite(v) && v >= min && v <= max;
var keys = (v, allowed) => Object.keys(v).every((key) => allowed.includes(key));
function parseAudioIndex(value) {
  if (!record(value) || !keys(value, ["format", "sample_rate", "entries"]) || value.format !== 1 || !finite(value.sample_rate, 8e3, 96e3) || !record(value.entries) || Object.keys(value.entries).length > 4096) throw Error("Invalid audio index.");
  const entries = /* @__PURE__ */ Object.create(null);
  for (const [id, raw] of Object.entries(value.entries)) {
    if (!/^(vo|sfx|music)\.[a-zA-Z0-9_.-]{1,160}$/.test(id) || !record(raw) || !keys(raw, ["bus", "priority", "cooldown_ms", "loop", "bpm", "beats_per_bar", "variants"]) || !["voice", "music", "effects", "ui"].includes(String(raw.bus)) || !Array.isArray(raw.variants) || !raw.variants.length || raw.variants.length > 8 || !finite(raw.priority ?? 0, 0, 100) || !finite(raw.cooldown_ms ?? 0, 0, 6e4) || raw.loop !== void 0 && typeof raw.loop !== "boolean" || raw.bpm !== void 0 && !finite(raw.bpm, 30, 240) || raw.beats_per_bar !== void 0 && !finite(raw.beats_per_bar, 1, 16)) throw Error(`Invalid audio entry: ${id}`);
    const variants = raw.variants.map((variant) => {
      if (!record(variant) || !keys(variant, ["url", "caption", "display_caption", "duration", "bytes", "sha256", "mp3_url", "mp3_bytes", "mp3_sha256"]) || typeof variant.url !== "string" || !/^\/art\/audio\/(?:[a-zA-Z0-9_-]+\/)*[a-zA-Z0-9_.-]+\.(ogg|mp3|wav)$/.test(variant.url) || variant.url.includes("..") || !finite(variant.duration, 0.01, raw.bus === "music" ? 180 : 90) || !Number.isSafeInteger(variant.bytes) || !finite(variant.bytes, 1, 16 * 1024 ** 2) || typeof variant.sha256 !== "string" || !/^([a-f0-9]{64})$/.test(variant.sha256) || variant.caption !== void 0 && (typeof variant.caption !== "string" || variant.caption.length > 12e3) || variant.display_caption !== void 0 && (typeof variant.display_caption !== "string" || variant.display_caption.length > 12e3) || raw.bus === "voice" && !variant.caption) throw Error(`Invalid audio variant: ${id}`);
      if (variant.mp3_url !== void 0 || variant.mp3_bytes !== void 0 || variant.mp3_sha256 !== void 0) {
        if (typeof variant.mp3_url !== "string" || !/^\/art\/audio\/(?:[a-zA-Z0-9_-]+\/)*[a-zA-Z0-9_.-]+\.mp3$/.test(variant.mp3_url) || variant.mp3_url.includes("..") || !Number.isSafeInteger(variant.mp3_bytes) || !finite(variant.mp3_bytes, 1, 16 * 1024 ** 2) || typeof variant.mp3_sha256 !== "string" || !/^([a-f0-9]{64})$/.test(variant.mp3_sha256)) throw Error(`Invalid MP3 fallback: ${id}`);
      }
      return { ...variant };
    });
    entries[id] = { bus: raw.bus, priority: raw.priority ?? 0, cooldown_ms: raw.cooldown_ms ?? 0, loop: raw.loop === true, bpm: raw.bpm, beats_per_bar: raw.beats_per_bar, variants };
  }
  return { format: 1, sample_rate: value.sample_rate, entries };
}
async function boundedAudioBytes(response, max) {
  if (!response.ok || response.redirected || !response.body) throw Error(`Audio file unavailable (${response.status}).`);
  const reader = response.body.getReader(), parts = [];
  let length = 0;
  try {
    for (; ; ) {
      const result = await reader.read();
      if (result.done) break;
      length += result.value.length;
      if (length > max) throw Error("Audio file exceeds declared size.");
      parts.push(result.value);
    }
  } catch (error) {
    await reader.cancel();
    throw error;
  } finally {
    reader.releaseLock();
  }
  const bytes = new Uint8Array(length);
  let at = 0;
  for (const part of parts) {
    bytes.set(part, at);
    at += part.length;
  }
  return bytes;
}
var AudioCooldowns = class {
  until = /* @__PURE__ */ new Map();
  admit(key, now, ms) {
    if ((this.until.get(key) ?? -Infinity) > now) return false;
    this.until.set(key, now + ms);
    if (this.until.size > 512) {
      for (const [id, end] of this.until) if (end <= now) this.until.delete(id);
    }
    if (this.until.size > 1024) this.until.delete(this.until.keys().next().value);
    return true;
  }
  clear() {
    this.until.clear();
  }
};

// work/audio-mix-headroom-v1/candidate/src/audio/mixer.ts
var BUSES = ["voice", "music", "effects", "ui"];
var MEMORY = 64 * 1024 ** 2;
var VOICES = 24;
var AudioMixer = class {
  constructor(preferences, fetcher = (...args) => globalThis.fetch(...args)) {
    this.fetcher = fetcher;
    this.preferences = preferences;
    this.state.update((state) => ({ ...state, status: preferences.audioConsent ? "gesture" : "disabled" }));
  }
  fetcher;
  state = new Observable({ status: "disabled", captions: [] });
  cooldowns = new AudioCooldowns();
  continuousRequests = /* @__PURE__ */ new Map();
  continuousSources = /* @__PURE__ */ new Map();
  continuousPending = /* @__PURE__ */ new Map();
  continuousNext = /* @__PURE__ */ new Map();
  continuousEpoch = 0;
  indexDigest;
  preferences;
  context;
  master;
  limiter;
  buses = /* @__PURE__ */ new Map();
  index;
  indexWork;
  life = new AbortController();
  loads = new AbortController();
  generation = 0;
  closed = false;
  focused = true;
  captionID = 0;
  expiry;
  sources = /* @__PURE__ */ new Set();
  buffers = /* @__PURE__ */ new Map();
  pending = /* @__PURE__ */ new Map();
  variants = /* @__PURE__ */ new Map();
  pins = /* @__PURE__ */ new Map();
  outputEpoch = 0;
  scheduled = /* @__PURE__ */ new Set();
  voiceEpoch = 0;
  voicePriority = -1;
  voiceDeadline = 0;
  musicNames = [];
  musicLevels = [];
  musicSources = [];
  musicWork = false;
  musicEpoch = 0;
  inFlight = 0;
  get manifest() {
    return this.index;
  }
  get statistics() {
    return { context: this.context?.state ?? "absent", sources: this.sources.size, continuous: this.continuousSources.size, buffers: this.buffers.size, decodedBytes: [...this.buffers.values()].reduce((sum, value) => sum + value.bytes, 0), pending: this.pending.size, generation: this.generation, gains: Object.fromEntries([["master", this.master?.gain.value ?? 0], ...BUSES.map((bus) => [bus, this.buses.get(bus)?.gain.value ?? 0])]) };
  }
  attach(target = window) {
    const signal = this.life.signal;
    target.addEventListener("pointerdown", this.gesture, { capture: true, signal });
    target.addEventListener("keydown", this.gesture, { capture: true, signal });
    target.addEventListener("click", this.click, { signal });
    target.addEventListener("blur", this.blur, { signal });
    target.addEventListener("focus", this.focus, { signal });
    document.addEventListener("visibilitychange", this.visibility, { signal });
  }
  async loadIndex(retry = false) {
    if (this.closed || this.index && !retry) return;
    if (this.indexWork) return this.indexWork;
    this.indexWork = (async () => {
      try {
        const response = await this.fetcher("/art/audio/index.json", { signal: this.life.signal, credentials: "omit", redirect: "error", cache: "no-cache" });
        const bytes = await boundedAudioBytes(response, 4 * 1024 ** 2);
        const index = parseAudioIndex(JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes))), digest = await sha256Hex(bytes);
        if (!this.closed) {
          if (this.index && this.indexDigest !== digest) this.reset();
          this.index = index;
          this.indexDigest = digest;
          this.state.update((state) => ({ ...state, error: void 0, status: this.preferences.audioConsent ? this.context?.state === "running" ? "ready" : "gesture" : "disabled" }));
          void this.ensureMusic();
          this.ensureContinuous();
        }
      } catch (error) {
        if (!this.closed) this.state.update((state) => ({ ...state, status: "unavailable", error: error instanceof Error ? error.message : "Audio unavailable." }));
      } finally {
        this.indexWork = void 0;
      }
    })();
    return this.indexWork;
  }
  update(preferences) {
    const withdrawn = this.preferences.audioConsent && !preferences.audioConsent;
    this.preferences = preferences;
    if (withdrawn) {
      this.reset();
      void this.context?.suspend();
    }
    this.applyGains();
    if (!preferences.captions) this.state.update((state) => ({ ...state, captions: [] }));
    this.state.update((state) => ({ ...state, status: !preferences.audioConsent ? "disabled" : this.context?.state === "running" ? "ready" : this.index ? "gesture" : state.status }));
    this.ensureContinuous();
  }
  applyGains() {
    if (!this.context) return;
    this.master.gain.setValueAtTime(this.preferences.audioConsent ? this.preferences.audio.master : 0, this.context.currentTime);
    for (const bus of BUSES) this.buses.get(bus).gain.setValueAtTime(this.preferences.audio[bus], this.context.currentTime);
  }
  gesture = (event) => {
    if (!event.isTrusted || !this.preferences.audioConsent || this.closed || document.visibilityState === "hidden") return;
    this.focused = true;
    if (!this.context) {
      this.context = new AudioContext({ sampleRate: 24e3 });
      this.master = this.context.createGain();
      this.master.connect(this.context.destination);
      this.limiter = this.context.createDynamicsCompressor();
      this.limiter.threshold.value = -3;
      this.limiter.knee.value = 3;
      this.limiter.ratio.value = 20;
      this.limiter.attack.value = 0;
      this.limiter.release.value = 0.1;
      this.limiter.connect(this.master);
      for (const bus of BUSES) {
        const gain = this.context.createGain();
        gain.connect(this.limiter);
        this.buses.set(bus, gain);
      }
      this.applyGains();
    }
    void this.context.resume().then(() => {
      if (!this.closed) {
        this.state.update((state) => ({ ...state, status: "ready" }));
        void this.ensureMusic();
        this.ensureContinuous();
      }
    }).catch(() => this.state.update((state) => ({ ...state, status: "gesture" })));
  };
  click = (event) => {
    if (event.isTrusted && event.target?.closest?.("button") && !event.target.closest("button").disabled) this.play("sfx.ui_click");
  };
  blur = () => {
    this.focused = false;
    this.stopTransient();
    void this.context?.suspend();
  };
  focus = () => {
    this.focused = true;
  };
  visibility = () => {
    if (document.visibilityState === "hidden") this.blur();
    else this.focus();
  };
  caption(text, priority = 50, duration = 5e3) {
    if (!this.preferences.captions || !text) return;
    const now = performance.now(), caption = { id: ++this.captionID, text: text.slice(0, 12e3), priority, expires: now + Math.min(12e3, Math.max(2500, duration)) };
    this.state.update((state) => ({ ...state, captions: [...state.captions.filter((c) => c.expires > now), caption].sort((a, b) => b.priority - a.priority || b.id - a.id).slice(0, 3) }));
    if (this.expiry) clearTimeout(this.expiry);
    this.expireCaptions();
  }
  expireCaptions() {
    this.expiry = setTimeout(() => {
      const now = performance.now();
      this.state.update((state) => ({ ...state, captions: state.captions.filter((c) => c.expires > now) }));
      if (this.state.get().captions.length) this.expireCaptions();
    }, 500);
  }
  play(id, options = {}) {
    if (this.closed) return;
    const entry = this.index?.entries[id], now = performance.now(), priority = options.priority ?? entry?.priority ?? 0;
    if (!this.cooldowns.admit(options.key ?? id, now, options.cooldown ?? entry?.cooldown_ms ?? 0)) return;
    const cursor = this.variants.get(id) ?? 0, variant = entry?.variants[cursor % (entry?.variants.length ?? 1)];
    this.variants.set(id, cursor + 1);
    const text = variant?.display_caption ?? variant?.caption ?? options.caption;
    if (text) this.caption(text, priority, (variant?.duration ?? 3) * 1e3 + 1500);
    if (!entry || !variant || !this.preferences.audioConsent || !this.focused || this.context?.state !== "running") return;
    if (this.preferences.audio.master === 0 || this.preferences.audio[entry.bus] === 0) return;
    let voice = 0;
    if (entry.bus === "voice") {
      if (this.voiceDeadline > now && this.voicePriority > priority) return;
      if (this.voiceDeadline > now && this.voicePriority === priority && priority >= 50 && priority < 100) return;
      this.voicePriority = priority;
      this.voiceDeadline = now + variant.duration * 1e3 + 2e3;
      voice = ++this.voiceEpoch;
      for (const source of this.sources) if (source.bus === "voice") this.stop(source);
    }
    const generation = this.generation, output = this.outputEpoch;
    void this.buffer(variant).then((buffer) => {
      if (generation !== this.generation || output !== this.outputEpoch || this.closed || !this.focused || this.context?.state !== "running" || !this.preferences.audioConsent || voice && voice !== this.voiceEpoch) return;
      if (this.sources.size >= VOICES) {
        const victim = [...this.sources].find((source2) => !source2.music && source2.priority < priority);
        if (!victim) return;
        this.stop(victim);
      }
      const source = this.source(buffer, entry, priority);
      source.node.start();
      if (voice) this.voiceDeadline = performance.now() + buffer.duration * 1e3;
    }).catch((error) => {
      if (voice && voice === this.voiceEpoch) {
        this.voiceDeadline = 0;
        this.voicePriority = -1;
      }
      this.failure(error, generation);
    });
  }
  failure(error, generation) {
    if (generation !== this.generation || this.closed || ["AbortError", "QuotaExceededError"].includes(error.name)) return;
    this.state.update((state) => ({ ...state, error: error instanceof Error ? error.message : "An audio file could not be loaded." }));
  }
  source(buffer, entry, priority, music2 = false, pan) {
    const context = this.context, node = context.createBufferSource(), gain = context.createGain();
    node.buffer = buffer;
    node.loop = entry.loop;
    node.connect(gain);
    const panner = pan === void 0 ? void 0 : context.createStereoPanner();
    if (panner) {
      panner.pan.value = Math.max(-1, Math.min(1, pan ?? 0));
      gain.connect(panner);
      panner.connect(this.buses.get(entry.bus));
    } else gain.connect(this.buses.get(entry.bus));
    const source = { node, gain, panner, bus: entry.bus, priority, music: music2 };
    this.sources.add(source);
    node.onended = () => {
      this.sources.delete(source);
      if (source.key && this.continuousSources.get(source.key) === source) this.continuousSources.delete(source.key);
      node.disconnect();
      gain.disconnect();
      panner?.disconnect();
    };
    return source;
  }
  stop(source) {
    source.node.onended = null;
    try {
      source.node.stop();
    } catch {
    }
    source.node.disconnect();
    source.gain.disconnect();
    source.panner?.disconnect();
    if (source.key) this.continuousSources.delete(source.key);
    this.sources.delete(source);
  }
  async buffer(variant) {
    const key = audioVariantKey(variant), cached = this.buffers.get(key);
    if (cached) {
      cached.used = performance.now();
      return cached.buffer;
    }
    const existing = this.pending.get(key);
    if (existing) return existing;
    if (this.inFlight >= 4) throw new DOMException("Audio decoder is busy.", "QuotaExceededError");
    const generation = this.generation, context = this.context, signal = this.loads.signal;
    this.inFlight++;
    const work = (async () => {
      const decode = async (url, size2, hash) => {
        const response = await this.fetcher(url, { signal, credentials: "omit", redirect: "error", cache: "force-cache" }), bytes = await boundedAudioBytes(response, size2);
        if (bytes.length !== size2 || await sha256Hex(bytes) !== hash) throw Error("Audio integrity check failed.");
        if (generation !== this.generation) throw new DOMException("Operation changed", "AbortError");
        return context.decodeAudioData(bytes.slice().buffer);
      };
      let buffer;
      try {
        buffer = await decode(variant.url, variant.bytes, variant.sha256);
      } catch (error) {
        if (error.name !== "EncodingError" || !variant.mp3_url) throw error;
        buffer = await decode(variant.mp3_url, variant.mp3_bytes, variant.mp3_sha256);
      }
      if (generation !== this.generation) throw new DOMException("Operation changed", "AbortError");
      if (!Number.isFinite(buffer.duration) || Math.abs(buffer.duration - variant.duration) > Math.max(0.15, variant.duration * 0.02) || buffer.numberOfChannels > 2) throw Error("Audio duration/channel validation failed.");
      const size = buffer.length * buffer.numberOfChannels * 4;
      if (size > MEMORY) throw Error("Audio clip exceeds memory budget.");
      for (const [key2, value] of [...this.buffers].sort((a, b) => a[1].used - b[1].used)) {
        if (this.statistics.decodedBytes + size <= MEMORY) break;
        if (!this.pins.has(value.buffer) && ![...this.sources].some((source) => source.node.buffer === value.buffer)) this.buffers.delete(key2);
      }
      if (this.statistics.decodedBytes + size > MEMORY) throw Error("Audio memory budget reached.");
      this.buffers.set(key, { buffer, bytes: size, used: performance.now() });
      return buffer;
    })().finally(() => {
      this.inFlight--;
      if (this.pending.get(key) === work) this.pending.delete(key);
    });
    this.pending.set(key, work);
    return work;
  }
  /** One quiet bed and up to three on-screen actors. Removal stops even a pending clip. */
  continuous(requests) {
    const next = /* @__PURE__ */ new Map();
    for (const request of requests.slice(0, 4)) {
      if (!request.key || request.key.length > 64 || !Number.isFinite(request.gain) || request.gain <= 0) continue;
      next.set(request.key, { ...request, gain: Math.min(0.3, request.gain), pan: Math.max(-1, Math.min(1, request.pan ?? 0)), repeatMs: Math.max(0, Math.min(6e4, request.repeatMs ?? 0)) });
    }
    for (const [key, source] of this.continuousSources) {
      const request = next.get(key), previous = this.continuousRequests.get(key);
      if (!request || request.id !== previous?.id) this.stop(source);
      else {
        source.gain.gain.setTargetAtTime(request.gain, this.context.currentTime, 0.08);
        source.panner?.pan.setTargetAtTime(request.pan ?? 0, this.context.currentTime, 0.08);
      }
    }
    for (const [key, previous] of this.continuousRequests) if (next.get(key)?.id !== previous.id) {
      this.continuousPending.delete(key);
      this.continuousNext.delete(key);
    }
    this.continuousRequests = next;
    this.ensureContinuous();
  }
  ensureContinuous() {
    if (this.closed || !this.index || !this.preferences.audioConsent || !this.focused || this.context?.state !== "running" || this.preferences.audio.master === 0 || this.preferences.audio.effects === 0) return;
    for (const [key, request] of this.continuousRequests) {
      if (this.continuousSources.has(key) || this.continuousPending.has(key) || (this.continuousNext.get(key) ?? 0) > performance.now() || this.sources.size >= VOICES) continue;
      const entry = this.index.entries[request.id];
      if (!entry || entry.bus !== "effects") continue;
      const epoch = ++this.continuousEpoch, generation = this.generation, output = this.outputEpoch;
      this.continuousPending.set(key, epoch);
      void this.buffer(entry.variants[0]).then((buffer) => {
        const latest = this.continuousRequests.get(key);
        if (this.closed || generation !== this.generation || output !== this.outputEpoch || this.continuousPending.get(key) !== epoch || latest?.id !== request.id || !this.focused || this.context?.state !== "running" || !this.preferences.audioConsent || this.sources.size >= VOICES) return;
        const source = this.source(buffer, entry, 0, false, latest.pan);
        source.key = key;
        source.gain.gain.value = latest.gain;
        this.continuousSources.set(key, source);
        this.continuousNext.set(key, performance.now() + Math.max(buffer.duration * 1e3, latest.repeatMs ?? 0));
        source.node.start();
      }).catch((error) => this.failure(error, generation)).finally(() => {
        if (this.continuousPending.get(key) === epoch) this.continuousPending.delete(key);
      });
    }
  }
  /** Layers start together at a single bar origin; intensity changes only their gains. */
  music(ids, levels = ids.map((_, i) => i ? 0 : 1)) {
    const changed = ids.join("|") !== this.musicNames.join("|");
    this.musicNames = [...ids];
    this.musicLevels = [...levels];
    if (changed) {
      this.musicEpoch++;
      for (const source of this.musicSources) this.stop(source);
      this.musicSources = [];
      this.musicWork = false;
    }
    if (this.musicSources.length) this.mixMusic();
    else void this.ensureMusic();
    this.ensureContinuous();
  }
  async ensureMusic() {
    if (this.musicWork || this.musicSources.length || !this.musicNames.length || !this.index || !this.preferences.audioConsent || !this.focused || this.context?.state !== "running") return;
    const ids = [...this.musicNames], entries = ids.map((id) => this.index.entries[id]);
    if (entries.some((entry) => !entry || entry.bus !== "music" || !entry.loop)) return;
    const first = entries[0];
    if (entries.length > 3 || entries.some((entry) => entry.bpm !== first.bpm || entry.beats_per_bar !== first.beats_per_bar || Math.abs(entry.variants[0].duration - first.variants[0].duration) > 0.05)) {
      this.state.update((state) => ({ ...state, error: "Music layers do not share a valid loop." }));
      return;
    }
    const generation = this.generation, epoch = this.musicEpoch;
    this.musicWork = true;
    const buffers = [];
    try {
      for (const entry of entries) {
        const buffer = await this.buffer(entry.variants[0]);
        buffers.push(buffer);
        this.pins.set(buffer, (this.pins.get(buffer) ?? 0) + 1);
      }
      if (generation !== this.generation || epoch !== this.musicEpoch || ids.join("|") !== this.musicNames.join("|") || this.closed || !this.preferences.audioConsent) return;
      const when = this.context.currentTime + 0.05;
      this.musicSources = entries.map((entry, i) => {
        const source = this.source(buffers[i], entry, 0, true);
        source.gain.gain.value = this.musicLevels[i] ?? 0;
        source.node.start(when);
        return source;
      });
    } catch (error) {
      this.failure(error, generation);
    } finally {
      for (const buffer of buffers) {
        const count = (this.pins.get(buffer) ?? 1) - 1;
        if (count > 0) this.pins.set(buffer, count);
        else this.pins.delete(buffer);
      }
      if (generation === this.generation && epoch === this.musicEpoch) this.musicWork = false;
    }
  }
  mixMusic() {
    if (!this.context) return;
    this.musicSources.forEach((source, i) => source.gain.gain.setTargetAtTime(Math.max(0, Math.min(1, this.musicLevels[i] ?? 0)), this.context.currentTime, 0.6));
  }
  afterSpeech(id) {
    const generation = this.generation, timer = setTimeout(() => {
      this.scheduled.delete(timer);
      if (generation === this.generation && !this.closed) this.play(id);
    }, Math.max(100, this.voiceDeadline - performance.now() + 100));
    this.scheduled.add(timer);
  }
  clearCaptions() {
    if (this.expiry) clearTimeout(this.expiry);
    this.state.update((state) => ({ ...state, captions: [] }));
  }
  stopTransient() {
    this.continuousNext.clear();
    this.outputEpoch++;
    this.voiceEpoch++;
    this.voiceDeadline = 0;
    for (const source of this.sources) if (!source.music) this.stop(source);
  }
  /** Session/seek/reconnect boundary: abort late loads and prevent stale warnings. */
  reset() {
    this.continuousRequests.clear();
    this.continuousPending.clear();
    this.continuousNext.clear();
    this.outputEpoch++;
    for (const timer of this.scheduled) clearTimeout(timer);
    this.scheduled.clear();
    this.generation++;
    this.musicEpoch++;
    this.loads.abort();
    this.loads = new AbortController();
    for (const source of this.sources) this.stop(source);
    this.musicSources = [];
    this.musicWork = false;
    this.pending.clear();
    this.buffers.clear();
    this.pins.clear();
    this.cooldowns.clear();
    this.variants.clear();
    this.voiceEpoch++;
    this.voiceDeadline = 0;
    this.voicePriority = -1;
    this.state.update((state) => ({ ...state, captions: [] }));
    if (this.expiry) clearTimeout(this.expiry);
  }
  dispose() {
    if (this.closed) return;
    this.closed = true;
    this.life.abort();
    this.reset();
    this.musicNames = [];
    this.buses.clear();
    void this.context?.close();
    this.context = void 0;
  }
};

// client/src/runtime/crypto.ts
var constants2 = new Uint32Array([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]);

// client/src/runtime/storage.ts
var MAX_SAVE = 64 * 1024 * 1024;
var MAX_REPLAY = 64 * 1024 * 1024;
var MAX_BACKUP = 256 * 1024 * 1024;

// client/src/runtime/content-library.ts
var LIMITS = { index: 1 << 20, map: 16 << 20, mission: 2 << 20 };

// client/src/runtime/campaign-journey.ts
var CAMPAIGN_STORIES = Object.freeze([
  { faction: "US", title: "Operation Clear Horizon", missions: Object.freeze(["First Foothold", "Open Corridor", "Relay Ridge", "Broken Umbrella", "Split Front", "Clear Horizon"]) },
  { faction: "IR", title: "Operation Iron Signal", missions: Object.freeze(["Forward Signal", "Eyes Above", "Beyond the Basin", "Hold the Network", "The Second Volley", "Iron Signal"]) },
  { faction: "SY", title: "Operation Open Road", missions: Object.freeze(["Workshop Foothold", "Supply Trail", "Three Crossings", "Open Doors", "Relay Break", "Open Road"]) },
  { faction: "SA", title: "Operation Shieldline", missions: Object.freeze(["Arrival Point", "Moving Shield", "Distant Depots", "Intercept Window", "Three Positions", "Shieldline"]) }
].map((value) => Object.freeze(value)));
var TUTORIAL_LESSONS = Object.freeze(["Give an order", "Operate a base", "Read the counter", "Defend the sky", "Command a match"]);
var COOP_SCENARIOS = Object.freeze(["Convoy Union", "Twin Outposts"]);
var MISSION_DIFFICULTIES = Object.freeze(["easy", "normal", "hard"]);

// client/src/runtime/editor.ts
var encoder = new TextEncoder();
var MAX_MAP_BYTES = 16 * 1024 * 1024;
var MAX_MISSION_BYTES = 2 * 1024 * 1024;
var MAX_DOCUMENT_BYTES = 20 * 1024 * 1024;

// client/src/runtime/keybindings.ts
var chord = (code, ...modifiers2) => ({ code, modifiers: modifiers2 });
var definition = (id, label, category, defaults = [], extra = {}) => ({ id, label, category, defaults, ...extra });
var SHORTCUT_DEFINITIONS = [
  definition("attack_move", "Attack-move", "orders", [chord("KeyA")], { queueModifier: true }),
  definition("stop", "Stop", "orders", [chord("KeyS")], { queueModifier: true }),
  definition("hold", "Hold position", "orders", [chord("KeyH")], { queueModifier: true }),
  definition("guard", "Guard unit or position", "orders", [chord("KeyG")], { queueModifier: true }),
  definition("move", "Move", "orders", [chord("KeyM")], { queueModifier: true }),
  definition("patrol", "Patrol", "orders", [chord("KeyP")], { queueModifier: true }),
  definition("escort", "Escort", "orders", [chord("KeyE")], { queueModifier: true }),
  definition("return", "Return to service", "orders", [chord("KeyR")], { queueModifier: true }),
  definition("repair", "Repair", "orders", [chord("KeyY")], { queueModifier: true }),
  definition("board", "Board", "orders", [chord("KeyB")], { queueModifier: true }),
  definition("unload", "Unload", "orders", [chord("KeyU")], { queueModifier: true }),
  definition("capture", "Capture", "orders", [chord("KeyC")], { queueModifier: true }),
  definition("force_fire", "Force-fire", "orders", [chord("KeyF")], { queueModifier: true }),
  definition("rally", "Set rally point", "orders", [chord("KeyL")]),
  definition("aggressive", "Aggressive stance", "orders", [chord("KeyX")], { queueModifier: true }),
  definition("deploy", "Deploy", "orders", [chord("KeyD")]),
  definition("pack", "Pack", "orders", [chord("KeyV")]),
  ...["build", "resume", "train", "research", "cancel_production", "sell", "power", "gather", "salvage", "repeat_sortie", "repair_reserve", "surrender_vote", "surrender_cancel", "convoy_hold", "convoy_advance", "ping"].map((id) => definition(id, id.replaceAll("_", " "), "orders")),
  ...Array.from({ length: 6 }, (_, i) => definition(`ability_${i + 1}`, `Ability ${i + 1}`, "orders", [], { queueModifier: true })),
  definition("select_all", "Select all controllable forces", "selection", [chord("KeyA", "ctrl")]),
  definition("select_same_type", "Select same type on screen", "selection", [chord("KeyT")]),
  definition("next_subgroup", "Next selection subgroup", "selection", [chord("Tab")]),
  definition("previous_subgroup", "Previous selection subgroup", "selection", [chord("Tab", "shift")]),
  definition("toggle_queue", "Toggle queued orders", "interface"),
  definition("toggle_multiselect", "Toggle additive selection", "interface"),
  definition("center_selection", "Center selection", "camera", [chord("Home")]),
  definition("center_alert", "Center latest actionable alert", "camera", [chord("Space")]),
  ...["Up", "Down", "Left", "Right"].map((direction) => definition(`pan_${direction.toLowerCase()}`, `Pan ${direction.toLowerCase()}`, "camera", [chord(`Arrow${direction}`)], { repeat: true })),
  definition("zoom_in", "Zoom in", "camera", [chord("Equal"), chord("NumpadAdd")], { repeat: true }),
  definition("zoom_out", "Zoom out", "camera", [chord("Minus"), chord("NumpadSubtract")], { repeat: true }),
  definition("escape", "Cancel targeting / pause menu", "interface", [chord("Escape")]),
  definition("chat", "Open match chat", "interface", [chord("Enter")]),
  definition("team_chat", "Open team chat", "interface", [chord("Enter", "shift")]),
  definition("quick_save", "Quick save (solo)", "interface", [chord("F5")]),
  definition("quick_load", "Quick load (solo)", "interface", [chord("F9")]),
  ...Array.from({ length: 9 }, (_, i) => [
    definition(`group_${i + 1}_recall`, `Recall group ${i + 1}`, "groups", [chord(`Digit${i + 1}`)]),
    definition(`group_${i + 1}_store`, `Store group ${i + 1}`, "groups", [chord(`Digit${i + 1}`, "ctrl")]),
    definition(`group_${i + 1}_append`, `Add selection to group ${i + 1}`, "groups", [chord(`Digit${i + 1}`, "ctrl", "shift")])
  ]).flat()
];
var modifiers = ["ctrl", "alt", "shift", "meta"];
function validModifier(value) {
  return modifiers.includes(value);
}
function normalized(chord2) {
  if (!chord2 || typeof chord2.code !== "string" || !/^[A-Za-z][A-Za-z0-9]{0,31}$/.test(chord2.code) || chord2.modifiers && !Array.isArray(chord2.modifiers)) throw new TypeError("Use a physical keyboard code and modifier list");
  const list = chord2.modifiers ?? [];
  if (list.some((modifier) => !validModifier(modifier)) || new Set(list).size !== list.length) throw new TypeError("Invalid or repeated keyboard modifier");
  return { code: chord2.code, modifiers: modifiers.filter((modifier) => list.includes(modifier)) };
}
function defaultBindings(preset = "standard") {
  return { preset, keys: Object.fromEntries(SHORTCUT_DEFINITIONS.map((def) => [def.id, def.defaults.map(normalized)])), modifiers: { queue: "shift", multiSelect: "shift", forceFire: "ctrl" }, pointer: { select: 0, context: preset === "classic" ? 0 : 2, pan: 1, cancel: 2 } };
}

// client/src/runtime/command-intent.ts
var command = (kind, targets, selection = "group", queueable = true, splittable = false, targetOptional = false) => ({ kind, targets, selection, queueable, splittable, targetOptional });
var STANDARD_COMMAND_DESCRIPTORS = [
  ...["move", "attack_move", "force_fire", "aggressive", "patrol"].map((kind) => command(kind, ["ground"], "group", true, true)),
  command("attack", ["entity"], "group", true, true),
  command("guard", ["ground", "entity"], "group", true, true),
  command("escort", ["entity"], "group", true, true),
  ...["stop", "hold"].map((kind) => command(kind, [], "group", true, true, true)),
  command("return", ["entity"], "group", true, true, true),
  ...["repair", "board"].map((kind) => command(kind, ["entity"], "group", true, true)),
  command("resume", ["entity"], "each", false, false),
  command("capture", ["entity", "station"], "group", true, true),
  command("unload", ["ground"], "group", true, true),
  command("gather", ["field"], "group", true, true, true),
  command("salvage", ["salvage"], "group", true, true),
  command("rally", ["ground"], "each", false, false),
  command("build", ["ground"], "single", false, false),
  ...["train", "research", "cancel"].map((kind) => command(kind, [], "single", false, false, true)),
  ...["sell", "power"].map((kind) => command(kind, [], "each", false, false, true)),
  ...["deploy", "pack", "repeat_sortie"].map((kind) => command(kind, [], "group", false, true, true)),
  command("ability", ["ground", "entity", "station"], "group", false, false, true),
  command("ping", ["ground"], "none", false, false),
  ...["surrender", "surrender_vote", "surrender_cancel", "repair_reserve", "convoy_hold", "convoy_advance"].map((kind) => command(kind, [], "none", false, false, true))
];

// client/src/runtime/save-sync.ts
var SYNC_MAX_BYTES = 256 * 1024 * 1024;
var MAX_BYTES = 256 * 1024 * 1024;
var encoder2 = new TextEncoder();

// client/src/app/settings.ts
var DEFAULT_SETTINGS = {
  version: 1,
  firstRunComplete: false,
  language: "en",
  uiScale: 1,
  minimapScale: 1,
  audioConsent: false,
  audio: { master: 0.8, music: 0.6, effects: 0.8, voice: 0.9, ui: 0.6 },
  captions: true,
  reducedMotion: false,
  reducedFlashing: false,
  screenShake: 0.6,
  palette: "standard",
  healthBars: "selected",
  keyboardCamera: true,
  edgeScroll: false,
  scrollSpeed: 1,
  zoomSpeed: 1,
  selectionTolerance: 6,
  dragThreshold: 6,
  artQuality: "auto",
  bindings: defaultBindings("standard")
};

// work/audio-mix-headroom-v1/fixture-candidate.ts
var mixer = new AudioMixer({ ...DEFAULT_SETTINGS, audioConsent: true });
var graph = mixer;
var music = ["calm", "tension", "combat"].map((layer) => "music.battle_US_" + layer);
var effects = ["AA", "AA_POST", "APC", "ART", "AT", "AUTO", "ELI", "FIGHT", "GUN", "IR_ART", "IR_FIGHT", "IR_LOITER", "IR_MISSILE", "IR_STRIKE", "MISSILE", "REC"].map((id) => "sfx.weapon." + id);
var ambient = ["sfx.ambient_desert_wind", "sfx.engine_tracked_heavy", "sfx.engine_hauler", "sfx.engine_rig"];
var warning = "vo.announcer.US.missile_warning";
var meter;
var sequence = 0;
var pending = /* @__PURE__ */ new Map();
var message = (kind) => new Promise((resolve) => {
  const id = ++sequence;
  pending.set(id, (value) => resolve(value));
  meter.port.postMessage({ id, kind });
});
var wait = async (predicate) => {
  const deadline = performance.now() + 1e4;
  while (!predicate()) {
    if (performance.now() > deadline) throw Error("Audio graph state deadline");
    await new Promise((resolve) => setTimeout(resolve, 10));
  }
};
mixer.attach();
var api = {
  async ready() {
    await mixer.loadIndex();
    return mixer.statistics;
  },
  state() {
    return { statistics: mixer.statistics, state: mixer.state.get(), context: graph.context?.state };
  },
  async instrument() {
    if (graph.context.state !== "running") throw Error("Requires real trusted consent gesture");
    await graph.context.audioWorklet.addModule("/meter.js");
    meter = new AudioWorkletNode(graph.context, "headroom-meter", { numberOfInputs: 1, numberOfOutputs: 1, outputChannelCount: [2] });
    meter.port.onmessage = (event) => {
      const resolve = pending.get(event.data.id);
      pending.delete(event.data.id);
      resolve?.(event.data.value);
    };
    graph.master.connect(meter);
    meter.connect(graph.context.destination);
    return { sampleRate: graph.context.sampleRate, state: graph.context.state };
  },
  async prepare(maximum) {
    mixer.music([]);
    mixer.reset();
    const preferences = { ...DEFAULT_SETTINGS, audioConsent: true, audio: maximum ? { master: 1, music: 1, effects: 1, voice: 1, ui: 1 } : DEFAULT_SETTINGS.audio };
    mixer.update(preferences);
    const ids = [...music, ...ambient, warning, ...effects];
    const buffers = [];
    for (const id of ids) {
      const entry = mixer.manifest.entries[id];
      if (!entry) throw Error("Missing original audio " + id);
      const buffer = await graph.buffer(entry.variants[0]);
      buffers.push({ id, frames: buffer.length, channels: buffer.numberOfChannels, duration: buffer.duration });
    }
    if (mixer.statistics.sources) throw Error("Preparation accidentally started playback");
    return { preferences, buffers, statistics: mixer.statistics };
  },
  async start(count) {
    await message("reset");
    mixer.music(music, [0, 0, 1]);
    mixer.continuous(ambient.map((id, i) => ({ key: "review-" + i, id, gain: i ? 0.18 : 0.07, pan: 0 })));
    mixer.play(warning);
    for (const id of effects.slice(0, count)) mixer.play(id);
    await wait(() => mixer.statistics.sources === 8 + count);
    return api.state();
  },
  read: () => message("read"),
  async clear() {
    mixer.music([]);
    mixer.reset();
    await wait(() => mixer.statistics.sources === 0 && mixer.statistics.pending === 0);
    return api.state();
  },
  async dispose() {
    const context = graph.context;
    meter?.disconnect();
    meter?.port.close();
    mixer.dispose();
    await wait(() => context.state === "closed");
    return { statistics: mixer.statistics, closedContext: context.state };
  }
};
window.audioMixQA = api;
document.getElementById("gesture").textContent = "Enable isolated audio check";
/*! Bundled license information:

react/cjs/react.development.js:
  (**
   * @license React
   * react.development.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)
*/
